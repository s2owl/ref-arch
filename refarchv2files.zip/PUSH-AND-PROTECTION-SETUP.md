## 1. Before anything else: fill in LICENSE

The file has a literal placeholder right now — [YOUR FULL LEGAL NAME] — and a
license naming no one doesn't actually protect anything. Edit that first.

## 2. Push — new branch, not direct to main

Since branch protection will require PRs anyway (and the repo's own stated
principle is "all changes via PR — audit trail"), push to a new branch and
open a PR rather than pushing straight to main. This also sidesteps a real
risk: if funfairlabs-incubator/ref-arch-v2 already has commit history that
doesn't share ancestry with this merged copy, a direct push to main could
be rejected or (worse, if forced) overwrite existing work.

```bash
cd ref-arch-v2

# Set your token as an environment variable — never paste it directly
# into a command, so it doesn't end up in shell history verbatim
export GITHUB_TOKEN="paste_your_token_here"

# Add the remote using the env var, not the literal token
git remote add origin "https://${GITHUB_TOKEN}@github.com/funfairlabs-incubator/ref-arch-v2.git"

# Push to a new branch, not main
git checkout -b merge-as-built
git push -u origin merge-as-built

# Immediately strip the token back out of the stored remote URL,
# so it's not sitting in .git/config in plaintext afterward
git remote set-url origin "https://github.com/funfairlabs-incubator/ref-arch-v2.git"

# Then open a PR from merge-as-built -> main in the GitHub UI,
# or via: gh pr create --base main --head merge-as-built
```

## 3. Branch protection — both options, as requested

**Manual** (no token/API needed at all): follow
`docs/branch-protection-setup.md` directly in Settings → Branches.
Already fully specified, 2-3 minutes.

**Scripted**, if you'd rather automate it — matches that same doc's spec
exactly:

```bash
cat > branch-protection.json << 'EOF'
{
  "required_status_checks": null,
  "enforce_admins": true,
  "required_pull_request_reviews": {
    "dismiss_stale_reviews": true,
    "require_code_owner_reviews": true,
    "required_approving_review_count": 1
  },
  "restrictions": null,
  "required_linear_history": true,
  "required_conversation_resolution": true
}
EOF

gh api \
  --method PUT \
  -H "Accept: application/vnd.github+json" \
  repos/funfairlabs-incubator/ref-arch-v2/branches/main/protection \
  --input branch-protection.json
```

Requires `gh auth login` first (or `GH_TOKEN` env var set) — same principle
as above, run this yourself with your own authenticated session.
