# Akamai Prolexic DDoS — VSBB-AKA-DDOS-001
# Terraform — Akamai provider
# Part of PAT-SEC-001 AND rule — must be deployed with GRE clean return

terraform {
  required_providers {
    akamai = {
      source  = "akamai/akamai"
      version = "~> 5.0"
    }
  }
}

provider "akamai" {
  # Credentials via .edgerc file or environment variables
}

resource "akamai_network_list" "protected_prefixes" {
  name        = "${var.location_name}-protected"
  type        = "IP"
  description = "Protected prefixes — ${var.location_name}"
  list        = var.protected_prefixes
}

# GRE return tunnel — note: provisioned via Akamai portal or API
# This resource documents the configuration intent
# Coordinate with Akamai TAM for actual GRE provisioning
output "gre_tunnel_config" {
  value = {
    location       = var.location_name
    source_ip      = var.gre_tunnel_source
    destination_ip = var.gre_tunnel_dest
    mode           = var.diversion_mode
    bgp_asn        = var.bgp_asn
    bandwidth_gbps = var.upstream_bandwidth
    note           = "Manual GRE provisioning required with Akamai TAM"
  }
}

variable "location_name"      { type = string }
variable "protected_prefixes" { type = list(string) }
variable "diversion_mode"     { type = string  default = "always-on" }
variable "gre_tunnel_source"  { type = string }
variable "gre_tunnel_dest"    { type = string }
variable "bgp_asn"            { type = number }
variable "upstream_bandwidth" { type = number }
variable "alert_threshold"    { type = number  default = 1000 }
variable "notification_email" { type = string }
