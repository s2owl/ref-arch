# Zscaler ZIA Tunnel Configuration — VSBB-ZSC-PROXY-001
# Terraform — Zscaler provider
# PAC file URL must be centrally managed — not local

terraform {
  required_providers {
    zscaler = {
      source  = "zscaler/zscaler"
      version = "~> 3.0"
    }
  }
}

provider "zia" {
  # Credentials via environment variables:
  # ZIA_USERNAME, ZIA_PASSWORD, ZIA_API_KEY, ZIA_CLOUD
}

resource "zia_location_management" "site" {
  name        = var.location_name
  description = "Managed via IaC — VSBB-ZSC-PROXY-001"
  country     = "UNITED_KINGDOM"
  tz          = "EUROPE_LONDON"
  auth_required     = var.auth_required
  xff_forward_enabled = var.xff_forwarding
  surrogate_ip      = false
  idle_time_in_minutes = 30
  display_time_unit    = "MINUTE"
  bandwidth_up      = var.bandwidth_mbps
  bandwidth_down    = var.bandwidth_mbps
}

resource "zia_traffic_forwarding_gre_tunnel" "site_tunnel" {
  count           = var.tunnel_type == "GRE" ? 1 : 0
  source_ip       = var.source_ip
  primary_dest_vip {
    id = data.zia_traffic_forwarding_vpn_credentials.nodes.primary_id
  }
  secondary_dest_vip {
    id = data.zia_traffic_forwarding_vpn_credentials.nodes.secondary_id
  }
  comment        = "Site: ${var.location_name} — IaC managed"
  within_country = false
}

variable "location_name"  { type = string }
variable "source_ip"      { type = string }
variable "tunnel_type"    { type = string  default = "GRE" }
variable "primary_node"   { type = string }
variable "secondary_node" { type = string }
variable "pac_file_url"   { type = string }
variable "ssl_inspection" { type = bool    default = true }
variable "auth_required"  { type = bool    default = true }
variable "xff_forwarding" { type = bool    default = false }
variable "bandwidth_mbps" { type = number  default = 100 }
