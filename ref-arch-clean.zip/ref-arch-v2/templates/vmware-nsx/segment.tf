# VMware NSX-T Segment — VSBB-VMW-NSX-001
# Terraform — VMware NSX-T provider
# Co-owned with virtualisation team — coordinate before deployment

terraform {
  required_providers {
    nsxt = {
      source  = "vmware/nsxt"
      version = "~> 3.3"
    }
  }
}

provider "nsxt" {
  # Credentials via environment variables:
  # NSXT_MANAGER_HOST, NSXT_USERNAME, NSXT_PASSWORD
}

data "nsxt_policy_transport_zone" "tz" {
  display_name = var.transport_zone
}

data "nsxt_policy_tier1_gateway" "t1" {
  display_name = var.connected_gateway
}

resource "nsxt_policy_segment" "segment" {
  display_name = var.segment_name
  description  = "Managed via IaC — VSBB-VMW-NSX-001"

  transport_zone_path = data.nsxt_policy_transport_zone.tz.path
  connectivity_path   = data.nsxt_policy_tier1_gateway.t1.path

  dynamic "subnet" {
    for_each = var.gateway_address != "" ? [1] : []
    content {
      cidr = var.gateway_address
    }
  }

  vni  = var.vni != 0 ? var.vni : null

  tag {
    tag = "managed-by-iac"
  }
}

variable "segment_name"      { type = string }
variable "transport_zone"    { type = string }
variable "connected_gateway" { type = string }
variable "gateway_address"   { type = string  default = "" }
variable "vni"               { type = number  default = 0 }
variable "vrf_name"          { type = string  default = "" }
variable "dfw_policy"        { type = string  default = "" }
variable "replication_mode"  { type = string  default = "MTEP" }
