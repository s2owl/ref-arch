# Avi NSX ALB Virtual Service — VSBB-VMW-AVI-LB-001
# Terraform — VMware Avi provider
# Co-owned with virtualisation team

terraform {
  required_providers {
    avi = {
      source  = "vmware/avi"
      version = "~> 22.1"
    }
  }
}

provider "avi" {
  # AVI_CONTROLLER, AVI_USERNAME, AVI_PASSWORD, AVI_TENANT
}

data "avi_cloud" "cloud" {
  name = var.cloud_ref
}

resource "avi_pool" "pool" {
  name      = "${var.pool_name}"
  cloud_ref = data.avi_cloud.cloud.id
  lb_algorithm = var.algorithm

  dynamic "servers" {
    for_each = var.pool_servers
    content {
      ip { addr = servers.value  type = "V4" }
      port = var.vip_port
    }
  }

  health_monitor_refs = [
    "https://${var.cloud_ref}/api/healthmonitor/?name=${var.health_monitor}"
  ]
}

resource "avi_virtualservice" "vs" {
  name      = var.vs_name
  pool_ref  = avi_pool.pool.id
  cloud_ref = data.avi_cloud.cloud.id

  vip {
    ip_address { addr = var.vip_address  type = "V4" }
    vip_id = "0"
  }

  services {
    port           = var.vip_port
    enable_ssl     = var.ssl_cert != "" ? true : false
  }
}

variable "vs_name"       { type = string }
variable "vip_address"   { type = string }
variable "vip_port"      { type = number  default = 443 }
variable "pool_name"     { type = string }
variable "pool_servers"  { type = list(string) }
variable "algorithm"     { type = string  default = "ROUND_ROBIN" }
variable "health_monitor"{ type = string  default = "HTTPS" }
variable "cloud_ref"     { type = string }
variable "se_group"      { type = string  default = "" }
variable "ssl_cert"      { type = string  default = "" }
