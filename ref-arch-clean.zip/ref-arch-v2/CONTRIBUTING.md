# Contributing to ref-arch

This is the source of truth for network architecture governance.
If you've been asked to contribute, this guide tells you what's needed
and where your contribution fits.

---

## Who does what

Architecture governance is a single-contributor function today.
That does not mean a single person produces everything.

**PA defines and gates. Domain experts produce.**

| Artefact | Who produces | PA role |
|---|---|---|
| ABB | PA | Produces — capability definition is architecture's language |
| SBB | SME | Reviews and approves against ABB capability gates |
| VSBB | SME / Engineer | Reviews and approves against SBB capability gates |
| ZBB | PA drafts, Cyber co-signs | Co-produces — neither can do it alone |
| Pattern | PA or Engineer/SME | Approves — regardless of source |
| Standard | SME (triggered by operational reality) | Reviews and approves |
| Decision record | PA | Produces — immutable audit trail |
| Options paper | Requestor | Reviews and endorses via Thread 2 |
| Service blueprint | MGR / Engineer | Reviews and approves architecture fit |
| Deployment register | Engineer | Informed — engineers own their deployments |

**The single most valuable contribution you can make:**
Document an unwritten rule as a standard. Every domain has norms that
exist in practice but aren't written down. They govern how things are
built, they get enforced in reviews, but they're invisible to governance,
audit, and anyone new. Write it down. Use the template. Start as a draft.

---

## Standards — how they get written

Standards are triggered by operational reality. PA does not speculatively
produce standards. Valid triggers:

- An unwritten rule surfaced via peer review or the forum
- A deviation being raised repeatedly — signals a missing rule
- A new platform introducing undocumented configuration norms
- A cross-domain risk that exposes a boundary gap

**To write a standard:**
1. Copy `standards/STANDARD-TEMPLATE.yaml` to the right domain folder
2. Populate `operational_owner` — this must be you or a named peer.
   Without a named owner, a standard has no one to flag when it
   drifts from reality. It becomes a dead document.
3. Set `trigger` — why does this standard exist? What operational
   reality is it grounded in?
4. Set `co_reviewed_by` if the standard intersects another domain
   (e.g. Cyber for any security-relevant rule)
5. Write the rules. Use MUST / MUST NOT. Include rationale for each.
   A rule without rationale is an assertion. Rationale is what makes
   it stick.
6. Status `draft` is fine — raise a PR. PA reviews and approves.

**Annual certification:**
PA does not certify every standard every year. The `operational_owner`
flags drift via the operational feedback channel when reality diverges
from the standard. PA spot-checks the feedback register for drift patterns.
If you are the operational_owner of a standard — you are the person
who keeps it honest.

---

## Patterns — two sources, one gate

A pattern is an approved way of assembling SBBs into a working solution.

**Architecture-initiated:** PA defines what right looks like before
engineers start. Prevents "artistic licence" in topology assembly.

**Engineering-initiated:** Engineers solve the same problem the same
way repeatedly. Document what you're doing. Raise it as a PR.
PA reviews and codifies it as an approved pattern.

Source doesn't matter. PA approval is the gate. A pattern is only
available for topology conformance self-certification once PA has
approved it. Copy `patterns/PATTERN-TEMPLATE.yaml` to start.

---

## The Arch/Eng Forum

Two threads. Know which one you need before you come.

### Thread 1 — Socialise

Comment and feedback within the domain. No approval. No endorsement.
Peer-level discussion. Use it for designs you're working through,
standards you think need revisiting, or capabilities with no SBB yet.

**MGR and GCB3 do not attend Thread 1.** Forum integrity requires
management chain separation — engineers self-censor otherwise.
Thread 1 is a technical and governance peer space.

### Thread 2 — Endorsement

Bring something for PA to review and endorse to proceed to review groups
or design authority. Formal step. Formal output:
**Endorsed / Endorsed with conditions / Not endorsed.**

**What you must bring:**
1. Solution design or options paper
2. Completed topology conformance self-assessment
3. Documented deviations — named, not discovered
4. Which review stage you are targeting next

---

## How to route your solution

```
Does an approved Service Blueprint (SVC-XXX) cover this?
    YES → Consume via ITSM. No design needed.
    NO  ↓

Does an approved Pattern cover this?
    YES → Complete topology conformance self-assessment.
          All three checks pass?
              YES → Self-certify in PR → Solution Design Forum
              NO  → Deviation path (see below)
    NO  ↓

Wholly new — no ABB/SBB coverage?
    YES → Raise an Options Paper Request Issue before designing.
```

**Deviation path:**
Raise a Deviation Request Issue → document what differs and why →
Thread 2 endorsement → appropriate review group.

---

## Topology conformance self-assessment

This is the definition of "as intended." Three questions.
All three must be YES for low-risk self-certification.

**TC-01 — Components**
Are all platforms approved VSBBs in `net-config/{vendor}/vendor-sbbs/`?

**TC-02 — Traffic flows match ZBB boundary contract**
Do all traffic flows match the `boundary_contract` of the zones involved?
Does the path traffic takes match the enforcement model in the contract?
Is every inline component named as an enforcement point?

> Example failure: Server return traffic transiting a firewall not named
> as an enforcement point in ZBB-APP-001's boundary contract. F5 and
> Checkpoint are both approved VSBBs. The topology is non-compliant
> because the routing path isn't in the boundary contract. Approved
> components assembled incorrectly is the risk this check catches.

**TC-03 — No undocumented flows**
Can every traffic path in your design be traced to a ZBB rule or pattern?

| Result | Action |
|---|---|
| All three YES | Self-certify in PR → Solution Design Forum |
| Any NO | Raise Deviation Request Issue before PR or forum |

---

## RACI summary

Full RACI in `governance/raci.yaml`. Summary:

| Solution type | Route | Accountable |
|---|---|---|
| Approved service exists | Consume via ITSM | — |
| Approved VSBBs + TC pass | PR self-cert → Solution Design Forum | PA (current) / CSD (target) |
| Documented deviation | Thread 2 → Review Group | PA — always |
| Wholly new capability | Options paper → Thread 2 → DA | PA — always |
| Cross-domain risk | Cross-domain consult before forum | PA — always |

**Current state constraint:** PA is accountable for all solution sign-off
today. This is acknowledged as a bottleneck. The target state removes PA
from the critical path for low-risk compliant work as CSD matures.
See `governance/raci.yaml` for the transition trigger.

---

## I've already built something — what now?

Recovery path if a solution arrives at peer review without prior
architecture engagement:

**Step 1** — Run topology conformance self-assessment against what exists.

**Step 2** — All three TC checks pass: raise a retrospective PR with
self-certification. Note it is a retrospective submission.
Low-risk recovery. PA not in critical path if genuinely compliant.

**Step 3** — Any TC check fails: raise a Deviation Request Issue
before the PR. Document what was built, which check failed, the risk,
and the proposed remediation.

**Step 4** — Cross-domain risk identified: peer review stops until
the domain owner is consulted. Not optional.

**Step 5** — Already in production: raise a retrospective Deviation
Request Issue with a remediation plan and target date. Becomes a
governance finding tracked until closed.

**The framework is not punitive.** A documented retrospective deviation
with a remediation plan is a better outcome than an undocumented risk.

---

## Cross-domain risk — the rule

If your solution introduces risk outside the network domain, that
domain must be consulted before any review can conclude.

Common boundaries:
- **Cyber** — firewall policy, WAF, SSL inspection, ZBB boundary enforcement
- **Identity** — Conditional Access, MFA, device compliance
- **Application** — application-layer routing, health endpoints
- **DC Facilities** — physical cabling, power, cooling

The ZBB boundary contract is the reference. If your solution touches a
boundary owned by another domain — that domain is a required reviewer.

---

## Questions

Raise a GitHub Issue with the label `question` or contact PA directly.
