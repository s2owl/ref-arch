<!-- BOTTOM LINE UP FRONT

  THREE ENTRY POINTS — find yours:

  Business / app team?
    Check the NC register (capabilities/NC-CATALOGUE.yaml) for your
    capability. Raise via ITSM. No VLANs, ports, or vendors needed.

  Technical consumer (server/platform/infra team)?
    Check the TSS sheets (consumption/technical-service-sheets/).
    Raise via ITSM with the spec completed.

  Engineer / CSD / programme?
    Does a Service Blueprint cover it? → ITSM. Done.
    Does a Pattern cover it? → TC-01/02/03, then PR.
    TC fail? → Deviation Request Issue BEFORE building.
    No coverage? → Options Paper Request Issue. Don't design yet.

  New to the framework? → governance/how-to-use.html
  Need the big picture? → governance/master-flow.html
-->

# Contributing to ref-arch

This is the source of truth for network architecture governance.
If you've been asked to contribute, this guide tells you what's needed
and where your contribution fits.

---

## Who does what

Architecture governance is a single-contributor function today.
That does not mean a single person produces everything.

**PA defines and gates. Domain experts produce.**

| Artefact | Who produces | PA role |
|---|---|---|
| ABB | PA | Produces — capability definition is architecture's language |
| SBB | SME | Reviews and approves against ABB capability gates |
| VSBB | SME / Engineer | Reviews and approves against SBB capability gates |
| ZBB | PA drafts, Cyber co-signs | Co-produces — neither can do it alone |
| Pattern | PA or CSD/SME | Approves — regardless of source |
| Standard | SME (triggered by operational reality) | Reviews and approves |
| Decision record | PA | Produces — immutable audit trail |
| Options paper | Requestor | Reviews and endorses via Thread 2 |
| Service blueprint | PO / Engineer | Reviews and approves architecture fit |
| NC record | PA | Produces capability definition and availability heatmap |
| TSS | SME (operational_owner) | Reviews and approves |
| Deployment register | Engineer | Informed — engineers own their deployments |

**The single most valuable contribution you can make:**
Document an unwritten rule as a standard. Every domain has norms that
exist in practice but aren't written down. They govern how things are
built, they are enforced in reviews, but they are invisible to governance,
audit, and anyone new. Write it down. Use the template. Start as a draft.

---

## Standards — how they get written

Standards are triggered by operational reality. PA does not speculatively
produce standards. Valid triggers:

- An unwritten rule surfaced via peer review or the forum
- A deviation being raised repeatedly — signals a missing rule
- A new platform introducing undocumented configuration norms
- A cross-domain risk that exposes a boundary gap

**To write a standard:**
1. Copy `standards/STANDARD-TEMPLATE.yaml` to the right domain folder
2. Populate `operational_owner` — this must be you or a named peer.
   Without a named owner a standard has no one to flag when it drifts
   from reality. It becomes a dead document.
3. Set `trigger` — why does this standard exist?
4. Set `co_reviewed_by` if the standard intersects another domain
5. Write the rules using MUST / MUST NOT. Include rationale for each.
   A rule without rationale is an assertion. Rationale is what makes it stick.
6. Status `draft` is fine — raise a PR. PA reviews and approves.

**Operational owner drift obligation:**
PA does not certify every standard annually. The `operational_owner`
flags drift via the operational feedback channel when reality diverges.
If you are the operational_owner — you are the person who keeps it honest.

---

## Patterns — two sources, one gate

A pattern is an approved way of assembling SBBs into a working solution.
The AND rule: if it takes "and" to describe it, it is a pattern.

**Architecture-initiated:** PA defines what correct looks like before
engineers start. Prevents artistic licence in topology assembly.

**Engineering-initiated:** CSD or engineers solve the same problem the
same way repeatedly. Document it. Raise it as a PR. PA reviews and
codifies it as an approved pattern.

Source does not matter. PA approval is the gate. Copy
`patterns/PATTERN-TEMPLATE.yaml` to start.

For guidance on Pattern vs SBB, see `patterns/PATTERN-VS-SBB-GUIDANCE.md`.

---

## Artefact lifecycle

Every ABB, SBB, VSBB, ZBB, and pattern has a lifecycle status.
Understanding this is essential for governance and the availability heatmap.

| Status | Meaning | Action required |
|---|---|---|
| `draft` | Being developed. Not approved for self-certification. | PA review needed before use. |
| `active` | Approved. Current version. Self-certification permitted. | None — use it. |
| `drift` | Deployment exists on a prior version. Approved but not current. | Remediation plan required. No new deployments on this version. |
| `deprecated` | Superseded by a newer version. Existing deployments tolerated. | Migrate to active version. No new deployments. |
| `end-of-life` | Vendor or platform EOL. Deployments at operational risk. | Urgent remediation. GCB3 must be informed. |
| `restricted` | Permitted in existing estate only. No new deployments under any circumstances. | Do not deploy. If encountered, raise operational feedback. |

**Version lifecycle triggers:**

When a new SBB version is published:
- All existing deployments move to `drift` status in the deployment register
- CSD updates the deployment register within 5 working days
- No new deployments on the old version from publication date
- Remediation timeline agreed with PO at the next forum

When a vendor declares EOL for a platform:
- Operational feedback raised immediately
- PA assesses and updates the VSBB and SBB status
- NC availability heatmap updated
- GCB3 informed — EOL is a DORA operational resilience risk
- Remediation programme raised if not already in flight

**The lifecycle and the heatmap:**
NC availability heatmap `technical.status` values are driven by this
lifecycle model. `drift` and `end-of-life` in the heatmap mean a deployment
at that site is behind the approved version or on EOL hardware.
This is a governance finding, not just an ops note.

---

## The Arch/Eng Forum

Two threads. Know which one you need before you come.

### Thread 1 — Socialise

Comment and feedback within the domain. No approval. No endorsement.
Use it for designs being worked through, standards needing revisiting,
capabilities with no SBB yet, or engineering-initiated patterns to socialise.

**PO and GCB3 do not attend Thread 1.** Forum integrity requires
management chain separation. Engineers self-censor otherwise.

### Thread 2 — Endorsement

Bring something for PA to review and endorse to proceed to review groups
or Design Authority. Formal step. Formal output:
**Endorsed / Endorsed with conditions / Not endorsed.**

**What you must bring:**
1. Solution design or options paper
2. Completed topology conformance self-assessment (TC-01/02/03)
3. Documented deviations — named before the meeting, not discovered in it
4. Which review stage you are targeting next

---

## How to route your solution

```
Does an approved Service Blueprint (SVC-XXX) cover this?
    YES → Consume via ITSM. No design needed.
    NO  ↓

Does an approved Pattern cover this?
    YES → Complete topology conformance self-assessment.
          All three checks pass?
              YES → Self-certify in PR → Solution Design Forum
              NO  → Deviation path (see below)
    NO  ↓

Wholly new — no ABB/SBB coverage?
    YES → Raise an Options Paper Request Issue. Do not design yet.
          PA triages. Options paper before any design work begins.
```

---

## Topology conformance self-assessment

Three questions. All must be YES before raising a Pull Request.

**TC-01 — Components**
Are all platforms approved VSBBs in the vendor catalogue?
→ Check `governance/approved-vendor-list.yaml`

**TC-02 — Traffic flows match ZBB boundary contract**
Do all traffic flows trace to a named rule in the ZBB boundary contract?
Does the path traffic takes match the enforcement model?
Is every inline component named as an enforcement point?

> Example failure: Server return traffic transiting a firewall not named
> as an enforcement point in ZBB-APP-001's boundary contract. F5 and
> Checkpoint are both approved VSBBs. The topology is non-compliant
> because the routing path does not match the boundary contract.
> Approved components assembled incorrectly is the risk this check catches.

**TC-03 — No undocumented flows**
Can every traffic path be traced to a ZBB rule or an approved pattern?

| Result | Action |
|---|---|
| All three YES | Self-certify in PR → Solution Design Forum |
| Any NO | Raise Deviation Request Issue before PR or forum |

---

## Change management — CAB integration

Architecture governance and change management are complementary processes.
Neither replaces the other.

```
Governance record        Answers: is this the right thing to build?
                         Is the topology compliant? Who approved the architecture?

Change record (CR)       Answers: when is it being built?
                         Who is doing the work? What is the rollback plan?
                         Has the CAB approved the change window?
```

**The required linkage:**

Every implementation of a governed solution must have a CR that references
the governance record. Every governance record should reference the CR
once it is raised.

| Governance record type | What to reference in the CR |
|---|---|
| Self-certified PR (compliant, TC pass) | PR number |
| Endorsed deviation | Deviation Issue number + PA endorsement date |
| DA-approved decision | DEC-XXX record ID |
| Options paper outcome | OP-XXX record ID |

**The CR does not substitute for governance approval.**
A CR can be raised before or after governance approval — but implementation
cannot proceed without both. A CAB-approved CR with no governance record
is an implementation outside the framework. PA must be informed.

**The POC / Pilot / Pilot-to-Production process:**
The onboarding, proof-of-concept, and pilot process is documented in
Confluence. Link: [TODO — add Confluence page URL when available]

All PoC and pilot work operates within the governance framework.
A PoC does not exempt a solution from topology conformance or the
deviation path. Pilots that reveal new capability requirements feed
into demand signals (DEMAND-XXX) and options papers (OP-XXX).

---

## Deviation lifecycle

A deviation is not closed when it is approved. It is closed when
it is remediated. Tracking open deviations to closure is a shared
accountability.

**Deviation lifecycle stages:**

```
Raised          Deviation Request Issue opened.
                status: awaiting-pa

Endorsed        PA endorses (possibly with conditions).
                status: awaiting-da → status: remediation-open

Approved        DA registers or PA approves at ARG.
                Remediation date set. Accountability recorded.
                status: remediation-open

Remediated      Implementation updated to remove the deviation.
                Retrospective TC-01/02/03 pass confirmed.
                Deviation Issue closed.
                Deployment register updated.

Missed date     Remediation date passes without closure.
                See escalation below.
```

**Escalation when a remediation date is missed:**

| Days overdue | Action | Who |
|---|---|---|
| 0–10 | PA contacts engineer and PO directly | PA |
| 10–20 | PO formally notified — written acknowledgement required | PA → PO |
| 20+ | GCB3 informed — becomes a programme-level finding | PA → GCB3 |
| Regulatory scope | Immediate GCB3 notification regardless of age | PA |

Open deviations with missed dates and regulatory scope (PCI-DSS, DORA,
PRA) are not just governance findings — they are potential regulatory
findings. GCB3 must be informed without waiting for the 20-day threshold.

**Deviation register:**
The deviation register is maintained via GitHub Issues with the
`type:deviation` label and tracked in `governance/metrics.yaml`
(quarterly). The `status:remediation-open` label identifies open items.


---

## Cross-framework linkages and the Control Owner

Network architecture artefacts (ZBBs, SBBs, Patterns) are linked to
stakeholder artefacts — Security Architecture policies, Risk/GRC controls
in Archer, Compliance standards — via XLINK records in `governance/xlinks/`.

**TBC/Control Owner** appears throughout the framework where a named
individual from a stakeholder organisation must formally engage.
Until they do, the linkage is incomplete — and that is the stakeholder's
finding, not the network team's.

**The accountability boundary:**

| Network Architecture owns | Stakeholder organisations own |
|---|---|
| Technical implementation | Policy and control definition |
| ZBB boundary contract | Enforcement policy and rule sets |
| Firewall insertion point | Firewall rules |
| Traffic flow model | Permitted flows policy |
| XLINK record creation and quarterly review | Co-sign and version change notification |

**What the network team does NOT do:**
- Interpret security policy
- Resolve conflicts between Security Architecture and Security Ops
- Implement requirements not formally agreed in a boundary contract
- Fill gaps left by stakeholder internal coordination failures

**When Security Architecture and Security Ops conflict:**
Document it. Raise CONF-F. Pause implementation on the affected scope.
Do not choose between the two positions. This is their conflict to resolve.

**When a Control Owner cannot be identified:**
PA pursues for 10 working days. Then escalates to the stakeholder
GCB3-equivalent. The outstanding finding is documented against the
stakeholder, not the network team.

**Quarterly XLINK review:**
PA reviews all XLINK records each quarter. For each record:
- Has the stakeholder artefact been superseded?
- If yes and no assessment has been done: raise CONF-G finding against stakeholder.
- If Control Owner has not responded to a notification: escalate.

See `governance/xlinks/` for all records.
See `governance/role-card-control-owner.md` for the Control Owner role.



---

## Domain taxonomy

Six domains. Plain English. No acronyms.
See `governance/domain-taxonomy.yaml` for full definitions and boundary cases.

| Domain | What's in it | What's NOT in it |
|---|---|---|
| `wan` | SD-WAN, BGP, WAN circuit design | The MPLS circuit itself → transport |
| `data-centre` | Leaf-spine fabric, VXLAN/EVPN, zone segmentation | Firewalls → security |
| `security` | Firewalls, WAF, DDoS, SSL inspection | Policy and rule sets → Cyber Architecture |
| `services` | NLB, GSLB, proxy, VPN, DNS, NTP, syslog, OOB | The routing protocols → wan/dc |
| `campus` | Access switching, wireless | Distribution and core → data-centre |
| `transport` | ISP circuits, MPLS, fibre, DWDM, 4G/5G, satellite, cabling | What runs on it → wan |

**The key boundary: transport = the medium. WAN = what you build on it.**

ABB IDs retain original prefixes (OVL/VPN/DDI/OBS/MGT) for backward
compatibility. The `domain` field is now `services` for all of them.



---

## Governance relationship — PA and GCB3

PA and GCB3 operate as peers at director level.

**PA governs the framework. GCB3 owns the delivery organisation.**

PA's escalation path for all non-compliance is GCB3 — not individual
engineers, CSDs, or SMEs. GCB3 delegates to their teams and is
accountable for those teams following the framework.

```
Non-compliant deployment?      PA → GCB3 → GCB3 manages their engineer
Options paper not actioned?    PA → GCB3 → GCB3 directs their SME
Deployment record unsigned?    PA → GCB3 → GCB3 directs their PO/ICL
Deviation not raised?          PA → GCB3 → GCB3 manages their team member
```

PA does not chase, direct, or manage the execution layer.
PA is accessible for guidance — Thread 1, direct queries, framework questions.
PA escalates non-compliance to GCB3.

---

## Deployment sign-off — two-in-the-box (DP-13)

Every deployment at a specific site requires confirmation from two
named individuals before the deployment register record is complete:

**Product Owner** — confirms the capability delivered matches the business
requirement. Any departures from standard resilience have been accepted.

**In-Country Lead** — confirms the physical implementation is correct
for that site. Circuits, zone placement, cabling, and local regulatory
requirements are met.

Neither can sign off alone. An incomplete record is a governance finding
against the unsigned party.

See `governance/raci.yaml` DP-13 · `role-card-po.md` · `role-card-icl.md`

---

## Options papers — two types

**DP-05 — New capability** (no existing ABB/SBB covers the requirement)
  Trigger: PA, CSD, or ENG identify the gap.
  GCB3 reviews and **approves**. PA owns the record.
  No design work before the options paper is approved.

**DP-06 — Tech debt, EOL platform, or operational consequence**
  Trigger: SME, ENG, CSD, or OPS — they see the problem first.
  Three separate accountabilities:
    PA: owns the governance record
    GCB3: accountable for the decision (their estate, their resources)
    PO: accountable for accepting the business consequence
  SME/ENG/CSD/OPS: produce the assessment, do the remediation work.
  GCB3 and PO must both accept the outcome in writing.

**DA is informed via the register — not on the critical path.**
The deviation register and options paper register are the DA
notification mechanism. DA reviews the register quarterly (DP-17).

## Departures from standard resilience

Every NC has a standard delivery model — the resilience the architecture
requires for that capability. When a programme cannot fund the standard
model, this is a **departure from standard**, not an exception.

The departure record (RES-XXX) contains two sections:

**Plain language** (for Product Owner and In-Country Lead):
- What the standard delivery looks like
- What this deployment provides instead
- What the business experiences if the departure scenario occurs

**Tier notation** (for the resilience team and audit):
- Standard tier and deployed tier
- Gap assessment
- DORA/PCI implications if applicable

Both audiences need both sections. Do not remove either.

---

## OS and firmware versions — what architecture governs

**Architecture governs features and where they are — not OS patch level.**

This principle affects how the deployment register is used and when
PA involvement is required for infrastructure changes.

**Not an architecture concern:**
- Site A running NX-OS 9.3(7) while Site B runs NX-OS 9.3(8)
- Minor patch increments within the same major version
- Security patching that does not change feature behaviour
- OS version alignment between sites

These are operational concerns owned by the security patching
and operations teams. They do not appear in the deployment register
as governance findings.

**An architecture concern:**
- OS upgraded beyond the IMPL/VSBB's `tested_os_versions` range
- Release notes confirm a `feature_dependency` is affected
- The config template produces different feature state on the new OS

When any of these occur, `vsbb_os_compatible` in the deployment register
moves to `needs-review`. PA assesses whether the feature contract is
still met. This is the governance signal — not the version number.

**The deployment register records:**
```
vsbb_ref:              Which config template — architecture governs this
vsbb_version:          Which template version — architecture governs this
os_version_at_deploy:  What OS was running — operational record only
vsbb_os_compatible:    Is the OS within tested range? — governance signal
```

`os_version_at_deploy` is informational. `vsbb_os_compatible` is the
field that matters for governance.

---

## Variable governance (forward-looking)

When contributing a VSBB or reviewing a variable file, be aware of
the variable governance straw man at `docs/variable-governance-strawman.md`.

The key principle today (Phase 1 — no tooling required):

> If changing a variable value would violate a TC-02 constraint,
> a ZBB boundary contract, or a regulatory control — it is a
> **Type 1 architectural variable**. Changing it is a deviation,
> not an operational decision.

The clearest example: `redistribute_default_route`. Changing this
from `deny` to `permit` in an EIGRP-to-BGP redistribution is a
ZBB boundary contract event — not a routing policy tweak.
See the straw man for the full list of governance-relevant variables
and the debate questions for Phase 2 and 3 investment.


---

## Operational resilience and deployment tiers

Every production deployment has a resilience tier. That tier is a
programme decision — not a network team decision. The network team
defines what is technically possible. The programme chooses what
to fund. The framework records the choice and who owns the risk.

**Four tiers** — see `governance/resilience-tiers.yaml` for full definitions:

| Tier | Description | Minimum for |
|---|---|---|
| N | Single instance, no redundancy | Non-production only |
| N+1 | Active + standby, single site | Standard production minimum |
| 2(N+1) | Dual active/active pairs | Trading, payment, DORA critical |
| 2N | Dual independent stacks, no shared components | DORA critical <1hr RTO, PCI CDE |

**How the tier is set:**

Every ABB defines a `minimum_resilience_tier` and a `recommended_resilience_tier`.
The programme selects the deployed tier. The deployment register records it.

**When the programme cannot fund the minimum tier:**

A Resilience Exception (RES-XXX) must be raised. This is the pre-state for
formal risk register submission.

1. Raise a Resilience Exception Request Issue
2. PA creates a RES-XXX record documenting the gap and regulatory consequence
3. Named risk owner accepts in writing — programme sponsor or GCB3
4. GCB3 informed where: production N-tier, or any DORA/PCI-scoped workload
5. RES-XXX submitted to risk register with this record as source
6. Remediation plan and target date recorded — quarterly review until closed

**Why this matters:**

The network team does not silently absorb a funding compromise as an
architectural decision. If a failure occurs on an under-resilient system,
the RES-XXX record is the evidence that the risk was known, documented,
and accepted — not that the network team made a poor design choice.

**RTO/RPO:**
RTO and RPO mapping to resilience tiers is a separate roadmap programme
(Q3/Q4 2025). Until it delivers, indicative values in resilience-tiers.yaml
must not be used as formal commitments.

---

## RACI summary

Full RACI in `governance/raci.html` and `governance/raci.yaml`.

| Solution type | Route | Accountable |
|---|---|---|
| Approved service exists | Consume via ITSM | — |
| Approved VSBBs + TC pass | PR self-cert → Solution Design Forum | CSD / ENG (PA audits sample) |
| Documented deviation | Thread 2 → Review Group | PA — always |
| Wholly new capability | Options paper → Thread 2 → DA | PA — always |
| Cross-domain risk | Consult domain owner before forum concludes | PA — always |
| NC record — create or update | PA drafts, CSD maintains heatmap | PA — always |
| Artefact lifecycle change | Operational feedback → PA assesses | PA — always |

**DP-02 is self-service.** PA does not approve every compliant solution.
The topology conformance self-certification IS the approval.
PA audits a sample (minimum 20%) each quarter and reviews metrics for
systemic drift. A false self-certification is a governance finding
against the submitter.

---

## I've already built something — what now?

**Step 1** — Run TC-01/02/03 against what exists.

**Step 2** — All pass: raise a retrospective PR with self-certification.
Note it is a retrospective submission. PA not in critical path.

**Step 3** — Any fail: raise a Deviation Request Issue before the PR.
Document what was built, which check failed, the risk, and the
proposed remediation with a target date.

**Step 4** — Cross-domain risk: peer review stops until the domain
owner is consulted. Not optional.

**Step 5** — Already in production: retrospective deviation + remediation
plan + target date. Governance finding tracked until closed.
If PCI/DORA scope: GCB3 informed immediately.

**The framework is not punitive.** A documented retrospective deviation
with a remediation plan is a better outcome than an undocumented risk.

---

## Cross-domain risk

If your solution introduces risk outside the network domain, that domain
must be consulted before any review can conclude.

Common boundaries:
- **Cyber** — firewall policy, WAF, SSL inspection, ZBB boundary enforcement
- **Identity** — Conditional Access, MFA, device compliance
- **Application** — application-layer routing, health endpoints
- **DC Facilities** — physical cabling, power, cooling

---

## Questions

Raise a GitHub Issue with the label `type:question` or contact PA directly.

For PoC / Pilot process: [TODO — Confluence link]
For CAB process: [TODO — Confluence link]
