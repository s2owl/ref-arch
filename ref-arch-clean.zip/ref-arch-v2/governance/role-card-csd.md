# Role Card — CSD (Connectivity Solution Designer)

> Your part in the governance process.
> One page. Keep it visible.

---

## Who you are

You are a Connectivity Solution Designer — a cross-platform network
generalist in the networks organisation. You understand how platforms
interact across the estate: how an F5 sits in front of a Checkpoint
in front of an ACI fabric. You build and deliver solutions, not
just individual platform components.

You are in the **delivery chain** — reporting to your director under
the Networks MD. You are not in the governance chain. PA governs
your work the same way PA governs any delivery team's work — through
the process, not alongside it. You do not hold governance
accountability. You are accountable for your own execution.

---

## What you produce

| Artefact | Your role |
|---|---|
| Solutions using approved VSBBs | Build and deliver — self-certify TC compliance in PR |
| SBBs | Produce — PA reviews against ABB capability gates |
| VSBBs | Produce — PA reviews against SBB capability gates |
| Engineering-initiated patterns | Initiate — PA codifies and approves |
| Topology conformance self-assessment | Own — your professional obligation |
| Deployment register entries | Own — every deployment you make |

---

## The topology conformance self-assessment

Your most important pre-submission check. Three questions.
All three must be YES before raising a Pull Request.

**TC-01** Are all platforms approved VSBBs in the vendor catalogue?

**TC-02** Do all traffic flows trace to a named rule in the ZBB
boundary contract for the zones involved? Does the path match the
enforcement model? Is every inline component named as an enforcement point?

**TC-03** Can every traffic path be traced to a ZBB rule or approved
pattern? If you cannot point to a rule for a flow — it is undocumented.

| All three YES | Self-certify in PR. No PA approval needed. |
| Any NO | Raise a Deviation Request Issue before the PR. |

PA audits a sample of self-certified PRs each quarter. A false
self-certification — claiming TC pass when a topology violation
exists — is a governance finding against you personally.

---

## The Arch/Eng Forum

**Thread 1 — Socialise**
Bring work in progress for peer comment. Use it when you are
working through a design, have an engineering-initiated pattern
to socialise, or want PA input before committing to a topology.
Getting input early in Thread 1 is far better than arriving at
Thread 2 with an undocumented deviation.

**Thread 2 — Endorsement**
When your solution needs PA endorsement to proceed to review groups
or Design Authority. Bring: the design, completed TC assessment,
documented deviations named before the meeting, and your target
review stage.

---

## Producing SBBs and VSBBs

You produce SBBs and VSBBs because you know the platform deeply.
PA reviews against capability gates, not platform detail.

1. Copy the relevant template from `sbbs/` or the vendor config repo
2. Populate `operational_owner` — you. You flag drift when reality changes.
3. Set `source: engineering-initiated` on any pattern you initiate
4. Raise a PR. PA reviews and approves.

---

## Raising an engineering-initiated pattern

If you solve the same problem the same way three times — document it.
That repeated solution is a pattern. Raise it in `patterns/`.
PA reviews, confirms it passes the AND rule, defines the TC-02
topology constraints, and approves it. Once approved, the whole
delivery team can self-certify against it.

This is one of the most valuable contributions CSD makes — turning
operational experience into approved governance.

---

## Man-marking project leads

When a domain has high artistic licence risk or delivery pressure,
a project lead may be embedded in the delivery team. Contract,
domain-targeted, time-limited. Triggered by deviation concentration
data from the quarterly metrics. They provide senior technical
assurance within delivery — they work alongside you, not above you.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Topology deviation — before building | `deviation-request.yaml` |
| Need Thread 2 endorsement | `endorsement-request.yaml` |
| New capability needed | `options-paper-request.yaml` |
| Standard or pattern wrong in practice | `operational-feedback.yaml` |
| Already built without prior engagement | Recovery path in CONTRIBUTING.md |

---

## The rule you must never break

> Run TC-01, TC-02, TC-03 before raising a Pull Request.
> Raise a Deviation Request Issue if any check fails — before building, not after.
> A deviation in production with no record is a governance finding against you.

---

*See CONTRIBUTING.md for full guidance · ref-arch*
