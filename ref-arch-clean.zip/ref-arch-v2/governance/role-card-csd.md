# Role Card — CSD (Connectivity Solution Designer)

> Your part in the governance process.
> One page. Keep it visible.

---

## Who you are

You are a Connectivity Solution Designer — a cross-platform network
generalist in the networks organisation.

The catalogue (NC-XXX / SVC-XXX / VSBB) defines everything that can be deployed
without you. Your job is **net-new design only** — what the catalogue cannot yet
cover. Every VSBB you produce, every pattern you initiate, every SBB you document
grows the catalogue and reduces the volume of snowflakes reaching you.

The measure of your impact is not how many deployments you touch —
it is how much of the estate the catalogue can deliver without you. You understand how platforms
interact across the estate: how an F5 sits in front of a Checkpoint
in front of an ACI fabric. You build and deliver solutions, not
just individual platform components.

You are in the **delivery chain** — reporting to your director under
the Networks MD. You are not in the governance chain. PA governs
your work the same way PA governs any delivery team's work — through
the process, not alongside it. You do not hold governance
accountability. You are accountable for your own execution.

---

## What you produce

| Artefact | Your role |
|---|---|
| Solutions using approved VSBBs | Build and deliver — self-certify TC compliance in PR |
| SBBs | Produce — PA reviews against ABB capability gates |
| VSBBs | Produce — PA reviews against SBB capability gates |
| Engineering-initiated patterns | Initiate — PA codifies and approves |
| Topology conformance self-assessment | Own — your professional obligation |
| Deployment register entries | Own — every deployment you make |

---

## The topology conformance self-assessment

Your most important pre-submission check. Three questions.
All three must be YES before raising a Pull Request.

**TC-01** Are all platforms approved VSBBs in the vendor catalogue?

**TC-02** Do all traffic flows trace to a named rule in the ZBB
boundary contract for the zones involved? Does the path match the
enforcement model? Is every inline component named as an enforcement point?

**TC-03** Can every traffic path be traced to a ZBB rule or approved
pattern? If you cannot point to a rule for a flow — it is undocumented.

| All three YES | Self-certify in PR. No PA approval needed. |
| Any NO | Raise a Deviation Request Issue before the PR. |

PA audits a sample of self-certified PRs each quarter. A false
self-certification — claiming TC pass when a topology violation
exists — is a governance finding against you personally.

---

## The Arch/Eng Forum

**Thread 1 — Socialise**
Bring work in progress for peer comment. Use it when you are
working through a design, have an engineering-initiated pattern
to socialise, or want PA input before committing to a topology.
Getting input early in Thread 1 is far better than arriving at
Thread 2 with an undocumented deviation.

**Thread 2 — Endorsement**
When your solution needs PA endorsement to proceed to review groups
or Design Authority. Bring: the design, completed TC assessment,
documented deviations named before the meeting, and your target
review stage.

---

## HLD and LLD

If you are used to producing HLD and LLD documents — the framework
maps these directly onto artefacts you already work with:

```
HLD  →  Pattern (PAT-XXX)
         If a pattern covers your requirement, the HLD is
         already written. You do not produce a new one.
         You self-certify against it.

LLD  →  VSBB + variable file
         The VSBB is the config template (the LLD structure).
         The variable file is the instance-specific values
         (the LLD content for that device).
```

For the full explanation of why this is better than Word documents
and exactly what to do in each situation — read:
`docs/csd-hld-lld-guidance.md`



You produce SBBs and VSBBs because you know the platform deeply.
PA reviews against capability gates, not platform detail.

1. Copy the relevant template from `sbbs/` or the vendor config repo
2. Populate `operational_owner` — you. You flag drift when reality changes.
3. Set `source: engineering-initiated` on any pattern you initiate
4. Raise a PR. PA reviews and approves.

---

## Raising an engineering-initiated pattern

If you solve the same problem the same way three times — document it.
That repeated solution is a pattern. Raise it in `patterns/`.
PA reviews, confirms it passes the AND rule, defines the TC-02
topology constraints, and approves it. Once approved, the whole
delivery team can self-certify against it.

This is one of the most valuable contributions CSD makes — turning
operational experience into approved governance.

---



## Vendor evidence records — VER-XXX

When reviewing a deployment that looks asymmetric — more hosts at one
site than another — check before flagging it as a resilience concern:

```
Is there a vendor_evidence_ref on the deployment register entry?
    YES → VER-XXX exists. Vendor best practice. Not a finding.
          Check the VER-XXX to confirm it covers the deployed version.
    NO  → Check resilience_exception_ref.
          If no RES-XXX either: this needs assessment.
          Raise via Thread 1.
```

The F5 GTM 2+1 sync group (VER-001) is the clearest example.
Two GTMs at Site A, one at Site B looks asymmetric. It is — by design.
A single GTM can sustain full DNS service. VER-001 is the evidence.


## Deployment sign-off — DP-13

You **create the technical deployment record**. You populate the
VSBB reference, OS version, resilience fields, and departure record
reference. The record is not complete until the Product Owner and
In-Country Lead have both confirmed it.

Do not mark a deployment record as complete on their behalf.
An incomplete record (one signed, one blank) is a governance finding.

If the departure_from_standard fields need populating — that means
a departure from the standard resilience model is being recorded.
Raise the RES-XXX departure record via the Issue template first.

## Stakeholder linkages — what this means for you

Some ZBBs and patterns you work with have a cross-framework linkage
(XLINK-XXX) to a Security Architecture policy or Risk/GRC control.

Where you see `co_reviewed_by: TBC/Control Owner` in a ZBB or pattern
— that linkage is incomplete. PA is pursuing the Control Owner.
This does not block your work on compliant solutions.
It does mean the ZBB boundary contract has not yet been formally
co-signed by Security Architecture.

If Security Operations or Security Engineering give you direction
that contradicts a ZBB boundary contract — do not implement it.
Raise this with PA. This is CONF-F territory.
The network team does not resolve Security's internal conflicts.

## Man-marking project leads

When a domain has high artistic licence risk or delivery pressure,
a project lead may be embedded in the delivery team. Contract,
domain-targeted, time-limited. Triggered by deviation concentration
data from the quarterly metrics. They provide senior technical
assurance within delivery — they work alongside you, not above you.


---


## Pattern ownership — your operational accountability (Model B)

Patterns are co-owned under a two-layer model:

```
PA              Governance accountability
                Is the pattern architecturally correct?
                Does it meet the ABB capability contract?
                Does the AND rule still hold?
                Approves all changes.

SME / CSD       Operational accuracy (operational_owner field)
(you)           Is the pattern technically current?
                Do tested versions reflect estate reality?
                Have platform behaviours changed?
                Are feature dependencies still correct?
```

**When you are the operational_owner of a pattern:**

You are notified:
- When a new RES-XXX departure record references the pattern
- When departure_count reaches the pattern's threshold
- When a version change is proposed

Your obligation:
- Confirm the pattern is technically accurate before PA approves a version change
- Raise operational feedback (DP-10/11) when the pattern drifts from reality
- Do not silently accumulate departures — if the same component keeps being
  departed from, the pattern may need updating

**The departure feedback loop:**

```
RES-XXX raised against PAT-SVC-001
  → PA notified
  → operational_owner notified
  → departure_count updated
  → if departure_count reaches threshold:
      PA reviews for DP-05/DP-06
      PA notifies PO
      You (operational_owner) produce the assessment
```

**Pattern version changes:**

When PA approves a pattern version change, you confirm the
technical accuracy. PA notifies:
- All POs whose NC refs the pattern
- All ICLs who have deployments against the previous version
- Any open RES-XXX departures are reviewed — does the version
  change resolve them or create new ones?

---

## Receiving a Front Door snowflake

When Front Door routes a snowflake to you, you receive:
- An FD-XXX GitHub Issue with the full design brief
- The requester's plain language request (their words)
- The closest NC/SVC match and the specific gap
- Any business funding constraints already identified

**Your obligations when picking up an FD-XXX:**

1. Confirm receipt — update the FD-XXX record so Front Door knows you have it
2. Design against the full approved pattern (PAT-XXX) — always
3. If the business cannot fund a component → flag to PA immediately.
   Do not design around it silently. PA raises the RES-XXX departure record.
   You reference it. You do not create a second design.
4. Update the FD-XXX record as work progresses — when you submit the PR,
   when a departure record is raised, when deployment is confirmed
5. Before closing the deployment — confirm all downstream refs are in
   the FD-XXX record (PR, DEV, RES, DEP). Front Door closes the record.

The FD-XXX record is not yours to close — it is the Front Door team's record.
Your job is to keep it accurate so they can close it cleanly.

---

## New capability → PA notification before deployment (DP-19)

If what you are designing is not currently in the NC catalogue or Service
Blueprint register — you are delivering a new capability from a snowflake.

**Before submitting the deployment record:**

Notify PA. The obligation is:

> "This design delivers a capability not currently in the NC/SVC catalogue.
> PO notification is required before deployment proceeds."

PA ensures the PO is notified and records their disposition (own / one-off /
escalate to options paper). Deployment does not proceed until the PO
disposition is recorded in the FD-XXX record.

Do not submit a deployment record for a new capability without PA notification.
A deployment record submitted without PO disposition is a governance finding.

---

## Business funding departure — one template, one design (DP-20)

When the business cannot fund all components of the approved pattern:

**What you do:**
1. Design against the **full approved pattern** — always
2. Reference the RES-XXX departure record that PA has raised
3. That is all — there is one design

**What you do NOT do:**
- Create a second "funded version" design
- Document what was cut out in the design itself
- Call it a deviation — it is a business funding departure

The pattern is the single template. The departure record is the rationale.
One design to maintain. When the pattern updates — one thing changes.

```
Wrong:  PAT-SVC-001 full design
        PAT-SVC-001 variant (no Intune) — your design
        Two things to maintain. Drift guaranteed.

Correct: PAT-SVC-001 full design — your design
         RES-VAT-001 — "Intune not funded for this deployment"
         One thing to maintain.
```

---

## DP-06 — your obligation to raise tech debt and operational gaps

DP-06 (options paper — tech debt, EOL platform, or operational consequence)
is triggered by the execution layer. That includes you.

**You are obligated to raise DP-06 when you see:**
- A platform approaching or past end-of-life
- A persistent operational gap the framework does not address
- A recurring workaround that signals a missing capability
- A deviation pattern that should be addressed at architecture level

How to raise it:
1. Use the `options-paper-request.yaml` GitHub Issue template
2. Describe the problem specifically — what platform, what gap, what consequence
3. PA owns the governance record
4. You do the assessment work and present the options

This is not optional. If you see a platform going EOL and do not raise it,
the finding will eventually land on you. Raising it formally protects you —
it puts the decision at the right level (GCB3 and PO) rather than leaving
it as an undocumented operational risk.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Received snowflake from Front Door | FD-XXX Issue already exists — update it |
| Topology deviation — before building | `deviation-request.yaml` |
| Need Thread 2 endorsement | `endorsement-request.yaml` |
| New capability — PO notification needed | `options-paper-request.yaml` |
| Tech debt or operational gap | `options-paper-request.yaml` (DP-06) |
| Standard or pattern wrong in practice | `operational-feedback.yaml` |
| Already built without prior engagement | Recovery path in CONTRIBUTING.md |

---

## The rule you must never break

> Run TC-01, TC-02, TC-03 before raising a Pull Request.
> Raise a Deviation Request Issue if any check fails — before building, not after.
> A deviation in production with no record is a governance finding against you.

---

*See CONTRIBUTING.md for full guidance · ref-arch*
