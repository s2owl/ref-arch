# Role Card — Product Owner

> Your part in the governance process.
> One page. Keep it visible.

---

<!-- BOTTOM LINE UP FRONT
  You are accountable for the business outcome — not the technical detail.
  For compliant solutions: you are informed. PA is not in your critical path.
  For deviations: you acknowledge risk in writing.
  For departures from standard resilience: you may be the named accepting party.
  For deployment sign-off: you and the In-Country Lead both confirm — two-in-the-box.
  Never instruct your engineer to skip TC checks or bypass the forum.
-->

## Who you are

You own a network capability on behalf of the business — Remote Working,
Internet Access, Site Connectivity, or similar. You represent the business
requirement. You are accountable that what is delivered matches what was
needed, at the right site, for the right users and workloads.

You do not need to understand VLANs, BGP, or resilience tier notation.
You do need to understand when a deployment departs from the standard
and what that means for the business.

---

## Your accountability

| Decision point | Your role |
|---|---|
| Compliant solution, no deviations | Informed only |
| Solution has deviations | Consulted — acknowledge deviation and accept risk in writing |
| Departure from standard resilience | Named accepting party — you and In-Country Lead |
| New capability | Consulted — articulate the business need |
| **Deployment record** | **R/A — two-in-the-box with In-Country Lead** |

---

## Deployment sign-off — two-in-the-box

When a capability is deployed at a specific site, two people must
confirm the deployment record is complete and correct:

**You (Product Owner)** confirm:
- The capability delivered matches the business requirement
- The scope, users, and workloads served are correct
- Any departures from standard delivery have been accepted

**The In-Country Lead** confirms:
- The implementation is correct for that specific site
- Physical installation, circuit connectivity, and zone placement
  are correct for the local environment
- The local network is in the expected state

Neither of you can sign off alone. Both fields must be populated
in the deployment register before the record is considered complete.
An incomplete record — one signed, one blank — is a governance finding.

---

## Departures from standard resilience

Every network capability has a standard delivery model — the way
it is normally built, with the resilience the architecture requires.

When a programme cannot fund the standard model, this is recorded
as a **departure from standard**. You will be asked:

> "The standard way we deliver [capability] includes [plain language
> description of standard resilience]. Your programme is funding
> [what is actually being built]. We need you to confirm you accept
> that this is less than the standard."

You do not need to understand tier notation. The plain language
description tells you what you are accepting. Your written acceptance
goes into the departure record. The record also contains the technical
tier notation for the resilience team — but that is not your concern.

For DORA-scoped or PCI-scoped capabilities: GCB3 is also informed.
Your acceptance does not remove the regulatory dimension.

---

## Deviations — what acknowledging means

When your engineer's solution deviates from an approved pattern:

> "Do you accept this risk on behalf of the capability?"

This creates a clean audit trail. PA approved on architecture grounds.
You accepted on business grounds. Neither can later claim ignorance.

Disagreement with the classification → conversation with PA.
Not an instruction to your engineer to proceed without the process.

---

## What you must not do

- **Do not instruct your engineer to skip TC checks or bypass the forum.**
  That is a governance finding. PA will escalate.

- **Do not suppress operational feedback** raised by your team.
  The feedback channel runs directly to architecture governance.

- **Do not attend Thread 1 of the Arch/Eng Forum.**
  Management presence causes engineers to self-censor.
  Thread 1 integrity requires your absence.

---

*See governance/conflict-resolution.yaml · governance/resilience-tiers.html · ref-arch*
