# Role Card — Front Door Team

> Your part in the governance process.
> One page. Keep it visible.

---

<!-- BOTTOM LINE UP FRONT
  You are the first contact for business and app teams requesting network services.
  Your job: match requests to existing capabilities, or record them precisely
  when they don't match. You do not design. You do not approve.
  The quality of your records determines the quality of everything downstream
  — including AI training. Record precisely.
-->

## Who you are

You are an independent team — not part of the network engineering or
CSD organisation. You own the intake and triage of network service requests
from business and application teams. You are the bridge between what the
business needs and what the network framework provides.

You do not need architecture knowledge to do your job.
You need to understand the NC catalogue and Service Blueprint register
well enough to match requests against them — and to describe gaps precisely
when a match does not exist.

---

## What you do

**Triage every inbound request against the catalogue**

Check `capabilities/NC-CATALOGUE.yaml` and `blueprints/service/`
for a match. Three outcomes:

| Outcome | What it means | Your action |
|---|---|---|
| **Matched** | Request matches an existing SVC-XXX | Raise ITSM ticket, reference the SVC, close the FD record |
| **Snowflake** | No match — needs design | Raise FD-XXX record, route to CSD |
| **Escalated** | Recurring gap or strategic need | Raise FD-XXX record, route to PA |

**Record snowflakes precisely**

When a request does not match an existing capability, raise a
`front-door-intake` GitHub Issue. Your record must include:
- What the requester actually asked for (their words)
- What the closest NC/SVC match is
- **Specifically** what prevents a full match

"Different from the standard" is not a gap description.
"Site does not have Intune deployed — PAT-SVC-001 requires Intune
as a mandatory component" is a gap description.

**Maintain the audit thread**

Every downstream artefact references the FD-XXX record.
You update the FD record as the request progresses:
- When CSD confirms receipt
- When a departure record is raised
- When the PO makes their disposition decision
- When deployment completes

You close the record only when `downstream_refs` is complete
and `outcome_notes` explains what happened.

---

## What you do NOT do

- **You do not design solutions.** Route to CSD.
- **You do not approve or endorse designs.** That is PA.
- **You do not decide whether something is a deviation or a departure.**
  That is PA and the business jointly.
- **You do not contact the PO directly about capability ownership.**
  PA notifies the PO when a new capability is designed.
- **You do not close a record without complete downstream refs.**
  An incomplete record is not eligible for AI training.

---

## The four handoff triggers

**1 → ITSM (matched)**
Request matches SVC-XXX fully.
Action: raise ITSM ticket, reference SVC-XXX, close FD record.

**2 → CSD (snowflake)**
Request does not match any SVC-XXX.
Action: raise FD-XXX Issue with full gap description.
Route to CSD with design brief.

**3 → PA (escalation)**
Same gap appearing 3+ times, or single high-impact gap.
Action: update FD-INDEX.yaml, notify PA directly.
PA will assess for DP-05 (new capability) or DP-06 (tech debt).

**4 → PA (business funding departure signal)**
Business cannot fund a component of the approved pattern.
Action: record the funding gap in the FD-XXX Issue.
Flag to CSD in the design brief: "business cannot fund [component]
— this is a business funding departure, not a technical deviation."
PA raises the RES-XXX departure record.

---

## Business funding departures — your role

When the business cannot fund all the components of an approved pattern:

> This is a **business funding decision** — not a technical deviation.
> The pattern remains the single approved template.
> The CSD designs against the full pattern.
> A departure record (RES-XXX) explains what was not funded.

Your job: record the funding gap precisely in the FD-XXX record.
Be specific about which component is not funded and why.
Do not call it a "deviation" — it is a departure from standard delivery
due to a funding constraint.

---

## AI training — why your records matter

Your FD-XXX records will eventually train AI to triage requests
automatically. For a record to be eligible for AI training it must:

- Have a specific, useful `match_gap` description
- Have a completed `outcome_notes` explaining the resolution
- Have all `downstream_refs` populated
- Have a `disposition` set

Records that are vague, incomplete, or inconsistently worded
**are not eligible for AI training** and are therefore wasted effort.
PA confirms eligibility. Your quality determines the AI's quality.

---

## Your relationship with PA

PA governs the framework you work within. PA does not manage your team.

When PA reviews FD records:
- PA is checking for recurring gaps that need options papers
- PA is confirming AI training eligibility
- PA is maintaining the FD-INDEX

PA's escalation path for Front Door quality issues is to your management —
not to you directly. PA does not manage Front Door staff.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| New inbound request | `front-door-intake.yaml` |
| Escalating a recurring gap | `options-paper-request.yaml` |

---

*See [governance/front-door.html](front-door.html) · front-door/FD-TEMPLATE.yaml · front-door/FD-INDEX.yaml · capabilities/NC-CATALOGUE.yaml*
