# Role Card — Principal Network Architect (PA)

> Your accountability in the governance process.
> Single contributor model — what you own, what you trigger, what you protect.

---

<!-- BOTTOM LINE UP FRONT
  You own the framework. You don't build everything — you gate everything.
  DP-02 is self-service: engineers self-certify, you audit 20% quarterly.
  Your week: Thread 1 (model correct challenge), Thread 2 (endorsement gate),
  quarterly metrics run, XLINK quarterly review, escalations as they come.
  Start every session: CURRENT-FOCUS.md first.
-->

---

## What you own and produce

| Artefact | Your role |
|---|---|
| ABBs | You produce — capability definition is architecture's language |
| ZBBs | You co-produce with Cyber — you define zone and flow contract |
| Patterns | You approve (either source) — PA approval is the gate |
| Decision records | You produce — immutable audit trail |
| Domain taxonomy | You own — `governance/domain-taxonomy.yaml` |
| The governance model itself | You own |

## What you trigger others to produce

| Artefact | Who | Your role |
|---|---|---|
| SBB | SME | Review against ABB capability gates |
| VSBB | SME / Engineer | Review against SBB capability gates |
| Standard | SME (operational reality only) | Review and approve |
| Options paper | Requestor | Review and endorse via Thread 2 |
| VER-XXX | PA | You create — vendor evidence records |
| RES-XXX | PA | You create — resilience exception records |
| XLINK | PA | You create and maintain — quarterly review |
| NC records | CSD | Review architecture fit and heatmap currency |

**The rule:** a standard without a named `operational_owner` does not get written.
An artefact without a named consumer does not get written.

---

## Forum

**Thread 1** — model correct topology conformance challenge. As CSD matures,
step back to informed. MGR and GCB3 do not attend — enforce this.

**Thread 2** — permanently accountable for endorsement. Output: Endorsed /
Endorsed with conditions / Not endorsed. Cannot be delegated.

---

## DP-02 — self-service with PA audit

DP-02 (compliant solutions) is self-service. Engineers self-certify
TC-01/02/03. That certification IS the approval.

PA's role:
- Quarterly audit of 20% minimum of self-certified PRs
- Review metrics for systemic drift (high retrospective rate,
  deviation concentration by domain)
- False self-certification = finding against submitter, not a DP-02 item

High deviation volume in a domain = man-marking resource, not more PA reviews.

---

## Quarterly run — what you do

```
1. collect-metrics.py --quarter YYYY-Qn
   GitHub + YAML health sweep + SNOW CR linkage
   
2. Review governance_health output:
   RES-XXX overdue?           → chase programme risk owner
   XLINK TBC count?           → chase Security Architecture
   vsbb_os_needs_review?      → chase SME for VSBB update
   N-tier in production?      → RES-XXX exists? If not, raise one
   
3. XLINK quarterly review:
   Has any stakeholder artefact been superseded?
   If yes and no assessment done → CONF-G, raise finding
   
4. Update metrics.yaml narrative
5. Update CURRENT-FOCUS.md
```

---

## Vendor evidence records — VER-XXX

Asymmetric topology by vendor design → VER-XXX. Not RES-XXX.
VER-XXX and RES-XXX are mutually exclusive.

Review VER-XXX records when vendor releases a new major version.
Check `version_review_trigger` in each record.

If someone proposes RES-XXX for a vendor best practice deployment:
redirect to VER-XXX.

---

## Cross-framework linkages — XLINK

You own XLINK records. You create, maintain, and run quarterly reviews.
You escalate when Control Owner is not identified.

**The boundary you must hold:**
- You are NOT accountable for interpreting security policy
- You are NOT accountable for Security's internal coordination failures
- When Security Architecture and Ops conflict: CONF-F, pause, escalate
- When Control Owner is TBC: outstanding finding against the stakeholder

See `governance/xlinks/` and `governance/conflict-resolution.yaml` CONF-F/G.

---

## OS versions and the feature contract

Architecture governs features — not OS patch level.
OS minor patch differences between sites = operational. Not a finding.

The governance trigger: `vsbb_os_compatible: needs-review`
- OS upgraded beyond VSBB `tested_os_versions` range
- Feature dependency affected by release notes
- Config template produces different output on new OS

When triggered: assess with the SME. If feature contract still met →
update VSBB tested range. If not → VSBB needs a new version.

---

## Domain taxonomy — you maintain it

Six domains. You own the taxonomy.
`governance/domain-taxonomy.yaml` is the canonical reference.

Key distinction: transport = the medium. WAN = what runs on it.
Services domain = everything previously called overlay/vpn/ddi/obs/mgt.
ABB IDs retain original prefixes for backward compatibility.

---

## Conflict escalation

Five scenarios in `governance/conflict-resolution.yaml`.
Each has a trigger, resolution path, and timeframe.

**Cross-org — no shared MD.** Unresolved conflicts escalate to respective
MDs via your director.

`co-reviewed-by` in conflict-resolution.yaml must be signed by the
networks directors **before framework goes live**. Without it,
CONF-D and CONF-E have no teeth.

---

## The mandate conversation — before go-live

Before the first forum: director-level agreement across both orgs.
One meeting. Two signatures. Do it before the first conflict, not during.

---

*See governance/raci.yaml · governance/conflict-resolution.yaml · CONTRIBUTING.md*
