# Role Card — Principal Network Architect (PA)

> Your accountability in the governance process.
> The single contributor model — what you own and what you trigger others to own.

---

## What you own and produce

| Artefact | Your role |
|---|---|
| ABB | You produce — capability definition is architecture's language |
| ZBB | You co-produce with Cyber — you define the zone and flow contract |
| Pattern | You approve (either source) — PA approval is the gate |
| Decision record | You produce — immutable audit trail |
| The governance model itself | You own |

## What you trigger others to produce

| Artefact | Triggered party | Your role |
|---|---|---|
| SBB | SME | Reviews against ABB capability gates |
| VSBB | SME / Engineer | Reviews against SBB capability gates |
| Standard | SME (operational reality only) | Reviews and approves |
| Options paper | Requestor | Reviews and endorses via Thread 2 |
| Service blueprint | MGR / Engineer | Reviews architecture fit |

**The rule:** A standard without a named `operational_owner` does not get written.
An artefact without a named consumer does not get written.

---

## Forum

**Thread 1:** You attend in current state to model correct topology conformance challenge.
As CSD matures, you step back to informed.

**Thread 2:** You are permanently accountable for endorsement.
Output: Endorsed / Endorsed with conditions / Not endorsed.
This gate cannot be delegated.

---

## DP-02 — Self-service with PA audit

DP-02 (compliant solutions) is self-service. CSD and engineers
self-certify TC-01/02/03 in a Pull Request. That certification
IS the approval. PA does not review every compliant solution.

PA's role is quarterly audit:
- Sample minimum 20% of self-certified PRs
- Review metrics for systemic drift — high retrospective rate
  or deviation concentration by domain signals a process problem
- A false self-certification is a governance finding against
  the submitter — not a DP-02 item to approve

If audit reveals systemic non-compliance in a domain: process adoption
problem, addressed by Thread 1 emphasis and role cards.
If DP-03/DP-08 deviation volume is high in a domain: man-marking
project lead resource is the answer, not PA reviewing more PRs.

---



## Vendor evidence records — VER-XXX

When a deployment uses an asymmetric topology by vendor design, a
VER-XXX Vendor Evidence Record is the correct governance artefact.
This is not a deviation. It is not a resilience exception.
It is documented evidence that the vendor recommends this model.

VER-XXX records must be reviewed when the vendor releases a new
major product version. Check version_review_trigger in each record.

`vendor_evidence_ref` and `resilience_exception_ref` are mutually
exclusive — a deployment is either vendor best practice or a funded
compromise. Never both. If someone proposes a RES-XXX for a vendor
best practice deployment, redirect to VER-XXX.

See `governance/vendor-evidence/` for all records.

## Cross-framework linkages — your responsibility

You own the XLINK records. You create them. You run the quarterly review.
You escalate when a Control Owner is not identified or does not respond.

**The accountability boundary you must hold:**

The network team implements security controls. Security Architecture
defines them. Risk/GRC maps them to control frameworks.
Neither of those functions is accountable for implementation — you are.

But you are NOT accountable for:
- Interpreting security policy
- Resolving conflicts between Security Architecture and Security Ops
- Implementing requirements not formally agreed in a boundary contract
- Filling the gap left by the stakeholder's internal coordination failures

When Security Architecture and Security Operations give conflicting
direction — document it, raise CONF-F, and pause implementation.
Do not choose between the two positions unilaterally.

When a Control Owner cannot be identified — document it in the XLINK
record as an outstanding finding against the stakeholder organisation.
Escalate to their GCB3-equivalent after 10 working days. This is their
finding, not yours.

See `governance/xlinks/` for all XLINK records.
See `governance/conflict-resolution.yaml` CONF-F and CONF-G.

## Annual certification — what you do not do

You do not certify every standard and SBB annually.
Named `operational_owner` fields flag drift via operational feedback.
You spot-check the feedback register for drift patterns.

If an artefact has no `operational_owner` — it cannot go active.

---

## Conflict escalation

Your conflict resolution paths are in `governance/conflict-resolution.yaml`.
Five scenarios. Each has a named trigger, resolution path, and timeframe.

Key principle: **Cross-org — no shared MD.**
Unresolved conflicts escalate to respective MDs via your director.

The `co-reviewed-by` field in `conflict-resolution.yaml` must be signed
by the networks directors **before the framework goes live**.
Without that, CONF-D and CONF-E have no teeth.

---

## The mandate conversation before go-live

Before the first forum, you need a director-level agreement across both orgs:
- Architecture governance applies to all solutions in the networks portfolio
- The conflict resolution paths are jointly agreed
- PA's independence from networks service delivery is understood and accepted

This is one meeting and two signatures. Do it before the first conflict, not during.

---

*See governance/raci.yaml · governance/conflict-resolution.yaml · CONTRIBUTING.md*
