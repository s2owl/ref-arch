# Role Card — Principal Network Architect (PA)

> Your accountability in the governance process.
> The single contributor model — what you own and what you trigger others to own.

---

## What you own and produce

| Artefact | Your role |
|---|---|
| ABB | You produce — capability definition is architecture's language |
| ZBB | You co-produce with Cyber — you define the zone and flow contract |
| Pattern | You approve (either source) — PA approval is the gate |
| Decision record | You produce — immutable audit trail |
| The governance model itself | You own |

## What you trigger others to produce

| Artefact | Triggered party | Your role |
|---|---|---|
| SBB | SME | Reviews against ABB capability gates |
| VSBB | SME / Engineer | Reviews against SBB capability gates |
| Standard | SME (operational reality only) | Reviews and approves |
| Options paper | Requestor | Reviews and endorses via Thread 2 |
| Service blueprint | MGR / Engineer | Reviews architecture fit |

**The rule:** A standard without a named `operational_owner` does not get written.
An artefact without a named consumer does not get written.

---

## Forum

**Thread 1:** You attend in current state to model correct topology conformance challenge.
As CSD matures, you step back to informed.

**Thread 2:** You are permanently accountable for endorsement.
Output: Endorsed / Endorsed with conditions / Not endorsed.
This gate cannot be delegated.

---

## The bottleneck you must plan to remove

You are currently accountable for all solution sign-off (DP-02).
This is the highest-volume decision point and the single contributor bottleneck.

Target state: CSD takes accountability for compliant solutions.
Transition trigger: 6 Thread 1 sessions + 3 PR topology reviews + 2 PA consistency assessments.

**Thread 1 is the development mechanism. Run it consistently.**

---

## Annual certification — what you do not do

You do not certify every standard and SBB annually.
Named `operational_owner` fields flag drift via operational feedback.
You spot-check the feedback register for drift patterns.

If an artefact has no `operational_owner` — it cannot go active.

---

## Conflict escalation

Your conflict resolution paths are in `governance/conflict-resolution.yaml`.
Five scenarios. Each has a named trigger, resolution path, and timeframe.

Key principle: **Cross-org — no shared MD.**
Unresolved conflicts escalate to respective MDs via your director.

The `co-reviewed-by` field in `conflict-resolution.yaml` must be signed
by the networks directors **before the framework goes live**.
Without that, CONF-D and CONF-E have no teeth.

---

## The mandate conversation before go-live

Before the first forum, you need a director-level agreement across both orgs:
- Architecture governance applies to all solutions in the networks portfolio
- The conflict resolution paths are jointly agreed
- PA's independence from networks service delivery is understood and accepted

This is one meeting and two signatures. Do it before the first conflict, not during.

---

*See governance/raci.yaml · governance/conflict-resolution.yaml · CONTRIBUTING.md*
