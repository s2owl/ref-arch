# Role Card — TBC/Control Owner
# governance/role-card-control-owner.md
#
# This role card is addressed to the individual from a stakeholder
# organisation (Security Architecture, Risk/GRC, Compliance) who
# is identified as the Control Owner for one or more network
# architecture linkage records (XLINK-XXX).
#
# Until a named individual accepts this role for a given XLINK,
# that record carries an outstanding finding — not against the
# network team, but against the stakeholder organisation.

# Role Card — Control Owner (TBC)

> This role requires a named individual from your organisation.
> Until you are identified, the governance linkage is incomplete
> and that incompleteness is recorded as your organisation's finding.

---

## What this role is

You are the named individual from your organisation — Security
Architecture, Risk/GRC, or Compliance — who formally agrees that
a network architecture artefact correctly implements your
organisation's policy, control, or standard.

You are not being asked to do network architecture. You are being
asked to confirm that what the network team has built is consistent
with what your organisation requires.

This is a governance engagement, not a technical delivery.

---

## What your organisation is NOT accountable for

The network team implements security controls — they configure
firewalls, define zone boundaries, and build segmentation patterns.
This is because the network team has access to the devices and the
technical capability to implement the controls.

Your organisation defines what those controls must achieve. It does
not implement them. It does not configure devices. It does not
resolve internal network design questions.

The accountability split:

| Network Architecture | Your organisation |
|---|---|
| Technical implementation | Policy and control definition |
| ZBB boundary contract (the what) | Enforcement policy (the how) |
| Firewall insertion point | Firewall rule set |
| Traffic flow model | Permitted flows policy |
| Version-controlled artefacts | Policy document versions |

---

## What is being asked of you

For each XLINK record where you are named as Control Owner:

**1. Review the network artefact**
Read the ZBB boundary contract, pattern, or SBB that is linked
to your policy or control. Confirm it is consistent with your
organisation's requirements.

**2. Agree the material change definition**
What changes on your side would require the network team to
reassess their artefact? What changes on the network side would
require you to reassess your policy alignment? This is agreed once
and recorded in the XLINK — it prevents unnecessary re-reviews.

**3. Co-sign the XLINK record**
Provide your name, function, grade, and the date of agreement.
The form of agreement (email confirmation, meeting minutes,
formal review document) is recorded in the XLINK.

**4. Respond to version change notifications**
When the network team notifies you that a material change has
occurred on their side, you assess whether your policy alignment
is still valid. Target response: 10 working days.

When your organisation publishes a new version of the linked policy
or control, you notify the network team. Target notification:
5 working days from publication.

---

## The internal coordination problem

Security Architecture, Security Operations, and Security Engineering
are different functions. The network team engages with Security
Architecture for policy alignment — not with Security Operations
or Security Engineering.

If you are from Security Operations or Security Engineering and
have been directed to this role card: the correct contact is
Security Architecture. The network team does not resolve your
organisation's internal coordination gaps.

If Security Architecture cannot identify a named individual to
act as Control Owner within 10 working days of being asked,
the network team escalates to the Security GCB3-equivalent.
The outstanding finding is documented against your organisation,
not against the network team.

---

## What happens if you don't engage

If a Control Owner is not identified and the XLINK remains
incomplete:

```
Days 0-10   PA attempts to identify Control Owner via
            Security Architecture / Risk/GRC contacts

Days 10-20  PA formally notifies the Security or Risk GCB3-
            equivalent that the linkage is incomplete and
            that governance cannot certify the alignment

Days 20+    Outstanding finding recorded in governance metrics
            as a stakeholder-linkage-drift item.
            Escalated to PA's MD if framework go-live is blocked.
```

The outstanding finding is not against the network team. The network
artefact is complete. The policy alignment cannot be confirmed
because the stakeholder organisation has not engaged.

---

## GitHub Issues

When a material change notification needs to be raised or a
version change assessment is required, the network team raises
a GitHub Issue with:

- `type:xlink-review`
- The XLINK-XXX reference
- The specific change and the assessment needed

You will be tagged as the named Control Owner. Response expected
within 10 working days.

---

## Quarterly review

All XLINK records are reviewed quarterly. If your organisation
has published a new version of a linked artefact and the network
team has not been notified, the quarterly review will surface it
as an outstanding finding. You will be contacted directly.

---

*See governance/xlinks/ for all XLINK records.*
*See governance/conflict-resolution.yaml CONF-F and CONF-G for*
*escalation paths when stakeholder engagement is blocked.*
