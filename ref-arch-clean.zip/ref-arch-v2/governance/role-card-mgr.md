# Role Card — Service Manager

> Your part in the governance process.
> One page. Keep it visible.

---

<!-- BOTTOM LINE UP FRONT
  For compliant solutions: you are informed. PA is not in your critical path.
  For deviations: you acknowledge the risk in writing. This creates the audit trail.
  For resilience exceptions: you may be the named risk owner. That is real accountability.
  Never instruct your engineer to skip TC checks or bypass the forum.
-->

## Your accountability

You are **accountable for service delivery** for your capability area.
Architecture governance is **parallel** to your delivery accountability.

PA governs correctness of architecture.
You govern delivery of the service.
Complementary — not competing.

---

## Where you appear in governance

| Decision point | Your role |
|---|---|
| Compliant solution, no deviations | Informed only |
| Solution has deviations | **Consulted — acknowledge deviation and accept risk in writing** |
| Resilience below ABB minimum tier | **Named risk owner in RES-XXX record** |
| New capability | Consulted — articulate the business need |
| Operational feedback | Informed when it affects your service |

---

## Deviations — what acknowledging means

When your engineer's solution has a documented deviation, you are asked:

> "Do you accept this risk on behalf of the service?"

This creates a clean audit trail:
- PA approved on **architecture grounds**
- You accepted on **service grounds**

Neither party can later claim they didn't know. If you disagree with
the classification — that is a conversation with PA, not an instruction
to your engineer to proceed without the process.

---

## Resilience exceptions — your accountability is real

When a programme cannot fund the ABB minimum resilience tier for a
Layer 3 service (NLB, DNS, proxy, VPN), a Resilience Exception
(RES-XXX) is raised. The exception requires a **named risk owner**.

For production services that is you — or your programme sponsor.
"The team accepts the risk" is not sufficient. A named individual
must accept in writing. That record goes to the risk register.

For DORA-scoped or PCI-scoped services below minimum tier: GCB3 is
informed regardless. This is regulatory risk, not just delivery risk.

See `governance/resilience-tiers.html` for the tier model and
`governance/resilience-exceptions/RES-TEMPLATE.yaml` for the record.

---

## What you must not do

- **Do not instruct your engineer to skip TC checks or bypass the forum.**
  That is CONF-A. PA will inform your director.

- **Do not suppress operational feedback** raised by your team.
  The feedback channel is direct to architecture governance.
  Suppression is itself a governance finding.

- **Do not attend Thread 1 of the Arch/Eng Forum.**
  Forum integrity requires management separation.
  Engineers self-censor in front of their management chain.

---

## What to expect

- **Compliant solutions:** you are informed. PA is not in your critical path.
- **Deviations:** consulted and acknowledgement recorded. 5–10 working days.
- **CONF-B (urgent deviation):** PA can endorse with conditions and time-bound
  remediation. If timeline cannot be agreed, your director and PA resolve jointly.

---

## Cross-framework governance

Some network artefacts link to Security Architecture policies and
Risk/GRC controls via XLINK records. Where Control Owner is TBC,
the linkage is incomplete — PA is pursuing the stakeholder.

If delivery is delayed because Security cannot give coherent direction:
that delay is documented against Security. You may escalate through
your GCB3 to the Security GCB3-equivalent.
The network team does not resolve Security's internal coordination gaps.

---

## The governance compact

This framework operates under a cross-org agreement co-signed at
director level. Architecture governance has authority here by agreed
mandate — not by seniority within your chain.

---

*See governance/conflict-resolution.yaml · governance/resilience-tiers.html · ref-arch*
