# Role Card — Service Manager

> Your part in the governance process.
> One page. Keep it visible.

---

## Your accountability

You are **accountable for service delivery** for your capability area.
Architecture governance is **parallel** to your delivery accountability — not inside it.

PA governs correctness of the architecture.
You govern delivery of the service.
These are complementary, not competing — when the process runs correctly.

---

## Where you appear in governance

| Decision point | Your role |
|---|---|
| Solution design — compliant, no deviations | Informed |
| Solution design — has deviations | **Consulted — you must acknowledge the deviation and accept the risk** |
| Deviation approval | **Consulted — your formal acknowledgement is required** |
| Wholly new capability | Consulted — you articulate the business need |
| Operational feedback | Informed when it affects your service |
| Deployment register currency | Consulted — you plan remediation for your service |

---

## What "consulted" means for deviations

When your engineer's solution has a documented deviation, you are asked:

> "Do you accept this risk on behalf of the service?"

This creates a clean audit trail:
- PA approved the deviation on **architecture grounds**
- You accepted it on **service grounds**

Neither party can later claim they didn't know.
If you disagree with the deviation classification, that is a conversation with PA —
not an instruction to your engineer to proceed without the process.

---

## What you must not do

- **Do not instruct your engineer to skip topology conformance or bypass the forum.**
  That is a CONF-A governance conflict. PA will inform your director.

- **Do not suppress operational feedback** raised by your team.
  The feedback channel is direct to architecture governance.
  Suppression is itself a governance finding.

- **Do not attend Thread 1 of the Arch/Eng Forum.**
  Forum integrity requires management separation.
  Engineers self-censor in front of their management chain.

---

## What you should expect

- For compliant solutions: you are **informed** of the outcome.
  PA is not in your delivery critical path.

- For deviations: you are **consulted and your acknowledgement is recorded**.
  The process is 5–10 working days from deviation issue to PA endorsement.

- For escalations (CONF-B — deviation urgent, deadline at risk):
  PA can endorse with conditions and a time-bound remediation plan.
  If PA and you cannot agree timeline, your director and PA resolve jointly.

---

## The governance compact

This governance framework operates under a cross-org agreement between
PA's organisation and yours, co-signed at director level.

Architecture governance has authority here by agreed mandate —
not by seniority within your management chain.

---

*See governance/conflict-resolution.yaml for escalation paths · ref-arch*
