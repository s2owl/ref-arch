import { useState } from "react";

const QUARTERS = [
  {
    quarter: "Q4 2025 — Capacity constraint",
    status: "example",
    narrative: "DC fabric generating highest deviation volume. PA bottleneck queue peaked at 4. Dwell concentrated at awaiting-pa (avg 8.2d vs 1.4d awaiting-submitter). Diagnosis: capacity constraint. Headcount case for Option A (CSD) is supported by data.",
    throughput: {
      dp02: { volume: 14, avg_cycle: 5.1, p90_cycle: 12 },
      dp03: { volume: 7,  avg_cycle: 9.4, p90_cycle: 18, by_outcome: { endorsed: 3, ewc: 3, not_endorsed: 1 }, by_domain: { "dc-fabric": 3, "security-boundary": 2, wan: 2 } },
      dp07: { volume: 9,  avg_cycle: 7.2, p90_cycle: 14, by_outcome: { endorsed: 6, ewc: 2, not_endorsed: 1 } },
      dp08: { volume: 7,  avg_cycle: 4.8, open_remediations: 4, rem_closed: 2, avg_rem_days: 21 },
      retro: { volume: 3, rate_pct: 14, by_domain: { "dc-fabric": 2, wan: 1 } },
      bottleneck: { events: 11, queue_depth: 4 },
      first_response: { avg_days: 1.2, p90_days: 3 },
    },
    dwell: {
      diagnosis: "capacity-constraint",
      diagnosis_note: "Dwell concentrated at awaiting-pa. PA is the bottleneck. Supports headcount Option A (CSD).",
      by_status: {
        "awaiting-pa":        { avg_days: 8.2, p90_days: 14, item_count: 18 },
        "awaiting-submitter": { avg_days: 1.4, p90_days: 3,  item_count: 12 },
        "awaiting-cyber":     { avg_days: 2.1, p90_days: 5,  item_count: 4  },
        "awaiting-da":        { avg_days: 3.0, p90_days: 7,  item_count: 6  },
        "in-progress":        { avg_days: 4.3, p90_days: 9,  item_count: 9  },
        "blocked":            { avg_days: 6.0, p90_days: 12, item_count: 2  },
        "remediation-open":   { avg_days: 18,  p90_days: 35, item_count: 4  },
      },
    },
    capability: { thread_1: 2, named_csd: 3, trigger_met: false, cap_gap: 4 },
    risk: {
      artistic: { volume: 5, by_domain: { "dc-fabric": 3, "security-boundary": 2 } },
      open_devs: { total: 8, by_domain: { "dc-fabric": 4, wan: 2, "security-boundary": 2 }, oldest_days: 47, avg_age: 22 },
      reg: { "PCI-DSS": 4, DORA: 3, "PRA-SS2/21": 1 },
      opfeed: { raised: 4, actioned: 2, open: 2 },
    },
  },
  {
    quarter: "Q4 2025 — Behaviour problem",
    status: "example",
    narrative: "High volume but dwell concentrated at awaiting-submitter (avg 9.1d vs 1.8d awaiting-pa). Submissions arriving incomplete — engineers raising Issues before TC self-assessment. Process adoption issue, not a capacity problem. Response: Thread 1 emphasis, role card refresher, not headcount.",
    throughput: {
      dp02: { volume: 11, avg_cycle: 3.4, p90_cycle: 7 },
      dp03: { volume: 9,  avg_cycle: 12.1, p90_cycle: 22, by_outcome: { endorsed: 2, ewc: 4, not_endorsed: 3 }, by_domain: { wan: 4, "dc-fabric": 3, "remote-access": 2 } },
      dp07: { volume: 8,  avg_cycle: 6.8, p90_cycle: 13, by_outcome: { endorsed: 4, ewc: 2, not_endorsed: 2 } },
      dp08: { volume: 9,  avg_cycle: 3.1, open_remediations: 6, rem_closed: 1, avg_rem_days: 31 },
      retro: { volume: 7, rate_pct: 35, by_domain: { wan: 4, "dc-fabric": 2, "remote-access": 1 } },
      bottleneck: { events: 3, queue_depth: 1 },
      first_response: { avg_days: 0.8, p90_days: 2 },
    },
    dwell: {
      diagnosis: "behaviour-problem",
      diagnosis_note: "Dwell concentrated at awaiting-submitter. Submissions are incomplete or raised too early. Process adoption issue — not a capacity problem. Response: Thread 1, role cards.",
      by_status: {
        "awaiting-pa":        { avg_days: 1.8, p90_days: 4,  item_count: 6  },
        "awaiting-submitter": { avg_days: 9.1, p90_days: 19, item_count: 22 },
        "awaiting-cyber":     { avg_days: 1.4, p90_days: 3,  item_count: 3  },
        "awaiting-da":        { avg_days: 2.2, p90_days: 5,  item_count: 5  },
        "in-progress":        { avg_days: 5.1, p90_days: 11, item_count: 8  },
        "blocked":            { avg_days: 3.0, p90_days: 7,  item_count: 3  },
        "remediation-open":   { avg_days: 24,  p90_days: 45, item_count: 6  },
      },
    },
    capability: { thread_1: 1, named_csd: 3, trigger_met: false, cap_gap: 2 },
    risk: {
      artistic: { volume: 8, by_domain: { wan: 4, "dc-fabric": 2, "remote-access": 2 } },
      open_devs: { total: 12, by_domain: { wan: 5, "dc-fabric": 4, "remote-access": 3 }, oldest_days: 62, avg_age: 31 },
      reg: { "PCI-DSS": 3, DORA: 5, "PRA-SS2/21": 2 },
      opfeed: { raised: 2, actioned: 1, open: 1 },
    },
  },
];

const DIAG = {
  "capacity-constraint": { color: "#dc2626", bg: "#fff5f5", border: "#fecaca", label: "Capacity constraint — headcount argument", icon: "⚠" },
  "behaviour-problem":   { color: "#d97706", bg: "#fffbeb", border: "#fde68a", label: "Behaviour / process adoption problem",     icon: "↻" },
  "mixed":               { color: "#2563eb", bg: "#eff6ff", border: "#bfdbfe", label: "Mixed — capacity and behaviour",           icon: "~" },
  "insufficient-data":   { color: "#9ca3af", bg: "#f9fafb", border: "#e5e7eb", label: "Insufficient data",                        icon: "?" },
};

const F = "Calibri, Arial, sans-serif";

const Chip = ({ label, color = "#6b7280", sz = 10 }) => (
  <span style={{ background: color + "18", color, border: `1px solid ${color}35`, borderRadius: 4, padding: "2px 7px", fontSize: sz, fontWeight: 600, textTransform: "uppercase", fontFamily: F, whiteSpace: "nowrap" }}>{label}</span>
);

const Stat = ({ label, value, sub, color = "#1a1814", warn }) => (
  <div style={{ background: warn ? "#fff8f0" : "#faf9f6", border: `1px solid ${warn ? "#f0d4a0" : "#e5e7eb"}`, borderTop: `3px solid ${color}`, borderRadius: 6, padding: "10px 12px" }}>
    <div style={{ fontSize: 10, color: "#6b7280", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 4, fontFamily: F }}>{label}</div>
    <div style={{ fontSize: 22, fontWeight: 700, color, fontFamily: F }}>{value}</div>
    {sub && <div style={{ fontSize: 10, color: "#9ca3af", marginTop: 2, fontFamily: F }}>{sub}</div>}
  </div>
);

const HBar = ({ label, value, max, color, bold }) => {
  const w = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "5px 0", borderBottom: "1px solid #f9fafb" }}>
      <div style={{ width: 156, fontSize: 11, color: bold ? "#111" : "#3d3a34", fontWeight: bold ? 700 : 400, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", fontFamily: F }}>{label}</div>
      <div style={{ flex: 1, height: 8, background: "#f3f4f6", borderRadius: 3, overflow: "hidden" }}>
        <div style={{ width: `${w}%`, height: "100%", background: color, borderRadius: 3 }} />
      </div>
      <div style={{ width: 38, textAlign: "right", fontSize: 11, fontFamily: F, color: bold ? color : "#6b7280", fontWeight: bold ? 700 : 400 }}>{(+value).toFixed(1)}d</div>
    </div>
  );
};

const SBar = ({ label, value, max, color }) => {
  const w = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "3px 0" }}>
      <div style={{ width: 120, fontSize: 10, color: "#3d3a34", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", fontFamily: F }}>{label}</div>
      <div style={{ flex: 1, height: 5, background: "#f3f4f6", borderRadius: 3, overflow: "hidden" }}>
        <div style={{ width: `${w}%`, height: "100%", background: color, borderRadius: 3 }} />
      </div>
      <div style={{ width: 20, textAlign: "right", fontSize: 10, fontFamily: F, color: "#6b7280" }}>{value}</div>
    </div>
  );
};

const Progress = ({ label, value, max, color }) => (
  <div style={{ marginBottom: 10 }}>
    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3, fontSize: 11, fontFamily: F }}>
      <span style={{ color: "#3d3a34" }}>{label}</span>
      <span style={{ color }}>{value} / {max}</span>
    </div>
    <div style={{ height: 6, background: "#f3f4f6", borderRadius: 4, overflow: "hidden" }}>
      <div style={{ width: `${Math.min(Math.round(value/max*100), 100)}%`, height: "100%", background: color, borderRadius: 4 }} />
    </div>
  </div>
);

export default function Dashboard() {
  const [sel, setSel] = useState(QUARTERS[0].quarter);
  const q  = QUARTERS.find(x => x.quarter === sel) || QUARTERS[0];
  const t  = q.throughput;
  const dw = q.dwell;
  const c  = q.capability;
  const r  = q.risk;
  const dg = DIAG[dw.diagnosis] || DIAG["insufficient-data"];
  const totalSol = t.dp02.volume + t.dp03.volume;
  const devRate  = totalSol > 0 ? Math.round(t.dp03.volume / totalSol * 100) : 0;
  const maxAvg   = Math.max(...Object.values(dw.by_status).map(s => s.avg_days), 1);
  const maxP90   = Math.max(...Object.values(dw.by_status).map(s => s.p90_days), 1);

  return (
    <div style={{ background: "#f8f7f4", minHeight: "100vh", fontFamily: F, padding: 24, fontSize: 12 }}>

      {/* Header */}
      <div style={{ background: "#0a0e1a", borderRadius: 8, padding: "14px 22px", marginBottom: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ color: "#f9fafb", fontSize: 15, fontWeight: 700 }}>Network Architecture Governance</div>
          <div style={{ color: "#9ca3af", fontSize: 10, marginTop: 2 }}>Governance Metrics · Dwell Time &amp; Volume Analysis</div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {QUARTERS.map(x => (
            <button key={x.quarter} onClick={() => setSel(x.quarter)}
              style={{ background: sel === x.quarter ? "#f9fafb" : "transparent", color: sel === x.quarter ? "#0a0e1a" : "#9ca3af", border: `1px solid ${sel === x.quarter ? "#f9fafb" : "#374151"}`, borderRadius: 4, padding: "4px 10px", fontSize: 10, cursor: "pointer", fontFamily: F, fontWeight: 600 }}>
              {x.quarter}
            </button>
          ))}
        </div>
      </div>

      {/* Diagnosis */}
      <div style={{ background: dg.bg, border: `1px solid ${dg.border}`, borderLeft: `4px solid ${dg.color}`, borderRadius: 6, padding: "12px 16px", marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16 }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: dg.color, marginBottom: 4 }}>{dg.icon}  {dg.label}</div>
            <div style={{ fontSize: 12, color: "#3d3a34", lineHeight: 1.6, maxWidth: 820 }}>{dw.diagnosis_note}</div>
          </div>
        </div>
        {q.narrative && <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${dg.border}`, fontSize: 11, color: "#6b6660", fontStyle: "italic", lineHeight: 1.6 }}>{q.narrative}</div>}
      </div>

      {/* Dwell by status */}
      <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 8, overflow: "hidden", marginBottom: 14 }}>
        <div style={{ background: "#1e3d5c", padding: "9px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ color: "white", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em" }}>Dwell Time by Status — Where Is Time Being Spent?</span>
          <span style={{ color: "#9ca3af", fontSize: 10 }}>Longer bar = problem in that state</span>
        </div>
        <div style={{ padding: "14px 16px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>Average days per item</div>
            {Object.entries(dw.by_status).map(([s, d]) => {
              const isPA = s === "awaiting-pa", isSub = s === "awaiting-submitter";
              const c2 = isPA ? "#dc2626" : isSub ? "#d97706" : s === "remediation-open" ? "#7c3aed" : "#6b7280";
              return <HBar key={s} label={s.replace(/-/g," ")} value={d.avg_days} max={maxAvg} color={c2} bold={isPA||isSub} />;
            })}
          </div>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>P90 days — worst case experience</div>
            {Object.entries(dw.by_status).map(([s, d]) => {
              const isPA = s === "awaiting-pa", isSub = s === "awaiting-submitter";
              const c2 = isPA ? "#dc2626" : isSub ? "#d97706" : s === "remediation-open" ? "#7c3aed" : "#9ca3af";
              return <HBar key={s} label={s.replace(/-/g," ")} value={d.p90_days} max={maxP90} color={c2} bold={isPA||isSub} />;
            })}
          </div>
        </div>
        <div style={{ padding: "8px 16px", borderTop: "1px solid #f3f4f6", background: "#f9fafb", display: "flex", gap: 20, flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: "#dc2626" }}><div style={{ width: 10, height: 10, background: "#dc2626", borderRadius: 2 }} /><strong>awaiting-pa</strong> long = capacity problem → headcount</div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: "#d97706" }}><div style={{ width: 10, height: 10, background: "#d97706", borderRadius: 2 }} /><strong>awaiting-submitter</strong> long = behaviour problem → Thread 1, role cards</div>
        </div>
      </div>

      {/* Volume */}
      <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 8, overflow: "hidden", marginBottom: 14 }}>
        <div style={{ background: "#1e3d5c", padding: "9px 16px" }}>
          <span style={{ color: "white", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em" }}>Volume &amp; Cycle Time</span>
        </div>
        <div style={{ padding: "14px 16px", display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginBottom: 12 }}>
          <Stat label="Compliant (DP-02)" value={t.dp02.volume} sub={`Avg ${t.dp02.avg_cycle}d · P90 ${t.dp02.p90_cycle}d`} color="#2d9e6e" />
          <Stat label="Deviations (DP-03)" value={t.dp03.volume} sub={`${devRate}% of solutions · avg ${t.dp03.avg_cycle}d`} color="#d97706" warn={devRate > 25} />
          <Stat label="Retrospective rate" value={`${t.retro.rate_pct}%`} sub={`${t.retro.volume} submitted without prior engagement`} color={t.retro.rate_pct > 20 ? "#dc2626" : "#d97706"} warn={t.retro.rate_pct > 20} />
          <Stat label="PA first response" value={`${t.first_response.avg_days}d avg`} sub={`P90: ${t.first_response.p90_days}d`} color={t.first_response.avg_days > 3 ? "#dc2626" : "#2d9e6e"} warn={t.first_response.avg_days > 3} />
        </div>
        <div style={{ padding: "0 16px 14px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>Deviations by domain</div>
            {Object.entries(t.dp03.by_domain).sort((a,b)=>b[1]-a[1]).map(([d,v]) => <SBar key={d} label={d} value={v} max={Math.max(...Object.values(t.dp03.by_domain))} color="#d97706" />)}
          </div>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>Retrospective by domain</div>
            {Object.entries(t.retro.by_domain).sort((a,b)=>b[1]-a[1]).map(([d,v]) => <SBar key={d} label={d} value={v} max={Math.max(...Object.values(t.retro.by_domain))} color="#dc2626" />)}
            <div style={{ marginTop: 8, fontSize: 11, color: "#6b7280", lineHeight: 1.5 }}>{t.retro.rate_pct > 20 ? "Above 20% — process not embedded in these domains." : "Below 20% — process adoption acceptable."}</div>
          </div>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>Remediation velocity</div>
            <Stat label="Open remediations" value={t.dp08.open_remediations} sub={`${t.dp08.rem_closed} closed · avg ${t.dp08.avg_rem_days}d`} color={t.dp08.open_remediations > 5 ? "#dc2626" : "#d97706"} warn={t.dp08.open_remediations > 5} />
          </div>
        </div>
      </div>

      {/* CSD + Artistic licence */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
        <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 8, overflow: "hidden" }}>
          <div style={{ background: "#3d1e5c", padding: "9px 16px" }}><span style={{ color: "white", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em" }}>CSD Transition</span></div>
          <div style={{ padding: "14px 16px" }}>
            <Progress label="Thread 1 sessions (6 required)" value={c.thread_1} max={6} color="#3d1e5c" />
            <Progress label="Named CSD reviewers" value={c.named_csd} max={4} color="#3d1e5c" />
            <div style={{ padding: "8px 10px", background: c.trigger_met ? "#f0f7f0" : "#fdf5f0", border: `1px solid ${c.trigger_met ? "#b0d8b0" : "#f0b0a0"}`, borderRadius: 6, fontSize: 11, color: c.trigger_met ? "#1e4a1e" : "#6b2a10", fontWeight: 600, fontFamily: F }}>
              {c.trigger_met ? "✓ Trigger met — PA can delegate DP-02" : "✗ Not met — PA sole approver for all DP-02"}
            </div>
          </div>
        </div>
        <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 8, overflow: "hidden" }}>
          <div style={{ background: "#6b2a10", padding: "9px 16px" }}><span style={{ color: "white", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em" }}>Artistic Licence — Man-marking Target</span></div>
          <div style={{ padding: "14px 16px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
              <Stat label="Events this quarter" value={r.artistic.volume} sub="Undocumented topology variations" color="#dc2626" warn={r.artistic.volume > 3} />
              <Stat label="Open deviations (all)" value={r.open_devs.total} sub={`Oldest: ${r.open_devs.oldest_days}d`} color="#d97706" warn={r.open_devs.oldest_days > 30} />
            </div>
            {Object.entries(r.artistic.by_domain).sort((a,b)=>b[1]-a[1]).map(([d,v]) => <SBar key={d} label={d} value={v} max={Math.max(...Object.values(r.artistic.by_domain))} color="#dc2626" />)}
          </div>
        </div>
      </div>

      {/* Headcount summary */}
      <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 8, overflow: "hidden" }}>
        <div style={{ background: "#0a0e1a", padding: "9px 16px" }}><span style={{ color: "white", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em" }}>Headcount Case — What the Data Says This Quarter</span></div>
        <div style={{ padding: "14px 16px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
          <div style={{ padding: "12px 14px", border: `1px solid ${dg.border}`, borderLeft: `3px solid ${dg.color}`, borderRadius: 6 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: dg.color, marginBottom: 6 }}>Diagnosis: {dg.icon} {DIAG[dw.diagnosis]?.label}</div>
            <div style={{ fontSize: 11, color: "#3d3a34", lineHeight: 1.6 }}>{dw.diagnosis_note}</div>
          </div>
          <div style={{ padding: "12px 14px", border: "1px solid #d0b8e0", borderLeft: "3px solid #3d1e5c", borderRadius: 6 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#3d1e5c", marginBottom: 6 }}>Option A — CSD (Enabler)</div>
            <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
              <Chip label={`PA queue: ${t.bottleneck.queue_depth}`} color={t.bottleneck.queue_depth > 2 ? "#dc2626" : "#9ca3af"} sz={9} />
              <Chip label={`Awaiting-PA: ${(+dw.by_status["awaiting-pa"]?.avg_days).toFixed(1)}d avg`} color={dw.by_status["awaiting-pa"]?.avg_days > 5 ? "#dc2626" : "#9ca3af"} sz={9} />
              <Chip label={c.trigger_met ? "CSD trigger met" : "CSD trigger: not met"} color={c.trigger_met ? "#2d9e6e" : "#dc2626"} sz={9} />
            </div>
          </div>
          <div style={{ padding: "12px 14px", border: "1px solid #f0b0a0", borderLeft: "3px solid #6b2a10", borderRadius: 6 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#6b2a10", marginBottom: 6 }}>Option B — Man-marking (Risk)</div>
            <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
              <Chip label={`Artistic licence: ${r.artistic.volume}`} color={r.artistic.volume > 3 ? "#dc2626" : "#9ca3af"} sz={9} />
              <Chip label={`Open devs: ${r.open_devs.total}`} color={r.open_devs.total > 6 ? "#d97706" : "#9ca3af"} sz={9} />
              <Chip label={`Target: ${Object.entries(r.artistic.by_domain).sort((a,b)=>b[1]-a[1])[0]?.[0] || "TBD"}`} color="#6b2a10" sz={9} />
            </div>
          </div>
        </div>
        <div style={{ padding: "8px 16px", borderTop: "1px solid #f3f4f6", fontSize: 10, color: "#9ca3af" }}>
          Data: GitHub labels · Collection: docs/collect-metrics.py · Quarterly cadence · governance/metrics.yaml
        </div>
      </div>
    </div>
  );
}
