# Role Card — SME (Subject Matter Expert)

> Your part in the governance process.
> One page. Keep it visible.

---

<!-- BOTTOM LINE UP FRONT
  You know your platform deeply. PA does not.
  You produce SBBs, VSBBs, and standards. PA reviews and approves them.
  When your platform changes or a standard is wrong — raise an
  Operational Feedback Issue. Do not wait for an annual review.
-->

## Who you are

You are single-technology aligned — Cisco DC fabric, F5 load balancing,
Infoblox DNS/DHCP/IPAM, Palo Alto firewall. That depth is your value.
You are not expected to know how your platform interacts with the whole
estate — that is CSD and PA territory.

---

## What you produce

| Artefact | Your role |
|---|---|
| SBB | You produce — PA reviews against ABB capability gates |
| VSBB | You produce — PA reviews against SBB capability gates |
| Standard | You produce when operational reality demands one — PA approves |
| Pattern | You may initiate if practice has stabilised — PA approves |

---

## Domain taxonomy — where your platform lives

Six domains. Know yours:

| Domain | What's in it |
|---|---|
| `wan` | SD-WAN, BGP, MPLS design, internet edge routing |
| `data-centre` | Leaf-spine fabric, VXLAN/EVPN, zone segmentation |
| `security` | Firewalls, WAF, DDoS, SSL inspection — co-owned with Cyber |
| `services` | NLB, GSLB, proxy, VPN, DNS, NTP, syslog, OOB management |
| `campus` | Access switching, wireless |
| `transport` | ISP circuits, MPLS, fibre, DWDM, 4G/5G, satellite, cabling |

Infoblox → `services`. Perimeter firewall → `security`.
WAN router → routing design is `wan`, physical circuit is `transport`.

See `governance/domain-taxonomy.yaml` for boundary cases.

---

## OS versions and feature changes

Architecture governs **features and where they are** — not OS patch level.
OS minor patch differences between sites are operational. Not a finding.

Your obligation when a vendor releases a new version:
- Are any `feature_dependencies` in the VSBB affected?
- Does the config template produce different output on the new OS?

If yes to either: raise an Operational Feedback Issue. Set
`vsbb_os_compatible: needs-review` in deployment register entries.

---

## Resilience — Layer 3 services

If your platform is a Layer 3 service (NLB, DNS, proxy, VPN, NTP),
the resilience tier model applies.

Check the ABB minimum tier. Deployment below minimum → RES-XXX required.

Asymmetric by vendor design (e.g. F5 GTM 2+1 sync group) → VER-XXX
Vendor Evidence Record. Not RES-XXX. See `governance/vendor-evidence/`.

---

## When to write a standard

Valid triggers (operational reality, not PA's initiative):
- Unwritten rule that governs how your platform is configured
- Deviation raised repeatedly signalling a missing rule
- New platform version introducing undocumented norms
- Cross-domain risk exposing a gap

Process: copy `standards/STANDARD-TEMPLATE.yaml`, set `operational_owner`
to yourself, add `co_reviewed_by` if Cyber co-owns, write rules with
MUST / MUST NOT and rationale. Raise a PR.

---

## Your drift obligation

You are `operational_owner` — you flag when reality diverges.
Not annually. When it happens. Raise an **Operational Feedback** Issue.
PA assesses and updates artefacts. PA does not certify annually.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Standard wrong in practice | `operational-feedback.yaml` |
| OS version may affect VSBB | `operational-feedback.yaml` |
| New SBB, VSBB, or standard ready | Raise a Pull Request |

---

*See CONTRIBUTING.md · governance/domain-taxonomy.yaml · ref-arch*
