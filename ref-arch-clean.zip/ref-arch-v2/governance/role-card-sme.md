# Role Card — SME (Subject Matter Expert)

> Your part in the governance process.
> One page. Keep it visible.

---

## Who you are

You are single-technology aligned — you know one platform or domain
deeply. Cisco fabric, F5 load balancing, Infoblox DDI, Checkpoint
firewall. That depth is your value. You are in the networks service
delivery organisation, reporting to a service manager.

You are not expected to know how your platform sits in relation to
others across the estate — that is CSD and PA territory. You are
expected to know your platform correctly and to say when the standards
written about it are wrong.

---

## What you produce

PA does not produce SBBs, VSBBs, or standards — you do.
PA reviews and approves them. PA does not know your platform
at the depth you do.

| Artefact | Your role |
|---|---|
| SBB | You produce — PA reviews against ABB capability gates |
| VSBB | You produce — PA reviews against SBB capability gates |
| Standard | You produce when operational reality demands one — PA approves |
| Pattern | You may initiate if your platform practice has stabilised — PA approves |

---

## When to write a standard

Standards come from operational reality — not from PA deciding one
should exist. Valid triggers:

- An unwritten rule that governs how your platform is configured
- A deviation being raised repeatedly that signals a missing rule
- A new platform version introducing undocumented norms
- A cross-domain risk that exposes a gap in written guidance

When you write one: copy `standards/STANDARD-TEMPLATE.yaml`, set
`operational_owner` to yourself, set `trigger` to what prompted it,
add `co_reviewed_by` if another domain (e.g. Cyber) is involved,
then write the rules using MUST / MUST NOT with rationale. Raise a PR.

---

## Your drift obligation

If you are the `operational_owner` of a standard, SBB, or VSBB,
you are accountable for flagging when reality diverges from it.

This is not an annual review. When your platform changes, when a
vendor deprecates a feature, when operational experience shows a
rule is wrong — raise an **Operational Feedback** GitHub Issue.
PA assesses and updates the artefacts.

PA does not certify your artefacts annually. You flag when they drift.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Operational gap or standard wrong | `operational-feedback.yaml` |
| New SBB, VSBB, or standard ready | Raise a Pull Request |

---

*See CONTRIBUTING.md for full guidance · ref-arch*
