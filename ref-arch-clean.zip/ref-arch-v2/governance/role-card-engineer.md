# Role Card — Engineer

> Your part in the governance process.
> One page. Keep it visible.

---

## Your accountability

You are **Accountable and Responsible** for:
- The topology conformance self-assessment (TC-01, TC-02, TC-03)
- Keeping the deployment register current for your deployments
- Raising deviations **before you build**, not after

---

## Before you start any design

**Check in this order:**

1. **Does an approved Service Blueprint cover this?**
   → `blueprints/service/` — if yes, raise an ITSM request. Done.

2. **Does an approved Pattern cover this?**
   → `patterns/` — if yes, run the topology conformance check below.

3. **No pattern exists?**
   → Raise an Options Paper Request GitHub Issue. Do not design. PA triages first.

---

## Topology Conformance — the three questions

Answer YES to all three before raising a PR.

**TC-01** Are all platforms approved VSBBs?
→ Check `governance/approved-vendor-list.yaml`

**TC-02** Do all traffic flows trace to a named rule in the ZBB boundary contract?
→ Check `zbbs/{zone}/` for ingress/egress rules
→ Does the path traffic takes match the enforcement model?
→ Is every inline component named as an enforcement point?

**TC-03** Can every traffic path be traced to a ZBB rule or approved pattern?
→ If you cannot point to a rule for a flow — it is undocumented.

| All three YES | Self-certify in PR → Solution Design Forum |
| Any NO | Raise Deviation Request Issue first |

---

## The forum

**Thread 1 — Socialise**
Bring work in progress for peer comment. No approval needed. Use it early.

**Thread 2 — Endorsement**
Bring when you need PA endorsement to proceed. Bring with you:
- Completed TC assessment
- Documented deviations (if any)
- Which review stage you are targeting

---

## If you've already built something

1. Run TC-01/02/03 against what you built
2. All pass → retrospective PR with self-certification note
3. Any fail → Deviation Request Issue first (mark retrospective)
4. Cross-domain risk → stop, consult domain owner
5. Already in production → retrospective deviation + remediation plan + target date

The framework is not punitive. A documented retrospective deviation
is a better outcome than an undocumented risk.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Need to deviate from a pattern | `deviation-request.yaml` |
| New capability needed | `options-paper-request.yaml` |
| Thread 2 endorsement | `endorsement-request.yaml` |
| Operational issue found | `operational-feedback.yaml` |
| Business demand signal | `demand-signal.yaml` |

---

## The rule you must never break

> Raise a deviation request **before you build**, not after.
> A deviation in production with no record is a governance finding against you.

---

*See CONTRIBUTING.md for full guidance · ref-arch*
