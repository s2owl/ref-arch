# Role Card — Engineer

> Your part in the governance process.
> One page. Keep it visible.

---

<!-- BOTTOM LINE UP FRONT
  Before you build: TC-01, TC-02, TC-03.
  Any check fails → Deviation Request Issue FIRST. Not after.
  A deviation in production with no record is a governance finding against you.
-->

## The rule — first, not last

> **Raise a Deviation Request Issue before you build, not after.**
> TC-01/02/03 before every PR. Any fail = deviation issue first.
> Production deviation with no record = governance finding against you personally.

---

## Before you start

**In this order:**

1. Service Blueprint exists? → ITSM request. Done.
2. Pattern covers this? → TC-01/02/03. All pass → PR. Any fail → deviation first.
3. Single SBB, no AND? → TC-01 only. PR. Self-certify.
4. Nothing covers this? → Options Paper Request Issue. Do not design yet.

---

## TC-01, TC-02, TC-03

All three YES before raising a PR.

**TC-01** All platforms approved VSBBs?
→ `governance/approved-vendor-list.yaml`

**TC-02** All flows trace to a named ZBB boundary contract rule?
→ Does the path match the enforcement model?
→ Is every inline component named as an enforcement point?

**TC-03** Every traffic path traces to a ZBB rule or approved pattern?
→ Cannot point to a rule = undocumented flow = TC-03 fail.

| All YES | Self-certify in PR → Solution Design Forum |
| Any NO  | Deviation Request Issue first |

PA audits 20% sample quarterly. False self-certification = finding against you.

---

## At deployment — what to record

```
vsbb_ref:              Which config template (governance)
vsbb_version:          Which version (governance)
os_version_at_deploy:  What OS was running (operational only — not a gate)
vsbb_os_compatible:    true | needs-review | incompatible (governance signal)
```

OS version: architecture governs features, not patch level.
Site A at v7, Site B at v8 within the same major version = operational. Not a finding.
OS upgraded beyond VSBB `tested_os_versions` range → set `needs-review`, flag PA.

Resilience: deployment below ABB minimum tier → RES-XXX before deployment.
Asymmetric deployment → check `vendor_evidence_ref` before flagging (VER-001 = F5 GTM).

---

## Security direction — who to follow

Security Architecture policy (via XLINK) beats informal Security Ops direction.
Contradiction → PA. Do not resolve yourself.
You implement what is formally agreed in the boundary contract.
Unsure → Thread 1 question before implementing.

---

## Forum

**Thread 1** — socialise work in progress. No approval. Use early.
**Thread 2** — PA endorsement when needed. Bring: TC assessment, deviations named.

---

## Already built something non-compliant?

1. TC-01/02/03 against what is built
2. All pass → retrospective PR with self-certification note
3. Any fail → Deviation Issue first, mark retrospective
4. In production → retrospective deviation + remediation plan + date

Framework is not punitive. Documented retrospective > undocumented risk.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Deviation from pattern | `deviation-request.yaml` |
| Resilience below minimum | `resilience-exception-request.yaml` |
| Thread 2 endorsement | `endorsement-request.yaml` |
| New capability needed | `options-paper-request.yaml` |
| Operational issue | `operational-feedback.yaml` |

---

*See CONTRIBUTING.md · governance/resilience-tiers.html · ref-arch*
