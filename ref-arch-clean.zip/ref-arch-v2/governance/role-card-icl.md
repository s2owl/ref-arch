# Role Card — In-Country Lead

> Your part in the governance process.
> One page. Keep it visible.

---

<!-- BOTTOM LINE UP FRONT
  You are the local network authority for your country or region.
  For deployments at your site: you and the Product Owner both sign off — two-in-the-box.
  You confirm the physical reality. The PO confirms the business outcome.
  Neither of you can sign off alone.
-->

## Who you are

You are the head of network for a specific country or region. You know
your sites — the physical infrastructure, the local circuits, the
regulatory environment, and the operational reality on the ground.

When a capability is deployed at your site, you are the person who
can confirm whether it was installed correctly — not just whether the
governance artefact says it should have been.

---

## Your accountability

| Decision point | Your role |
|---|---|
| Deployment at your site | **R/A — two-in-the-box with Product Owner** |
| Local regulatory requirements | Consulted — you know the local obligations |
| Site-specific deviations | Consulted — you surface what PA cannot see remotely |
| Operational issues at your site | Responsible for raising via Operational Feedback |

---

## Deployment sign-off — two-in-the-box

When a capability is deployed at your site, two people must confirm
the deployment record:

**You (In-Country Lead)** confirm:
- Physical installation is correct for this site
- Circuits and connectivity match what the design specified
- Zone placement and cabling are as expected
- The local network is in the expected state post-deployment
- Any local regulatory or physical constraints are met

**The Product Owner** confirms:
- The capability delivered matches the business requirement
- Any departures from standard delivery have been formally accepted

Neither of you can sign off alone. Both fields must be populated
in the deployment register before the record is complete.

---

## Why this matters

A deployment record signed only by the engineer who built it has
one perspective — the technical build. It cannot confirm:

- Whether the right thing was built for the right business need
- Whether the physical reality at the site matches the design
- Whether local regulatory requirements were considered
- Whether the local network manager has visibility of what changed

Two-in-the-box gives the deployment record two independent
confirmations from different perspectives. Neither replaces
governance review — it supplements it with local and business
accountability.

---

## Departures from standard resilience

If a deployment at your site is below the standard resilience
model for the capability, you will be asked to confirm alongside
the Product Owner. Plain language — not tier notation.

> "The standard way we deliver [capability] at a site includes
> [description]. This deployment is [what is actually built].
> Do you confirm you are aware of this and accept it for your site?"

Your confirmation goes into the departure record. You are not being
asked to accept the business risk — that is the Product Owner.
You are being asked to confirm that you, as the local network
authority, are aware of the departure and its implications for
your site.

---

## Local regulatory requirements

You are the first line of awareness for local regulatory obligations
that the framework may not capture centrally. If a deployment at
your site has local regulatory implications — data sovereignty,
local privacy law, in-country routing requirements — you raise
this via Thread 1 or Operational Feedback before the deployment
is confirmed.

PA cannot know every local regulatory environment. You are the
signal.

---

## Raising operational issues

If something at your site does not match the governance record —
a device on the wrong SBB version, a circuit that does not match
the design, a resilience posture that differs from what was agreed
— raise an **Operational Feedback** GitHub Issue.

You do not need to diagnose the governance gap. Describe what you
observe. PA assesses and acts.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Site deployment ready to confirm | Update deployment register directly |
| Local issue does not match design | `operational-feedback.yaml` |
| Local regulatory concern | `operational-feedback.yaml` or Thread 1 |

---

*See governance/raci.yaml · deployments/deployment-register.yaml · ref-arch*
