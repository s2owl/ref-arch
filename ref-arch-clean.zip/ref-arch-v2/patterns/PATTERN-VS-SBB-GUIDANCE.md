# Pattern vs SBB — How to Tell the Difference
# ref-arch/patterns/PATTERN-VS-SBB-GUIDANCE.md
#
# Use this when deciding whether something should be an SBB
# or a Pattern, or when reviewing a PR or Thread 1 submission.

---

## The AND rule

**If you need "and" to describe how something works — it is a Pattern.**

A single technology that delivers a capability on its own is an SBB.
Multiple technologies assembled together, where the assembly itself
has constraints, is a Pattern.

```
VXLAN                              → SBB
EVPN                               → SBB
Firewall                           → SBB

VXLAN and EVPN                     → candidate for Pattern
VXLAN and EVPN and Firewall        → Pattern
  (with specific zone insertion
   and traffic flow model)

GRE                                → SBB
IPSla                              → SBB
GRE and IPSla and DNAT             → Pattern
  and cloud proxy egress
```

---

## The three-question test

1. **Does it require "and" to describe?**
   If yes → candidate for Pattern.

2. **Is there a meaningful wrong assembly?**
   Can the components be connected incorrectly in a way that
   creates risk, breaks the capability, or introduces undocumented
   traffic flows? If yes → confirm it is a Pattern.

3. **What does wrong look like specifically?**
   That answer becomes the TC-02 topology constraint in the Pattern record.
   If you cannot name what wrong looks like — the Pattern is not
   specific enough yet. Keep working.

---

## Why this matters

The framework governs approved components via the vendor catalogue.
But approved components assembled incorrectly is the primary risk —
not unapproved components.

A Pattern is the mechanism that captures "here is the correct assembly,
and here is specifically what a non-compliant assembly looks like."
Without the Pattern, topology conformance (TC-02 and TC-03) has nothing
to check against.

---

## Applied examples

| Description | Level | Rationale |
|---|---|---|
| VRRP | SBB | Delivers gateway redundancy alone. No assembly question. |
| HSRP | SBB | Same capability, different vendor SBB. |
| VXLAN | SBB | Data plane encapsulation. Works alone. |
| EVPN | SBB | Control plane for VXLAN. Works alongside VXLAN. Part of `services` or `data-centre` domain depending on context. |
| VXLAN **and** EVPN **and** firewall (macro segmentation) | Pattern | Assembly has specific constraints: firewall insertion point, anycast gateway placement, VNI-to-zone mapping. Multiple wrong assemblies exist. |
| GRE | SBB | Point-to-point tunnel transport. Works alone. |
| IPSla | SBB | Health tracking. Works alone. |
| GRE **and** IPSla **and** DNAT **and** cloud proxy | Pattern | Failover model, egress path, DNAT target, fail-open vs fail-closed are all topology constraints. |
| IPsec | SBB | Encrypted transport. Works alone as a point-to-point mechanism. |
| IPsec **and** routing **and** QoS **and** dual-carrier | Pattern | Hub-and-spoke WAN. Failover model, traffic steering, and carrier diversity define the topology. |
| BGP | SBB | Routing protocol. Works alone. |
| Akamai cloud scrubbing **and** Radware on-premise **and** perimeter firewall | Pattern | DDoS protection ecosystem (PAT-SEC-001). All three required — removing any one leaves a gap. Component order is a TC-02 constraint. |
| Cisco ASA **and** Entra ID **and** Intune | Pattern | Remote access VPN (PAT-SVC-001). All three required for the service to work. IP-as-identity explicitly prohibited at TC-02 level (DEC-003). |
| OSPF | SBB | Same. |
| Spanning Tree | SBB | L2 loop prevention. Works alone. |
| ECMP | SBB | Load distribution alongside routing SBBs. |
| DNS | SBB | Name resolution. Works alone. |

---

## The VXLAN/EVPN edge case

VXLAN and EVPN are almost always deployed together but they are
separate SBBs. VXLAN is the data plane. EVPN is the control plane.
The fact that your standard mandates EVPN as the control plane for
VXLAN is a rule in STD-SWR-001 — not a reason to merge them into
one SBB.

The Pattern is what captures "these must be used together, with these
specific BGP peering, VNI, and gateway constraints." The SBBs
exist independently and may be referenced by multiple patterns.

---

## Macro network segmentation — the worked example

```
Components:
  SBB-SWR-001   VXLAN (data plane encapsulation)
  SBB-SWR-002   EVPN (control plane)
  SBB-SEC-001   Firewall (zone boundary enforcement, Cyber co-owns)

Pattern: PAT-DC-001 — Macro Network Segmentation

TC-02 topology constraints (the wrong assemblies):
  - Firewall inserted at zone boundary only —
    not inline on intra-zone traffic
  - Anycast gateway on the leaf switch —
    not on the firewall (asymmetric routing = TC-02 fail)
  - VNI-to-zone mapping is 1:1 —
    multiple zones sharing a VNI = TC-02 fail
  - North-south traffic transits firewall —
    east-west within zone does not
```

These constraints exist in senior engineers' heads today.
The Pattern record is what makes them checkable and auditable.

---

---

## DDoS — the AND rule in the security domain

```
Components:
  VSBB-AKA-XXX   Akamai cloud scrubbing (volumetric)
  VSBB-RAD-XXX   Radware on-premise (application layer)
  VSBB-[FW]-XXX  Perimeter firewall (zone boundary enforcement)

All in ZBB-INTERNET-EDGE-001.

Pattern: PAT-SEC-001 — DDoS Protection Ecosystem

TC-02 topology constraints:
  - Akamai must be upstream of Radware (scrubbing order)
  - Radware must be upstream of firewall (clean traffic to firewall)
  - Auto-diversion to Akamai must be automatic — not manual
  - All three components must be in ZBB-INTERNET-EDGE-001
```

Without the pattern: nothing enforces the component order.
An engineer could deploy all three approved VSBBs in the wrong sequence.
TC-01 passes. TC-02 fails against PAT-SEC-001.

---

## Remote Access VPN — the AND rule with an identity constraint

```
Components:
  SBB-VPN-001            Cisco ASA (termination)
  SBB-IDENTITY-ENTRA-XXX Entra ID (MFA / Conditional Access)
  SBB-MDM-INTUNE-XXX     Intune (device compliance)

Pattern: PAT-SVC-001 — Remote Access VPN

TC-02 topology constraints:
  - Authentication MUST be Entra ID — not source IP (DEC-003)
  - Intune compliance check MUST complete before tunnel establishment
  - VPN terminates in VPN zone — not APP or DATA zone
  - No split tunnel
  - IKEv2 / AES-256 minimum
```

The pattern is also where the IP-as-identity prohibition (DEC-003)
becomes a machine-checkable TC-02 constraint rather than just a
principle in a document. Any deployment where source IP is used for
access control fails TC-02 against PAT-SVC-001.

---

*See patterns/PATTERN-TEMPLATE.yaml to create a new pattern.*
*See zbbs/TOPOLOGY-CONFORMANCE.yaml for the TC-01/02/03 check model.*
