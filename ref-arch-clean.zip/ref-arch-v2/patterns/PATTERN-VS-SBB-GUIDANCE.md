# Pattern vs SBB — How to Tell the Difference
# ref-arch/patterns/PATTERN-VS-SBB-GUIDANCE.md
#
# Use this when deciding whether something should be an SBB
# or a Pattern, or when reviewing a PR or Thread 1 submission.

---

## The AND rule

**If you need "and" to describe how something works — it is a Pattern.**

A single technology that delivers a capability on its own is an SBB.
Multiple technologies assembled together, where the assembly itself
has constraints, is a Pattern.

```
VXLAN                              → SBB
EVPN                               → SBB
Firewall                           → SBB

VXLAN and EVPN                     → candidate for Pattern
VXLAN and EVPN and Firewall        → Pattern
  (with specific zone insertion
   and traffic flow model)

GRE                                → SBB
IPSla                              → SBB
GRE and IPSla and DNAT             → Pattern
  and cloud proxy egress
```

---

## The three-question test

1. **Does it require "and" to describe?**
   If yes → candidate for Pattern.

2. **Is there a meaningful wrong assembly?**
   Can the components be connected incorrectly in a way that
   creates risk, breaks the capability, or introduces undocumented
   traffic flows? If yes → confirm it is a Pattern.

3. **What does wrong look like specifically?**
   That answer becomes the TC-02 topology constraint in the Pattern record.
   If you cannot name what wrong looks like — the Pattern is not
   specific enough yet. Keep working.

---

## Why this matters

The framework governs approved components via the vendor catalogue.
But approved components assembled incorrectly is the primary risk —
not unapproved components.

A Pattern is the mechanism that captures "here is the correct assembly,
and here is specifically what a non-compliant assembly looks like."
Without the Pattern, topology conformance (TC-02 and TC-03) has nothing
to check against.

---

## Applied examples

| Description | Level | Rationale |
|---|---|---|
| VRRP | SBB | Delivers gateway redundancy alone. No assembly question. |
| HSRP | SBB | Same capability, different vendor SBB. |
| VXLAN | SBB | Data plane encapsulation. Works alone. |
| EVPN | SBB | Control plane for overlay. Works alongside VXLAN. |
| VXLAN **and** EVPN **and** firewall (macro segmentation) | Pattern | Assembly has specific constraints: firewall insertion point, anycast gateway placement, VNI-to-zone mapping. Multiple wrong assemblies exist. |
| GRE | SBB | Point-to-point tunnel transport. Works alone. |
| IPSla | SBB | Health tracking. Works alone. |
| GRE **and** IPSla **and** DNAT **and** cloud proxy | Pattern | Failover model, egress path, DNAT target, fail-open vs fail-closed are all topology constraints. |
| IPsec | SBB | Encrypted transport. Works alone as a point-to-point mechanism. |
| IPsec **and** routing **and** QoS **and** dual-carrier | Pattern | Hub-and-spoke WAN. Failover model, traffic steering, and carrier diversity define the topology. |
| BGP | SBB | Routing protocol. Works alone. |
| OSPF | SBB | Same. |
| Spanning Tree | SBB | L2 loop prevention. Works alone. |
| ECMP | SBB | Load distribution alongside routing SBBs. |
| DNS | SBB | Name resolution. Works alone. |

---

## The VXLAN/EVPN edge case

VXLAN and EVPN are almost always deployed together but they are
separate SBBs. VXLAN is the data plane. EVPN is the control plane.
The fact that your standard mandates EVPN as the control plane for
VXLAN is a rule in STD-SWR-001 — not a reason to merge them into
one SBB.

The Pattern is what captures "these must be used together, with these
specific BGP peering, VNI, and gateway constraints." The SBBs
exist independently and may be referenced by multiple patterns.

---

## Macro network segmentation — the worked example

```
Components:
  SBB-SWR-001   VXLAN (data plane encapsulation)
  SBB-SWR-002   EVPN (control plane)
  SBB-SEC-001   Firewall (zone boundary enforcement, Cyber co-owns)

Pattern: PAT-DC-001 — Macro Network Segmentation

TC-02 topology constraints (the wrong assemblies):
  - Firewall inserted at zone boundary only —
    not inline on intra-zone traffic
  - Anycast gateway on the leaf switch —
    not on the firewall (asymmetric routing = TC-02 fail)
  - VNI-to-zone mapping is 1:1 —
    multiple zones sharing a VNI = TC-02 fail
  - North-south traffic transits firewall —
    east-west within zone does not
```

These constraints exist in senior engineers' heads today.
The Pattern record is what makes them checkable and auditable.

---

*See patterns/PATTERN-TEMPLATE.yaml to create a new pattern.*
*See zbbs/TOPOLOGY-CONFORMANCE.yaml for the TC-01/02/03 check model.*
