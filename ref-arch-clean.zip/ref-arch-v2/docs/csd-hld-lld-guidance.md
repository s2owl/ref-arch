<!-- BOTTOM LINE UP FRONT
  HLD = Pattern (PAT-XXX). If one exists for your topology, the HLD is already written.
  LLD = VSBB config template + variable file. You populate the variables, not a Word doc.
  Pattern exists + TC-01/02/03 pass → raise PR, self-certify. No ARB slot needed.
  Pattern doesn't exist → bring it to Thread 1. PA codifies it. Then use the pattern.
  Full explanation below.
-->

# HLD and LLD in the Framework
# docs/csd-hld-lld-guidance.md
#
# For: Connectivity Solution Designers
# Purpose: Explains how High Level Design and Low Level Design
#          map onto the framework hierarchy — and what that
#          means for how you work day to day.

---

## The short answer

| What you called it | What the framework calls it |
|---|---|
| High Level Design (HLD) | Pattern (PAT-XXX) |
| Low Level Design (LLD) | VSBB + variable file |

That's not just a renaming exercise. The mapping changes how you produce them, who reviews them, and how they accumulate value over time. This page explains why.

---

## What an HLD actually is

An HLD answers: **what components do I need and how do they connect?**

It is vendor-agnostic. It has no IP addresses. No interface names. No config. It describes the topology — which building blocks are needed, how they assemble, and what the constraints are.

In this framework that is a **Pattern**.

```
PAT-DC-001 — Macro Network Segmentation

Components:
  VXLAN (SBB)  AND  EVPN (SBB)  AND  Firewall (SBB)

Assembly constraints (TC-02):
  Firewall at zone boundary only — not inline on intra-zone traffic
  Anycast gateway on the leaf — not on the firewall
  VNI-to-zone mapping 1:1 — no shared VNIs between zones
  North-south via firewall — east-west within zone direct
```

That IS an HLD. A complete, approved, version-controlled HLD for DC macro segmentation. You do not write a new one. You use it.

---

## What an LLD actually is

An LLD answers: **how is this specific instance configured?**

It is vendor-specific. It has IP addresses, interface names, VLANs, ASNs, version numbers. It describes one deployment at one site on specific hardware.

In this framework that is a **VSBB + variable file**.

```
VSBB-CIS-NXS-001 — Cisco NX-OS EVPN/VXLAN
  The config template. Parameterised. Reusable.
  Same template for every NX-OS deployment.
  This is the LLD structure.

variables/SITE-LON-01/leaf-01a.yaml
  server_ip: 10.10.210.45
  vlan_id: 210
  interface: Ethernet1/15
  spine_asn: 65001
  This is the LLD content for this specific device.
```

Together — VSBB template + variable file = the LLD for that deployment. Not a Word document. A version-controlled artefact pair that can be reviewed, approved, and reused.

---

## Why this is better than a Word document

Traditional HLD/LLD documents have three problems.

**Problem 1 — They are one-off.**
The HLD you write for Project X has no relationship to the HLD for Project Y even if they describe the same topology. The same design decisions are made repeatedly. Nobody builds on previous work.

In this framework: PAT-DC-001 is the approved HLD for DC macro segmentation for every project. When the pattern improves — every future project inherits the improvement. Knowledge accumulates.

**Problem 2 — They don't govern.**
A Word document in SharePoint is not a governance artefact. It cannot be cited in a TC-02 check. It cannot be referenced in a deviation. It exists but it doesn't control anything. An auditor cannot trace a deployed config back to it.

In this framework: a pattern has a version, an approval record, and TC-02 constraints that are checkable. A VSBB has a variable schema. A deployment register entry references both. The audit trail exists.

**Problem 3 — The LLD is where artistic licence lives.**
When you write an LLD in Word, you make dozens of micro-decisions that are never formally reviewed. Gateway here, firewall there, redistribute this route. Buried in a document nobody reads again. That is where non-compliant topologies come from.

In this framework: the pattern captures what the correct assembly looks like and what wrong looks like. The variable schema defines which configuration values are architectural (not overridable) and which are instance-level (your choice within validated ranges). The scope for undocumented decisions is explicitly bounded.

---

## What you actually do when you need to design something

### Step 1 — Does an approved pattern cover this?

Check `patterns/` in the framework.

```
YES → The HLD is already written.
      Run TC-01/02/03 self-assessment against the pattern.
      All pass → raise a PR with the VSBB + variable file.
      Any fail → raise a Deviation Request Issue before the PR.
      No Word document needed. No separate ARB slot needed.

NO  → The HLD doesn't exist yet.
      Go to Step 2.
```

### Step 2 — No pattern exists

This is the HLD conversation — and it happens in Thread 1, not in a Word document.

Bring the design to Thread 1. Walk through:
- What components are needed (the SBBs)
- How they connect (the assembly)
- What the constraints are (what wrong looks like)

PA will work with you to codify this as a new pattern. The pattern IS the HLD output. It is version-controlled, approved, and available to every future project from that point forward.

The traditional HLD review meeting at ARB is replaced by Thread 1 — earlier, lighter, and producing a reusable artefact rather than a one-off document.

### Step 3 — Produce the LLD (the VSBB + variable file)

Once a pattern exists:

1. Find the right VSBB for the vendor platform you are deploying.
   Check `net-config/{vendor}/vendor-sbbs/`.

2. Copy the variable file template for the site.
   Check `net-config/{vendor}/group-vars/` for site-level variables (Type 2 — pre-populated, do not change).
   Populate `net-config/{vendor}/host-vars/` for device-specific values (Type 3 — your values).

3. Before you fill in the variable file — check the variable schema.
   Some variables are Type 1 (architectural — pre-populated, do not override).
   Changing a Type 1 variable is a deviation, not an operational choice.
   The most important example: `redistribute_default_route`.
   See `docs/variable-governance-strawman.md` for the full list.

4. Complete TC-01/02/03 self-assessment.
   The pattern tells you exactly what to check.
   All pass → raise the PR.
   Any fail → raise a Deviation Request Issue first.

---

## When you still need a document

There are two situations where a formal design document is still appropriate.

**Options paper (OP-XXX)**
When a requirement has no existing pattern and the design decision is strategic — new capability, new geography, new technology. The options paper is the governance artefact for that decision. It is structured (SPIN format) and goes through Thread 2 → ARG → DA. This is not an HLD. It is a decision document.

**Connectivity Construct (CC-XXX)**
When a solution is a point-to-point connection between specific named endpoints that is not repeatable as a pattern. A CC record documents the specific solution — endpoints, transport, purpose, ZBB boundary, lifecycle. This is the closest thing to a traditional LLD for a one-off connection.

---

## The summary in one table

| Traditional | This framework | What changes |
|---|---|---|
| Write an HLD | Check for an existing Pattern | You consume rather than produce for covered requirements |
| HLD reviewed at ARB | Thread 1 socialise, PA codifies the Pattern | Earlier, lighter, reusable output |
| Write an LLD | Populate VSBB + variable file | Structured template, governed variables, version-controlled |
| LLD reviewed at ARB | TC-01/02/03 self-certification + PR | Self-service for compliant solutions |
| File in SharePoint | Pattern and VSBB in ref-arch and net-config | Traceable, version-controlled, reusable |
| Next project starts again | Next project uses same Pattern and VSBB | Knowledge accumulates, overhead decreases |

---

## The most important thing to understand

When you use an existing pattern and VSBB, you are not producing a design from scratch. You are **instantiating an approved design**.

The HLD was approved when the pattern was approved.
The LLD template was approved when the VSBB was approved.
Your job is to provide the instance-specific values (the variable file) and confirm the topology conforms (TC-01/02/03).

That is a significantly smaller governance surface than producing a new design document for every project — and it produces a much better audit trail.

---

## Quick reference

```
I need to design something new
    ↓
Does a pattern cover it?
    YES → TC-01/02/03 → PR (self-certify) or deviation
    NO  → Thread 1 → PA codifies pattern → then YES path

I need to produce the device config
    ↓
Find the VSBB for the vendor
Check the variable schema (Type 1 variables: do not touch)
Populate the variable file (Type 2: pre-populated, Type 3: yours)
TC-01/02/03 → PR

I have a one-off point-to-point connection
    ↓
Connectivity Construct (CC-XXX)
Pattern check: should this be a pattern instead?

I have a strategic decision with no existing pattern
    ↓
Options paper (OP-XXX) → Thread 2 → ARG/DA
```

---

*See `patterns/PATTERN-VS-SBB-GUIDANCE.md` for the AND rule — when something is a pattern vs an SBB.*
*See `docs/variable-governance-strawman.md` for which variables are governance-relevant.*
*See `CONTRIBUTING.md` for the full governance process.*
