# Confluence Publishing — Setup Guide
# docs/confluence-setup.md
#
# One-time setup. Do this before the first pipeline run.
# After setup, publishing is fully automated on merge to main.

---

## What gets published

| Source file (GitHub) | Confluence page |
|---|---|
| governance/process-map.html | Network Architecture Governance / Process Map |
| governance/consumption-map.html | Network Architecture Governance / Consumption & Dependency Map |
| governance/role-card-engineer.md | Network Architecture Governance / Role Cards / Engineer |
| governance/role-card-csd.md | Network Architecture Governance / Role Cards / CSD |
| governance/role-card-sme.md | Network Architecture Governance / Role Cards / SME |
| governance/role-card-mgr.md | Network Architecture Governance / Role Cards / Service Manager |
| governance/role-card-pa.md | Network Architecture Governance / Role Cards / Principal Architect |
| governance/CONTRIBUTING-summary.md | Network Architecture Governance / How to Contribute |
| governance/raci-summary.md | Network Architecture Governance / RACI Summary |

---

## Step 1 — Create the Confluence space structure

In your Confluence instance, create the following page hierarchy.
These are the pages the pipeline will update. The page titles must
match exactly — the pipeline identifies pages by title within the space.

```
Network Architecture Governance          ← parent page (space home or top-level)
├── Process Map
├── Consumption & Dependency Map
├── How to Contribute
├── RACI Summary
└── Role Cards                           ← parent page
    ├── Engineer
    ├── Connectivity Solution Designer (CSD)
    ├── Subject Matter Expert (SME)
    ├── Service Manager
    └── Principal Architect
```

Create them as blank pages initially. The pipeline will populate the content.

---

## Step 2 — Get your Confluence details

You need three values:

**Confluence base URL**
Your Confluence instance URL. Examples:
- Cloud:  `https://your-org.atlassian.net/wiki`
- Server: `https://confluence.your-org.com`

**Space key**
The short key for your Confluence space. Find it in:
Space Settings → Space Key (usually 2-10 uppercase letters, e.g. NETARCH)

**Parent page ID**
The numeric ID of the "Network Architecture Governance" parent page.
Find it by opening the page and looking at the URL:
`https://your-org.atlassian.net/wiki/spaces/NETARCH/pages/123456789/...`
                                                              ^^^^^^^^^
That number is the page ID.

---

## Step 3 — Create a Confluence API token

**Confluence Cloud:**
1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Create a token named "GitHub Actions — Network Architecture Governance"
3. Copy the token value immediately (shown once only)

**Confluence Server / Data Center:**
1. Go to your profile → Personal Access Tokens
2. Create a token with read/write access to your space
3. Copy the token value

---

## Step 4 — Add GitHub Secrets

In your GitHub repository: Settings → Secrets and variables → Actions → New repository secret

| Secret name | Value |
|---|---|
| `CONFLUENCE_BASE_URL` | Your Confluence URL (no trailing slash) |
| `CONFLUENCE_SPACE_KEY` | Your space key (e.g. NETARCH) |
| `CONFLUENCE_PARENT_PAGE_ID` | The numeric page ID from Step 2 |
| `CONFLUENCE_USER_EMAIL` | Your email address (Cloud only — not needed for Server) |
| `CONFLUENCE_API_TOKEN` | The token from Step 3 |

---

## Step 5 — Update the page map

Edit `docs/confluence-page-map.yaml` and add the page IDs for each page
you created in Step 1. Get the ID from each page URL as described above.

The pipeline uses these IDs to update the correct pages. Without them
it will fail on the first run.

---

## Step 6 — Test the pipeline

Push a small change to any file in `governance/` to main.
Watch the Actions tab in GitHub — the "Publish to Confluence" workflow
should trigger and complete successfully.

Check the Confluence pages — content should now be populated.

---

## Troubleshooting

**401 Unauthorized**
API token is wrong or expired. Regenerate and update the GitHub Secret.

**404 Not Found on page update**
Page ID in confluence-page-map.yaml is incorrect.
Check the page URL and update the map.

**403 Forbidden**
The API token user doesn't have edit permission on the space.
Add the user as a space admin or editor.

**Content looks wrong (tables broken, code blocks missing)**
The Markdown → Confluence conversion is best-effort.
HTML pages (process maps) render correctly via iframe.
For complex Markdown, edit the Confluence page template in
docs/publish-to-confluence.py to adjust the conversion rules.

---

## Keeping it in sync

The pipeline runs on every merge to main that touches `governance/`.
No manual action required after initial setup.

If you rename a source file, update `docs/confluence-page-map.yaml`
to point to the new filename. The Confluence page ID stays the same.

If you want to add a new page to the published set, create the
Confluence page manually, get its ID, add it to the page map,
and add the source file path to the workflow's path filter.
