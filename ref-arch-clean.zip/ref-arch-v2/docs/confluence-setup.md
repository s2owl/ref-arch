# Confluence Publishing — Setup Guide
# docs/confluence-setup.md
#
# The publish script fetches files directly from GitHub Enterprise
# via the API and pushes them to Confluence Server/Data Center.
# No local clone needed. No third-party packages. Standard library only.

---

## What gets published

| Page ID | Source in GHE | Confluence page title |
|---|---|---|
| `vision` | `governance/vision.html` | Vision |
| `roadmap` | `governance/roadmap.html` | Roadmap |
| `process-map` | `governance/process-map.html` | Process Map |
| `consumption-map` | `governance/consumption-map.html` | Consumption and Dependency Map |
| `raci` | `governance/raci.html` | RACI |
| `contributing` | `CONTRIBUTING.md` | How to Contribute |
| `role-engineer` | `governance/role-card-engineer.md` | Role Card — Engineer |
| `role-csd` | `governance/role-card-csd.md` | Role Card — Connectivity Solution Designer |
| `role-sme` | `governance/role-card-sme.md` | Role Card — SME |
| `role-mgr` | `governance/role-card-mgr.md` | Role Card — Service Manager |
| `role-pa` | `governance/role-card-pa.md` | Role Card — Principal Architect |

---

## Prerequisites

- Python 3 available in your environment
- A GitHub Enterprise PAT with `repo` (read) scope
- A Confluence Server/Data Center PAT with page edit permission

---

## Step 1 — Create the Confluence page structure

Create these pages in Confluence. Titles must match exactly.

```
Network Architecture Governance          ← parent page
├── Vision
├── Roadmap
├── Process Map
├── Consumption and Dependency Map
├── RACI
├── How to Contribute
└── Role Cards                           ← parent page
    ├── Role Card — Engineer
    ├── Role Card — Connectivity Solution Designer
    ├── Role Card — SME
    ├── Role Card — Service Manager
    └── Role Card — Principal Architect
```

Leave them blank — the script populates the content.

---

## Step 2 — Get Confluence page IDs

For each page, open it in Confluence and get the numeric ID from the URL:

```
https://confluence.your-org.com/pages/123456789/Vision
                                        ^^^^^^^^^
                                        This is the page ID
```

---

## Step 3 — Edit the script

Open `docs/publish-to-confluence.py` and:

**1. Set the configuration block** (or use environment variables — preferred):

```python
GHE_TOKEN           = "ghp_xxxxxxxxxxxx"
GHE_BASE_URL        = "https://github.your-org.com"
GHE_REPO            = "your-org/ref-arch"
CONFLUENCE_TOKEN    = "xxxxxxxxxxxx"
CONFLUENCE_BASE_URL = "https://confluence.your-org.com"
```

**2. Populate the page IDs** in the PAGES list:

```python
{
    "id": "process-map",
    "confluence_page_id": 123456789,    # ← add your page ID here
},
```

---

## Step 4 — Test with dry run

```bash
python docs/publish-to-confluence.py --dry-run
```

Fetches from GHE and validates conversion without writing to Confluence.

---

## Step 5 — Publish

```bash
# All pages
python docs/publish-to-confluence.py

# Single page
python docs/publish-to-confluence.py --page process-map

# List configured pages and their status
python docs/publish-to-confluence.py --list
```

---

## Using environment variables (recommended)

```bash
export GHE_TOKEN="ghp_xxxxxxxxxxxx"
export GHE_BASE_URL="https://github.your-org.com"
export GHE_REPO="your-org/ref-arch"
export CONFLUENCE_TOKEN="xxxxxxxxxxxx"
export CONFLUENCE_BASE_URL="https://confluence.your-org.com"

python docs/publish-to-confluence.py
```

---

## When to run

Run manually after significant changes to governance artefacts —
after merging changes to `governance/`, before a forum session,
or after quarterly metrics updates.

---

## HTML macro note

HTML pages use the Confluence HTML macro. To check if it is enabled:
try inserting an HTML macro on any Confluence page. If unavailable,
contact your Confluence administrator or link to the GitHub Pages URL.

---

## Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| 401 from GHE | PAT expired or wrong scope | Regenerate with `repo` scope |
| 401 from Confluence | PAT expired | Regenerate |
| 404 from Confluence | Wrong page ID | Check the page URL |
| 403 from Confluence | Insufficient permission | Add edit permission to PAT user |
| HTML not rendering | HTML macro disabled | Contact Confluence admin |

---

## ServiceNow integration (collect-metrics.py)

The metrics collector can query ServiceNow for CR governance linkage data.

```bash
# Full collection — GitHub + YAML health sweep + SNOW prompt
python docs/collect-metrics.py --quarter 2025-Q3

# Skip SNOW (GitHub + YAML sweep only)
python docs/collect-metrics.py --quarter 2025-Q3 --skip-snow

# Skip YAML health sweep
python docs/collect-metrics.py --quarter 2025-Q3 --skip-yaml-health

# With network team assignment group filter (Option A — when ready)
python docs/collect-metrics.py --quarter 2025-Q3 \
  --snow-assignment-groups "Network Engineering" "Network Architecture"

# With CI class filter (Option B — when CMDB data quality supports it)
python docs/collect-metrics.py --quarter 2025-Q3 \
  --snow-ci-classes "cmdb_ci_network_switch" "cmdb_ci_network_router"
```

SNOW env vars:
```bash
export SNOW_BASE_URL="https://your-instance.service-now.com"
export SNOW_TOKEN="your-token"
export SNOW_AUTH_TYPE="bearer"   # or basic
export SNOW_SKIP="1"             # set to skip SNOW entirely
```

The current scoping is Option C (all CRs in the period) — an honest
baseline. The CR governance linkage rate is expected to be low initially.
That is the point — it surfaces the gap before the CAB integration
process is embedded.

When the SNOW NC/Tech Services initiative lands, add the field linkage
to the script and the tech_services_linkage field in metrics.yaml will
start populating.
