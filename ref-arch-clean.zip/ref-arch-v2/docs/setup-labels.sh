#!/bin/bash
# docs/setup-labels.sh
# Creates all governance labels in the GitHub repository.
# Run once before go-live. Requires GitHub CLI (gh) authenticated.
#
# Usage:
#   chmod +x docs/setup-labels.sh
#   ./docs/setup-labels.sh
#
# Prerequisites:
#   gh auth login
#   gh auth status

set -e

REPO=$(gh repo view --json nameWithOwner -q .nameWithOwner)
echo "Creating labels for: $REPO"

create_label() {
  local name="$1" color="$2" description="$3"
  gh label create "$name" \
    --color "$color" \
    --description "$description" \
    --force 2>/dev/null && echo "  ✓ $name" || echo "  ~ $name (already exists)"
}

echo ""
echo "── Type labels ──────────────────────────────"
create_label "type:deviation"           "8B1A1A" "Deviation from approved pattern or ZBB boundary contract"
create_label "type:endorsement"         "2D5986" "Thread 2 endorsement request"
create_label "type:options-paper"       "5C3D8B" "Options paper request or submission"
create_label "type:demand-signal"       "1A6B5C" "Business demand signal for new capability"
create_label "type:operational-feedback" "6B4A1A" "Operational feedback — standard or SBB drift"
create_label "type:question"            "4A6B2D" "Question for architecture team"
create_label "type:reclassification"    "8B6B1A" "Legacy tech-service-as-app reclassification"
create_label "type:new-pattern"         "1A4A6B" "New pattern proposed"
create_label "type:new-standard"        "1A4A6B" "New standard proposed"
create_label "type:compliant-solution"  "1A6B3A" "PR — compliant solution, TC-01/02/03 pass"
create_label "type:retrospective"       "8B3A1A" "Retrospective submission"

echo ""
echo "── Domain labels ────────────────────────────"
create_label "domain:dc-fabric"         "1E3D5C" "Data centre fabric"
create_label "domain:security-boundary" "6B1A1A" "Security boundary"
create_label "domain:wan"               "1A5C4E" "WAN and SD-WAN"
create_label "domain:remote-access"     "3D1E5C" "Remote access VPN and ZTNA"
create_label "domain:proxy-egress"      "5C4E1A" "Proxy and internet egress"
create_label "domain:ddi"               "1A3D5C" "DNS, DHCP, IPAM"
create_label "domain:load-balancing"    "2D5C1A" "Load balancing"
create_label "domain:wireless"          "5C1A4E" "Wireless and campus"
create_label "domain:optical-transport" "4E5C1A" "DWDM and optical transport"
create_label "domain:cross-domain"      "8B4A1A" "Spans multiple domains"

echo ""
echo "── Status labels ────────────────────────────"
create_label "status:awaiting-pa"       "D97706" "Awaiting PA review or decision"
create_label "status:awaiting-submitter" "6B6660" "Awaiting submitter action"
create_label "status:awaiting-cyber"    "6B1A1A" "Blocked — awaiting Cyber input"
create_label "status:awaiting-da"       "3D1E5C" "PA-endorsed — awaiting DA"
create_label "status:in-progress"       "1A5C4E" "Actively being worked"
create_label "status:blocked"           "8B1A1A" "Blocked"
create_label "status:remediation-open"  "D97706" "Open remediation"

echo ""
echo "── Outcome labels ───────────────────────────"
create_label "outcome:endorsed"                 "1A6B3A" "PA endorsed"
create_label "outcome:endorsed-with-conditions" "D97706" "PA endorsed with conditions"
create_label "outcome:not-endorsed"             "8B1A1A" "Not endorsed"
create_label "outcome:approved"                 "1A6B3A" "Approved"
create_label "outcome:closed-no-action"         "6B6660" "Closed — no action"
create_label "outcome:withdrawn"                "6B6660" "Withdrawn"
create_label "outcome:escalated"                "8B1A1A" "Escalated to ARG/DA"

echo ""
echo "── Decision point labels ────────────────────"
create_label "dp:02-compliant-solution"  "B0C4D8" "DP-02 Compliant solution"
create_label "dp:03-deviation"           "C8B0D8" "DP-03 Deviation"
create_label "dp:04-new-capability"      "B0C4D8" "DP-04 New capability"
create_label "dp:07-endorsement"         "B0C4D8" "DP-07 Endorsement"
create_label "dp:08-deviation-approval"  "C8B0D8" "DP-08 Deviation approval"
create_label "dp:10-operational-feedback" "D8C8B0" "DP-10 Operational feedback"

echo ""
echo "── Programme labels ─────────────────────────"
create_label "programme:PROG-001-sase"       "B0D8C8" "SASE/SD-WAN programme"
create_label "programme:PROG-002-ip-identity" "B0D8C8" "IP identity programme"
create_label "programme:PROG-003-ztna"       "B0D8C8" "ZTNA programme"

echo ""
echo "── Risk labels ──────────────────────────────"
create_label "risk:PCI-DSS"    "D8B0B0" "PCI-DSS v4.0"
create_label "risk:DORA"       "D8B0B0" "DORA Arts 5-9"
create_label "risk:PRA-SS2/21" "D8B0B0" "PRA SS2/21"

echo ""
echo "── Headcount evidence labels ────────────────"
create_label "evidence:pa-bottleneck"    "FFB347" "PA bottleneck evidence"
create_label "evidence:capability-gap"   "FFB347" "CSD capability gap evidence"
create_label "evidence:artistic-licence" "FF6B6B" "Artistic licence deviation"

echo ""
echo "Done. $(gh label list --limit 100 | wc -l) labels now in $REPO"
