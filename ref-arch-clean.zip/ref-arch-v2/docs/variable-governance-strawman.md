<!-- BOTTOM LINE UP FRONT
  This is a STRAW MAN FOR DEBATE — not a decision, not implemented yet.
  The one thing to know right now (Phase 1, no tooling needed):
  Some config variables are governance decisions, not operational choices.
  The clearest example: redistribute_default_route.
  Changing that from deny to permit is a ZBB boundary contract event.
  It requires a deviation record. Not an ops ticket.
  The full taxonomy and debate questions are in the document below.
-->

# VARIABLE GOVERNANCE — STRAW MAN
# docs/variable-governance-strawman.md
#
# STATUS: Straw man for debate. Not implemented. Not a decision.
#
# PURPOSE:
#   Variables are where the governance model and the engineering model
#   meet. This document proposes a variable taxonomy and schema model,
#   explains why it matters for regulatory demonstrability, and raises
#   the debate questions that must be answered before building.
#
# USE THIS TO:
#   - Debate the right separation of concerns between framework,
#     site, and instance variables
#   - Understand where today's framework has a gap
#   - Frame the investment case for variable schema enforcement
#   - Show the end-to-end chain from regulatory obligation to
#     deployed config

---

## What variables are and why they matter

A VSBB (Vendor Solution Building Block) is a parameterised config
template. Variables are the values that make that template specific
to a deployment instance.

```
Template (VSBB)           Variables                  Rendered config
─────────────────         ──────────────             ───────────────
interface {{ port }}      port: Ethernet1/1   →      interface Ethernet1/1
  speed {{ speed }}       speed: 10G          →        speed 10G
  vlan {{ vlan_id }}      vlan_id: 210        →        vlan 210
```

Variables look like an engineering implementation detail. They are not.

**They are the governance boundary between what is approved and what
is deployed.**

The VSBB template is what PA approved. The rendered config — template
plus variables — is what actually runs on a device. If the variables
are wrong, the deployment violates the pattern even though the template
is correct.

```
Example failure:
  PAT-DC-001 requires anycast gateway on the leaf switch.
  VSBB template correctly places the gateway on the leaf.
  Engineer sets: gateway_interface: firewall_vlan
  Rendered config puts the gateway on the firewall.
  TC-02 violation. PCI CDE boundary enforcement broken.
  The template was approved. The deployment was not.
```

This is artistic licence expressed at the variable level. The template
is right. The variable choice is wrong. Today there is nothing that
prevents it.

---

## The governance boundary — what is and is not in scope

Not every variable in a config template is a governance concern.
Getting an interface description wrong is an operational problem.
Getting a route redistribution policy wrong can break a ZBB boundary
contract and violate PCI CDE isolation. These are fundamentally
different problems.

**The test:**

> If this variable's value changed, would it violate a TC-02
> topology constraint, a ZBB boundary contract, a regulatory
> control, or an architecture decision record?
>
> **Yes** → governance-relevant. Type 1 variable.
> **No**  → operational. Not in scope for variable governance.

**Out of scope — operational, not governed:**

```
Interface descriptions      "GE0/0 — uplink to spine-01"
                            Getting this wrong is an ops problem.
                            A deviation register entry adds no value.

Port VLAN membership        "switchport access vlan 210"
                            The VLAN was assigned by IPAM. It's
                            correct or it isn't. Governance doesn't
                            help here — IPAM does.

Individual prefix entries   "network 10.10.210.0/24"
                            Operational detail. Too granular.

Summary route decisions     "summary-address 10.10.0.0/16"
                            An operational choice. Summarisation
                            doesn't affect boundary enforcement or
                            zone traffic paths.

Interface MTU               "mtu 9000"
                            Operational. Agreed via TSS-001 before
                            deployment. Coordination problem, not
                            a governance problem.
```

**In scope — governance-relevant:**

```
Default route redistribution  Redistributing a default route from
                              EIGRP into BGP is not a routing policy
                              detail. It is a ZBB boundary contract
                              event. See the worked example below.

Route domain boundaries       Which protocols exchange routes at a
                              boundary point. Defines what can cross
                              between routing domains.

Redistribution policy ref     Which route-map governs the redistribution.
                              The route-map is the enforcement mechanism —
                              it must reference an approved policy.

BGP default originate         Whether a device originates a default
                              route into BGP. Affects every BGP peer
                              in that domain.

Enforcement model placement   Which component enforces a ZBB boundary.
                              Cannot be changed without a boundary
                              contract update.

PCI CDE isolation             VNI separation. No shared boundary.
                              Regulatory — not operational.

Authentication mechanism      No IP-as-identity. If the authentication
                              variable is set to source-ip, that is a
                              governance finding, not an ops ticket.
```

---

## The redistribution example — where the line sits

This is the sharpest illustration of the boundary.

**The scenario:**

An engineer is configuring redistribution between an EIGRP domain
(DC internal routing) and BGP (WAN/external routing) at a boundary
router. The VSBB template has a variable:

```yaml
redistribute_default_route: deny     # Type 1 — governance-relevant
```

The engineer changes it to `permit` — perhaps because an application
team said they need a default route at a remote site, perhaps because
it "fixes" a connectivity issue that was actually caused by something
else.

**What happens downstream:**

```
redistribute_default_route: permit

→ A default route (0.0.0.0/0) is redistributed from EIGRP into BGP
→ Every BGP peer receives this default route
→ Traffic from BGP peers now routes to this device for all unknown
  destinations — including peers in different ZBBs
→ If any of those peers are in PCI CDE-adjacent zones, traffic
  that should not cross the CDE boundary now has a path to do so
→ TC-02 violation: traffic path does not match the ZBB boundary
  contract for the zones involved
→ TC-03 violation: undocumented traffic flow — no ZBB rule permits
  this path
```

**Why it looks operational but isn't:**

```
Looks like:   A routing policy decision made by a network engineer
              during a maintenance window to resolve a connectivity
              issue. Normal operational activity.

Is actually:  A change to which traffic can cross which ZBB boundary.
              The ZBB boundary contract for the affected zones does
              not include a rule for this default route path.
              The enforcement model has changed without governance.
              This is TC-02 and TC-03 simultaneously.
```

**The regulatory consequence:**

A PCI QSA asks: "Show me that traffic cannot reach the CDE without
traversing a named enforcement point." The ZBB boundary contract says
yes. The deployed config says no — because a default route leaked
into BGP creates an undocumented path. The audit finding is not
"someone made a routing change." It is "the governance framework did
not prevent a config change that broke a documented control."

**The variable governance answer:**

```yaml
# VSBB variable schema — Type 1

redistribute_default_route:
  type: 1
  source: framework
  value: deny                        # Pre-populated. Not editable.
  validation:
    allowed_values: [deny]           # deny is the only permitted value
  override: not-permitted
  governance_note: >
    Redistributing a default route into BGP is a ZBB boundary
    contract event. If a default route must be originated into BGP
    for a specific operational reason, raise a deviation request.
    PA reviews against the ZBB boundary contract for affected zones.
    Cyber Architecture must be consulted if CDE-adjacent zones
    are in the blast radius.
  regulatory_refs: [PCI-DSS-v4-Req1.3, DORA-Art9]
```

With this schema, the value is pre-populated by the framework. The
engineer cannot change it at deployment time. If the operational
need genuinely requires a default route in BGP, the deviation path
surfaces the decision — PA reviews, Cyber consults, a GEO or DEC
record is created. The change is documented before it is deployed.

**The maturity phases for this specific case:**

```
Phase 1 (today — no cost)
  Identify redistribute_default_route as a Type 1 variable
  in the straw man. Document the consequence of changing it.
  Engineers are informed — not enforced, but informed.

Phase 2 (light investment — pre-commit hook)
  Pre-commit hook checks variable files.
  If redistribute_default_route != deny, the commit is flagged.
  Engineer must add a deviation reference to proceed.
  Still bypassable, but the friction is deliberate.

Phase 3 (real investment — render-time validation)
  Render tooling refuses to produce a config where
  redistribute_default_route == permit without a
  valid deviation record reference.
  Cannot be deployed without the governance record existing first.
```

Phase 1 is available today with no tooling. It just requires writing
this document and making sure CSD and engineers have read it.

---



Four types. Each has a different governance treatment.

### Type 1 — Architectural variables

**What they are:**
Values derived from the governance framework itself — from ZBB boundary
contracts, pattern constraints, or regulatory requirements. They define
the structural properties of a deployment that must not deviate.

**Examples — structural (DC fabric):**
```yaml
zone_id: APP                          # Derived from ZBB placement
enforcement_model: firewall-boundary  # Derived from PAT-DC-001 TC-02
vni_to_zone_mapping: 1:1             # Pattern constraint
gateway_placement: leaf              # TC-02 constraint — not the firewall
pci_cde_isolated: true               # Regulatory — PCI requirement
```

**Examples — routing and boundary control:**
```yaml
redistribute_default_route: deny     # Must not leak a default into BGP
                                     # without a deviation record.
                                     # Changing this is a ZBB boundary
                                     # contract event, not a routing tweak.

bgp_default_originate: false         # Whether this device originates
                                     # 0.0.0.0/0 into BGP. Affects every
                                     # peer in the domain. Architecture
                                     # decision required to change.

redistribution_policy_ref: RM-EIGRP-TO-BGP-DENY-DEFAULT
                                     # The route-map governing redistribution.
                                     # Must reference an approved policy.
                                     # Changing to an unapproved route-map
                                     # is a TC-02 violation.

route_domain_boundary: [eigrp, bgp]  # Which protocols exchange routes
                                     # at this boundary point.
                                     # Adding a new protocol = ZBB boundary
                                     # contract change, Cyber sign-off.

authentication_mechanism: entra-id   # Must not be source-ip.
                                     # IP-as-identity is an architecture
                                     # position (DEC-003). Any value of
                                     # source-ip is a governance finding.
```

**Who sets them:** The governance framework. Pre-populated. Not editable
by an engineer at deployment time.

**Override:** Not permitted. Changing a Type 1 variable is a TC-02
violation and a deviation. Any deployment with an overridden Type 1
variable must go through the deviation path.

**Why this matters for regulators:**
Type 1 variables are the machine-readable expression of regulatory
controls. "The PCI CDE is isolated" is not a statement in a document —
it is a variable in a schema, validated at deployment, with a hash in
the deployment register. That is a demonstrable control.

---

### Type 2 — Site variables

**What they are:**
Values that are consistent across all deployments at a given site.
Derived from the Site Blueprint. They describe the infrastructure
topology at that location.

**Examples:**
```yaml
site_id: SITE-LON-01
spine_asn: 65001
mgmt_vlan: 100
loopback_pool: 10.255.0.0/24
dns_server: 10.1.1.53
ntp_server: 10.1.1.123
```

**Who sets them:** CSD / network team. Defined in the Site Blueprint
record. The same file is used by all deployments at that site.

**Override:** Requires a Site Blueprint update. Not overridable at
deployment time. A deployment with a site variable that differs from
the Site Blueprint is a deviation.

**Why this matters:**
Site variables are the link between the governance framework and the
physical estate. When a site variable changes (e.g. a new spine ASN
after a fabric refresh), the Site Blueprint is updated, and all VSBBs
that reference it inherit the change. Without this link, site-wide
changes require manual updates to every deployment — which is how
drift happens.

---

### Type 3 — Instance variables

**What they are:**
Values specific to a single deployment instance. Set by the engineer
at deployment time. These are the things that genuinely vary between
deployments: the specific server port, the allocated IP, the VLAN
assigned by IPAM.

**Examples:**
```yaml
server_port: Ethernet1/15
server_ip: 10.10.210.45        # Allocated from IPAM
vlan_id: 210                   # Assigned by IPAM
interface_speed: 10G
lag_members: [Ethernet1/15, Ethernet1/16]
hostname: app-server-prod-01
```

**Who sets them:** The engineer, at deployment time. Values come from
ITSM/IPAM allocation or physical installation.

**Validation:** Instance variables have allowed ranges or validation
rules in the schema. An IP address must come from an allocated IPAM
block. A VLAN ID must be within the site's allocated range. A speed
must be one of the approved values for that interface type.

**Override:** Self-service within the validated range. Outside the
validated range = deviation.

**The IPAM integration opportunity:**
Today: engineer gets an IP from ITSM, manually transcribes it into
the variable file. Transcription errors are possible. The IP may not
be the one that was allocated. There is no automated check.

With investment: IPAM API provides the value directly into the variable
file at deployment time. Pre-validated. No manual transcription.
No transcription error. The variable file references the IPAM
allocation ID, not just the IP — so the chain from IPAM record to
deployed config is traceable.

---

### Type 4 — Operational variables

**What they are:**
Values set at runtime by the platform itself. Not in the governance
model. Not in the template.

**Examples:**
```
interface_status: up/down
mac_address: 00:50:56:ab:cd:ef
arp_cache entries
spanning_tree_port_state
bgp_session_state
```

**Who sets them:** The device. Not governed. Not in scope.

**Why they are named here:**
Operational variables are frequently confused with instance variables.
The distinction matters because operational variables change during
normal operation and must not trigger compliance alerts. A port going
down is not a deviation. A gateway_placement changing from leaf to
firewall is.

---

## The schema model (straw man)

Each VSBB record would define a variable schema alongside its config
template. The schema specifies type, source, and validation for every
variable in the template.

```yaml
# In the VSBB record — ref-arch/sbbs/.../VSBB-XXX.yaml

variable_schema:

  zone_id:
    type: 1                        # Architectural — not overridable
    source: framework              # Pre-populated from ZBB placement
    validation:
      allowed_values: [APP, DATA, DMZ, MGMT, PCI-CDE]
    governance_note: >
      Changing zone_id after initial deployment is a ZBB boundary
      change. Requires new ZBB boundary rule and Cyber sign-off.
      This is not a variable change — it is an architecture change.

  spine_asn:
    type: 2                        # Site — from Site Blueprint
    source: site_blueprint         # Pre-populated from SITE-XXX
    validation:
      type: integer
      range: [64512, 65535]        # Private ASN range
    governance_note: >
      Changing spine_asn requires a Site Blueprint update and
      a coordinated maintenance window across all devices at the site.

  server_ip:
    type: 3                        # Instance — set by engineer
    source: ipam                   # Must come from IPAM allocation
    validation:
      format: ipv4
      ipam_required: true          # With investment: validated against IPAM API
    governance_note: >
      IP must be allocated via ITSM before deployment. With IPAM
      integration, the variable file references the IPAM allocation ID
      and the IP is injected at render time.

  interface_speed:
    type: 3
    source: engineer
    validation:
      allowed_values: [1G, 10G, 25G, 40G, 100G]
    governance_note: >
      25G, 40G, and 100G require confirmation of availability at the
      site — see TSS-001. Selecting an unavailable speed will cause
      interface negotiation failure.
```

---

## The end-to-end chain with variables

This is the chain a regulator follows. Every link is traceable.

```
Regulatory obligation
  PCI-DSS v4.0 Requirement 1.3 — network access controls
  DORA Art.9 — ICT security measures
        ↓
Architecture decision
  DEC-001 — Zone-based segmentation model
  "CDE is isolated in a dedicated zone with
   firewall enforcement at every boundary"
        ↓
Pattern
  PAT-DC-001 — Macro Network Segmentation
  TC-02: anycast gateway on leaf, not firewall
  TC-02: VNI-to-zone mapping is 1:1
  TC-02: north-south transits firewall, east-west does not
        ↓
SBB
  SBB-DC-001 v2.3 — EVPN/VXLAN DC Fabric
  Realises the segmentation capability
        ↓
VSBB
  VSBB-CIS-NXS-001 — Cisco NX-OS EVPN/VXLAN
  Config template with variable schema
        ↓
Variables
  Type 1: zone_id=PCI-CDE, gateway_placement=leaf  ← from framework
  Type 2: spine_asn=65001, mgmt_vlan=100           ← from Site Blueprint
  Type 3: server_ip=10.10.50.12, vlan_id=510       ← from IPAM/engineer
        ↓
Rendered config
  The actual NX-OS configuration file
  Hash: sha256:a3f8c2...
        ↓
Deployment register
  Site: SITE-LON-01
  Device: leaf-01a
  VSBB: VSBB-CIS-NXS-001 v2.3
  Variable file: variables/SITE-LON-01/leaf-01a.yaml
  Rendered config hash: sha256:a3f8c2...
  Deployed: 2025-05-01T14:32:00Z
  PR: #247 (self-certified TC-01/02/03 pass)
        ↓
Compliance check (with investment)
  TC-02 constraint: gateway_placement == leaf
  Check: rendered config shows "ip anycast-gateway" on Vlan510
  Result: PASS
        ↓
Deviation register
  No open deviations for this device.
  Last deviation: DEV-023 (2024-11-15, remediated 2024-12-01)
```

The regulator asks: "Show me that the PCI CDE is isolated."
The answer is this chain. Not a document. A traceable, timestamped,
hash-verified record from obligation to deployed config.

---

## Debate questions

These are the questions that must be answered before building.
This straw man does not answer them — it surfaces them.

### 1. Where does the schema live?

**Option A:** Schema in ref-arch (governance repo), values in net-config
(engineering repo). Clean separation — governance defines the rules,
engineering holds the values.

**Option B:** Both in net-config. Governance just approves the VSBB.
Variable governance is an engineering concern.

**The argument for A:** Type 1 variables express governance constraints.
They belong in the governance framework, not the engineering repo.
The regulatory chain runs through ref-arch — the schema needs to be
there for the chain to be complete.

**The argument for B:** Engineers work in net-config. Adding a
governance dependency for every deployment increases friction and
creates a cross-repo maintenance burden.

**Open:** This is a PA / CSD / GCB3 conversation.

---

### 2. What enforces the schema?

**Today:** Nothing automated. PR review is a manual check. An engineer
can set gateway_placement=firewall and it will merge unless a reviewer
catches it.

**With investment — Option A:** Pre-commit hook in net-config validates
variable files against the schema at commit time. Fails locally before
a PR is even raised.

**With investment — Option B:** CI pipeline (if/when available) validates
on PR. Blocks merge if Type 1 or Type 2 variables are overridden or
Type 3 variables are out of range.

**With investment — Option C:** The IaC generation tool (Terraform /
Ansible) validates at plan/render time and refuses to render if
schema violations exist.

**The investment question:** Options B and C require pipeline
infrastructure that isn't available today. Option A (pre-commit hook)
runs locally and requires no infrastructure — but it's optional and
can be bypassed. What level of enforcement is the right starting point?

---

### 3. What happens when a Type 3 variable is out of range?

**Option A:** Blocked. The commit or render fails. Engineer must
raise a deviation request first.

**Option B:** Warning. The commit succeeds but a governance flag is
set. PA is notified. The deviation path is triggered post-deployment.

**Option C:** Allowed with documentation. The engineer adds a
justification comment to the variable file. PA reviews on audit.

**The tension:** Option A maximises governance integrity but adds
friction to legitimate edge cases (e.g. a speed that isn't in the
allowed_values list because a new interface type was just approved
but the schema hasn't been updated yet). Option C risks the
documentation becoming a rubber stamp.

---

### 4. IPAM integration — ambition vs pragmatism

**Today:** Engineer gets an IP from ITSM, types it into a variable
file. No validation that the IP matches the allocation. No traceability
from IPAM record to deployed config.

**Straw man:** IPAM API (Infoblox) provides values directly. Variable
file contains an IPAM allocation ID. At render time, the IP is fetched
from IPAM and injected. The deployed config references an IPAM record,
not a manually entered IP.

**What this enables:**
- No transcription errors
- Every deployed IP is traceable to an IPAM allocation
- Decommissioning: IPAM record deletion triggers a config update
- IP conflict: impossible — IPAM is the source of truth

**What this requires:**
- Infoblox API access from the deployment pipeline
- A wrapper in the render tooling (Ansible/Terraform) to call IPAM
- A variable file format that references allocation IDs, not raw IPs
- Error handling for IPAM unavailability at deployment time

**The investment question:** Is IPAM API integration a Year 1 or
Year 2 investment? What is the cost of manual transcription errors
today (incidents, audit findings, re-work)?

---

### 5. The governance compact for variables

Who is accountable when a Type 1 variable is wrong?

Today: PA approved the template. Engineer deployed the variables.
If the rendered config violates TC-02, the accountability is unclear.

With variable governance:
- PA approves the VSBB and its variable schema
- The schema makes Type 1 variables non-overridable
- Engineer self-certifies TC pass based on the rendered config
- If a Type 1 variable was overridden (by bypassing the schema),
  that is an engineering governance finding against the engineer

This resolves the accountability gap. PA is accountable for the
schema. Engineer is accountable for the values. The rendered config
is where they meet — and TC-01/02/03 is where it is validated.

---

### 6. Routing governance — the approved policy catalogue

For redistribution_policy_ref to be a meaningful Type 1 variable,
there must be an approved list of route-maps it can reference.
Today that catalogue doesn't exist in the framework.

**The debate question:** Where does the approved route-map catalogue
live and who maintains it?

**Option A:** Route-maps defined in the pattern record.
PAT-DC-001 includes an approved redistribution policy for the
EIGRP-to-BGP boundary at DC edge routers. The VSBB must reference
this policy name. Any other route-map name is a deviation.

**Option B:** A standalone routing policy register in ref-arch.
`routing/approved-policies/RP-EIGRP-BGP-001.yaml` defines the
approved redistribution behaviour. VSBBs reference policies from
this register. PA approves new policies.

**Option C:** Route-map content is out of scope — only the
redistribution decision (permit/deny) is governed, not the
specific policy detail.

**The tension:** Option C is pragmatic — it governs the important
decision (should a default route be redistributed at all?) without
requiring a route-map catalogue. Option A or B provides tighter
governance but requires significant upfront work to catalogue
all existing redistribution policies.

**Recommended starting position:** Option C for Phase 1 and 2.
Govern the permit/deny decision. Document that the route-map
content is operational but the redistribution decision is not.
Revisit when the Phase 3 investment is made.


---

## Summary — what this unlocks with investment

**The governance boundary:**

| Variable | Governed? | Why |
|---|---|---|
| Interface description | No | Operational. Getting it wrong is an ops problem. |
| Port VLAN membership | No | Operational. IPAM is the control, not variable governance. |
| Summary route address | No | Operational choice. Doesn't affect boundary enforcement. |
| Individual prefix entries | No | Too granular. No governance value. |
| Interface MTU | No | Operational. Agreed via TSS-001 at request time. |
| Zone ID | **Yes** | Defines ZBB placement. Changing it moves a workload between zones. |
| Anycast gateway placement | **Yes** | TC-02 constraint. Getting it wrong breaks PCI CDE isolation. |
| VNI-to-zone mapping | **Yes** | Pattern constraint. Shared VNI = TC-02 violation. |
| Default route redistribution | **Yes** | ZBB boundary contract event. See redistribution example. |
| BGP default originate | **Yes** | Affects every peer in the domain. Architecture decision. |
| Redistribution policy ref | **Yes** | The enforcement mechanism. Must reference an approved policy. |
| Authentication mechanism | **Yes** | IP-as-identity is an architecture position (DEC-003). |

**What variable governance unlocks:**

| Today | With variable governance |
|---|---|
| Template approved, variables ungoverned | Template AND governance-relevant variables governed |
| Artistic licence at variable level | Type 1 variables enforce pattern and boundary constraints |
| Redistribution policy changed operationally | Redistribution change triggers deviation path |
| IP from ITSM, manually transcribed | IP from IPAM, automatically injected |
| Deployment register records VSBB version | Deployment register records VSBB + variable hash |
| TC-02 checked manually at PR | TC-02 constraints validated against rendered config |
| Regulator sees a document | Regulator sees a traceable chain |

**The phased investment:**

```
Phase 1 — Today, no cost
  Identify Type 1 variables by name in this straw man.
  Engineers and CSD read and understand the boundary.
  Informed but not enforced. The redistribution example
  is the anchor — everyone knows what wrong looks like.

Phase 2 — Light investment (pre-commit hook)
  Schema in VSBB records.
  Pre-commit hook in net-config validates variable files.
  Type 1 variables flagged if changed without a deviation ref.
  Bypassable — but friction is deliberate.

Phase 3 — Medium investment (render-time validation)
  Render tooling validates Type 1 variables at config
  generation time. Cannot render a non-compliant config
  without a deviation record reference.
  Approved route-map catalogue required for redistribution
  policy validation.

Phase 4 — Higher investment (IPAM integration)
  Type 3 IP variables injected from IPAM API at render time.
  No manual transcription. No IP conflicts.

Phase 5 — Destination (continuous compliance)
  Deployed estate scanned against Type 1 variable schema.
  Drift detected automatically, not at audit.
  Deviation register updated by the tool, not manually.
```

Each phase adds a link to the chain. None requires all phases to be
complete before value is delivered. Phase 1 is available today.


---

*Status: Straw man. For debate. Not a decision.*
*Owner: PA — ref-arch/docs/variable-governance-strawman.md*
