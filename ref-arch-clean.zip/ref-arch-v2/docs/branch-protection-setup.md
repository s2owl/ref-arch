# Branch Protection Configuration

This document records the required branch protection settings for `main`.
These must be configured manually in GitHub repository settings.
No Actions dependency — enforcement is native GitHub branch protection.

---

## Required Settings — `main` branch

Navigate to: **Settings → Branches → Branch protection rules → Add rule**

### Rule: `main`

| Setting | Value | Rationale |
|---|---|---|
| Require a pull request before merging | ✅ Enabled | All changes via PR — audit trail |
| Required approving reviews | 1 | Minimum; patterns/decisions require CODEOWNERS |
| Dismiss stale pull request approvals | ✅ Enabled | Re-review if PR updated after approval |
| Require review from Code Owners | ✅ Enabled | Routes patterns/decisions to principal architect |
| Require conversation resolution | ✅ Enabled | No unresolved review comments on merge |
| Require linear history | ✅ Enabled | Clean commit history, no merge commits |
| Do not allow bypassing the above settings | ✅ Enabled | Applies to admins — governance integrity |

### Not required (no Actions)
- Required status checks — skip (would require Actions)
- Require branches to be up to date — optional, enable if merge conflicts are a problem

---

## Label Configuration

Create these labels in **Issues → Labels**:

| Label | Colour | Purpose |
|---|---|---|
| `deviation` | `#ef4444` | Pattern deviation requests |
| `awaiting-review` | `#f59e0b` | Pending principal architect review |
| `approved` | `#22c55e` | Deviation or paper approved |
| `rejected` | `#64748b` | Deviation rejected |
| `options-paper` | `#7c3aed` | Options paper issues |
| `awaiting-triage` | `#0ea5e9` | New paper, awaiting tier assignment |
| `arb-required` | `#ec4899` | Requires ARB endorsement |
| `high-risk` | `#ef4444` | High risk classification |
| `regulatory-impact` | `#f59e0b` | Regulatory framework impact flagged |

---

## Milestone Configuration

Create milestones to track quarterly governance cycles:

- `Q2 2025 ARB` — current ARB cycle
- `Q3 2026 ARB` — next cycle
- `Backlog` — unscheduled

Assign options paper Issues and decision records to milestones to track ARB pipeline.

---

## Repository Settings

| Setting | Value |
|---|---|
| Issues | ✅ Enabled |
| Discussions | ✅ Enabled (use for ARB meeting notes) |
| Projects | Optional — useful for kanban view of papers |
| Wiki | ❌ Disabled — docs live in /docs/ |
| Merge commits | ❌ Disabled |
| Squash merging | ✅ Enabled |
| Rebase merging | ✅ Enabled |
| Automatically delete head branches | ✅ Enabled |
