# Network Architecture Governance
**Principal Network Architect · Financial Services · TOGAF 10**

This repository is the source of truth for network architecture governance
for the network domain. It is not a compliance document collection. It is
a **living governance system** — standards, patterns, building blocks, and
the process that connects them.

---

## Start here

**If you are new to this framework, read one of these first:**

| Your role | Start with |
|---|---|
| Engineer deploying infrastructure | [`governance/role-card-engineer.md`](governance/role-card-engineer.md) |
| SME — platform or vendor specialist | [`governance/role-card-sme.md`](governance/role-card-sme.md) |
| CSD — cross-platform network generalist | [`governance/role-card-csd.md`](governance/role-card-csd.md) |
| Service Manager with a delivery need | [`governance/role-card-mgr.md`](governance/role-card-mgr.md) |
| Principal Architect (reference) | [`governance/role-card-pa.md`](governance/role-card-pa.md) |

**The process in one diagram:**
→ [`governance/process-map.html`](governance/process-map.html) — open in browser, printable

**Full contribution guidance:**
→ [`CONTRIBUTING.md`](CONTRIBUTING.md)

---

## The governance loop in one sentence

A requirement enters as a **demand signal** → routes through the **pattern gate** → goes to the **Arch/Eng Forum** → proceeds to the right **review stage** → is implemented using an **approved VSBB** → feeds back through **operational feedback** → improves the **standards and patterns**.

```
Demand Signal
    ↓
Pattern Gate (topology conformance self-assessment)
    ↓
Arch/Eng Forum — Thread 1 (socialise) or Thread 2 (endorsement)
    ↓
Solution Design Forum / ARG / Design Authority
    ↓
Implementation (approved VSBB + config template)
    ↓
Operational Feedback → Standards update
```

---

## Architecture hierarchy

```
Primary Capability (PC)     What the network delivers to the business
    └── ABB                 What technical capability is required (vendor-agnostic)
          └── SBB           How that capability is realised (versioned)
                └── VSBB    How a specific vendor implements it (config + variables)

ZBB                         Bounded zone — Network defines, Cyber enforces boundary
    └── Site Blueprint      Complete site definition (all zones, versions, VSBB choices)

Service Blueprint           Consumable service — what application teams request
```

**The "as intended" test** is whether your solution's traffic flows match the ZBB boundary contract — not just whether the components are approved. See `governance/process-map.html` for the topology conformance check.

---

## Repository structure

```
ref-arch/
├── governance/
│   ├── process-map.html          ← START HERE — visual process flow
│   ├── role-card-engineer.md     ← Engineer one-pager
│   ├── role-card-sme-par.md      ← SME / connectivity solution designer one-pager
│   ├── role-card-mgr.md          ← Service manager one-pager
│   ├── role-card-pa.md           ← Principal architect reference
│   ├── raci.yaml                 ← Full RACI (current + target state)
│   ├── conflict-resolution.yaml  ← Cross-org escalation paths
│   └── approved-vendor-list.yaml ← Vendor tiers and capability gates
│
├── capabilities/                 ← Primary capabilities (business language)
├── abbs/                         ← Architecture Building Blocks (vendor-agnostic)
├── sbbs/                         ← Solution Building Blocks (versioned realisations)
├── zbbs/                         ← Zonal Building Blocks (zone definitions)
├── patterns/                     ← Approved topologies
├── standards/                    ← Normative rules by domain
│
├── blueprints/
│   ├── site/                     ← Site Blueprints (complete site definitions)
│   └── service/                  ← Service Blueprints (consumable services)
│
├── decisions/                    ← ARB/DA decision records (immutable)
├── options-papers/               ← Options paper index records
├── programmes/                   ← Roadmap programme records
├── demand/                       ← Business demand signals
├── feedback/                     ← Operational feedback register
│
└── .github/
    ├── ISSUE_TEMPLATE/
    │   ├── deviation-request.yaml
    │   ├── options-paper-request.yaml
    │   ├── endorsement-request.yaml
    │   ├── demand-signal.yaml
    │   └── operational-feedback.yaml
    └── PULL_REQUEST_TEMPLATE/
        └── pull_request_template.md
```

The engineering implementation lives in [`net-config`](https://github.com/net-config):
VSBBs, hardware records, Jinja2 config templates, and variable schemas.

---

## Confluence publishing

Key governance artefacts are automatically published to Confluence
on every merge to main. GitHub is the source of truth. Confluence
is the reading layer for stakeholders who won't open a GitHub repo.

**What gets published:** Process maps, role cards, RACI summary, CONTRIBUTING guide.

**Setup (one time):** [`docs/confluence-setup.md`](docs/confluence-setup.md)

**After setup:** Fully automated on merge to main. No manual action required.

**Manual trigger:** GitHub Actions → Publish to Confluence → Run workflow.

---

## How to submit

| What you need to do | How |
|---|---|
| Deploy a compliant solution | PR with self-certification checklist |
| Deviate from a pattern | [Raise a Deviation Request Issue](.github/ISSUE_TEMPLATE/deviation-request.yaml) **first** |
| Get endorsement for Thread 2 | [Raise an Endorsement Request Issue](.github/ISSUE_TEMPLATE/endorsement-request.yaml) |
| Request a new capability | [Raise an Options Paper Request Issue](.github/ISSUE_TEMPLATE/options-paper-request.yaml) |
| Report an operational issue | [Raise an Operational Feedback Issue](.github/ISSUE_TEMPLATE/operational-feedback.yaml) |
| Signal a business demand | [Raise a Demand Signal Issue](.github/ISSUE_TEMPLATE/demand-signal.yaml) |

---

## Architectural principles

1. **IP address is a routing attribute** — not an identity or authorisation signal (see OP-001, STD-VPN-001/R04)
2. **Approved components ≠ compliant topology** — the risk is in the assembly, not just the component list
3. **PA defines and gates; domain experts produce** — standards and SBBs require operational grounding, not speculation
4. **Compliance is not a separate workstream** — regulatory lenses applied at design, not audit
5. **Network's remit is packet exchange** — security policy decisions must not create Network delivery accountability
6. **Retrospective deviation > undocumented risk** — the framework is not punitive

---

## Governance mandate

PA operates under **independent architecture governance authority**, separate from
the networks service delivery organisation. This independence is by design —
it prevents marking your own homework. The governance mandate is agreed at
director and MD level across both organisations.

See `governance/conflict-resolution.yaml` for the cross-org escalation model.
The `co-reviewed-by` field must be populated before the framework is operational.

---

## Regulatory frameworks

| Tag | Framework |
|---|---|
| `PCI-DSS-v4` | PCI-DSS v4.0 |
| `DORA` | DORA 2022/2554 Articles 5–9 |
| `PRA-SS2/21` | PRA Supervisory Statement SS2/21 |
| `GDPR` | GDPR Art.32 |

---

*TOGAF 10 aligned. ABB/SBB taxonomy. ADM phases referenced in all ABB records.*
*Agent/RAG navigation: see `agent-index.yaml`*
