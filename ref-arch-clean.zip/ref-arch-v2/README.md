# Network Architecture Governance
**TOGAF 10 · Financial Services · Independent Governance**

> **Picking this up after a gap?**
> Read [`CURRENT-FOCUS.md`](CURRENT-FOCUS.md) first —
> it tells you where you left off, what's in flight, and what's next.

This repository is the source of truth for network architecture governance.
It is not a compliance document collection — it is a **living governance
system**: standards, patterns, building blocks, and the process that connects them.

---

## Start here

**New to the framework? Read these first:**

| Document | What it answers |
|---|---|
| [`governance/master-flow.html`](governance/master-flow.html) | **Master flow** — interactive end-to-end process map, click your role |
| [`governance/how-to-use.html`](governance/how-to-use.html) | How to use — decision tree, TC checks, artefact map, quick reference |
| [`governance/resilience-tiers.html`](governance/resilience-tiers.html) | Resilience tiers reference card — N/N+1/2(N+1)/2N, exception process |
| [`governance/hierarchy.html`](governance/hierarchy.html) | **Artefact hierarchy** — visual scaffold of every layer and what depends on what |
| [`governance/hierarchy-tree.html`](governance/hierarchy-tree.html) | **Hierarchy tree** — root and branch, left to right, 1:1 and 1:* relationships |
| [`governance/worked-examples.html`](governance/worked-examples.html) | Worked examples — DDoS, proxy, VPN, DC segmentation traced through hierarchy |
| [`capabilities/PC-CATALOGUE.yaml`](capabilities/PC-CATALOGUE.yaml) | Primary Capabilities — business language, 10 PCs |
| [`capabilities/NC-CATALOGUE.yaml`](capabilities/NC-CATALOGUE.yaml) | Network Capabilities — 14 NCs, business entry point |
| [`capabilities/ABB-CATALOGUE.yaml`](capabilities/ABB-CATALOGUE.yaml) | Complete ABB catalogue — all 34 ABBs across 6 domains |
| [`governance/domain-taxonomy.yaml`](governance/domain-taxonomy.yaml) | Domain taxonomy — plain English definitions with examples and boundaries |
| [`governance/vision.html`](governance/vision.html) | Why this framework exists · what it enables · governing principles |
| [`governance/roadmap.html`](governance/roadmap.html) | Where the framework is going · programme pipeline · open questions |
| [`governance/process-map.html`](governance/process-map.html) | How the governance process works — visual, printable |
| [`governance/raci.html`](governance/raci.html) | Who is accountable for what — interactive matrix |

**Your role card:**

| Your role | Start with |
|---|---|
| Engineer deploying infrastructure | [`governance/role-card-engineer.md`](governance/role-card-engineer.md) |
| CSD — cross-platform solution delivery | [`governance/role-card-csd.md`](governance/role-card-csd.md) |
| SME — platform or vendor specialist | [`governance/role-card-sme.md`](governance/role-card-sme.md) |
| Product Owner | [`governance/org-chart.html`](governance/org-chart.html) | **Target organisation** — director structure, platform taxonomy, peer relationships |
| [`governance/front-door.html`](governance/front-door.html) | **Front Door** — intake, triage, handoff process and worked example |
| [`governance/role-card-frontdoor.md`](governance/role-card-frontdoor.md) | Front Door team role card — intake, triage, handoff |
| [`front-door/FD-TEMPLATE.yaml`](front-door/FD-TEMPLATE.yaml) | Snowflake record template — FD-XXX |
| [`front-door/FD-001-worked-example.yaml`](front-door/FD-001-worked-example.yaml) | Worked example — Vatican City, business funding departure |
| [`governance/role-card-po.md`](governance/role-card-po.md) |
| Principal Architect (reference) | [`governance/role-card-pa.md`](governance/role-card-pa.md) |

**Full contribution guidance:**
→ [`CONTRIBUTING.md`](CONTRIBUTING.md)

---

## The governance loop

A requirement enters as a **demand signal** → routes through the **pattern gate** → goes to the **Arch/Eng Forum** → proceeds to the right **review stage** → is implemented using an **approved VSBB** → feeds back through **operational feedback** → improves **standards and patterns**.

```
Demand Signal
    ↓
Pattern Gate (topology conformance self-assessment — TC-01/02/03)
    ↓
Arch/Eng Forum — Thread 1 (socialise) or Thread 2 (endorsement)
    ↓
Solution Design Forum / ARG / Design Authority
    ↓
Implementation (approved VSBB + config template)
    ↓
Operational Feedback → Standards update
```

---

## Architecture hierarchy

```
Network Capability (NC)     What the network delivers — business language
    └── ABB                 What technical capability is required (vendor-agnostic)
          └── SBB           How that capability is realised (versioned)
                └── VSBB    How a specific vendor implements it (config + variables)

ZBB                         Bounded zone — PA defines, Cyber enforces boundary
    └── Site Blueprint      Complete site definition (zones, versions, VSBB choices)
        └── Service Blueprint   Consumable service — what application teams request

Pattern                     How SBBs are assembled correctly (the AND rule)
Connectivity Construct      Point solution — specific endpoints, specific purpose
```

**The "as intended" test:** whether traffic flows match the ZBB boundary contract —
not just whether the components are approved.

---



## Blueprint types — collections of building blocks

Two blueprint types sit at different layers of the hierarchy:

**Service Blueprint (SVC-XXX)** — a collection of patterns assembled for a named, consumable service outcome.
The NC made requestable via ITSM. Application and platform teams request a service blueprint without needing to understand the underlying patterns, SBBs, or VSBBs.

```
SVC-001  Internet-facing application hosting
         = PAT-DC-001 + PAT-SEC-001 + PAT-PROXY-005

SVC-004  Remote access
         = PAT-SVC-001 (Cisco ASA AND Entra ID AND Intune)
```

**Site Blueprint (SITE-XXX)** — a collection of ZBBs instantiated at a specific physical location.
The operational record of what is deployed at a named site, at which SBB version, with which VSBB choices.

```
SITE-LON-01  London Primary DC
             = ZBB-APP-001 + ZBB-DATA-001 + ZBB-DMZ-001
             + ZBB-MGMT-001 + ZBB-INTERNET-EDGE-001
             with SBB-DC-001 v2.3, VSBB-CIS-NXS-001, ...
```

See `blueprints/service/` and `blueprints/site/`.

## Vendor evidence records — VER-XXX

When a deployment is asymmetric by **vendor best practice** rather than
funding constraint, a Vendor Evidence Record (VER-XXX) is the governance
artefact — not a Resilience Exception.

| Record | What it covers |
|---|---|
| [VER-001](governance/vendor-evidence/VER-001-f5-gtm-sync-group.yaml) | F5 GTM 2+1 sync group — dual-DC GSLB |
| [VER-TEMPLATE](governance/vendor-evidence/VER-TEMPLATE.yaml) | Template for new vendor evidence records |

`vendor_evidence_ref` and `resilience_exception_ref` in the deployment
register are mutually exclusive — a deployment follows vendor best practice
or it is a funded compromise. Not both.

## Technical service sheets — the engineering interface

Technical Service Sheets answer the questions a server team, application
architect, or platform engineer asks when interfacing with the network.
Not business outcomes. Not governance. Engineering specifications.

| Sheet | What it covers |
|---|---|
| [TSS-001 Network Connectivity](consumption/technical-service-sheets/TSS-001-network-connectivity.yaml) | Interface types, speeds, LAG/bonding, redundancy, WAN circuits |
| [TSS-002 Proxy Services](consumption/technical-service-sheets/TSS-002-proxy-services.yaml) | Explicit proxy, PAC file, WPAD, SSL inspection, bypass |
| [TSS-003 Load Balancing](consumption/technical-service-sheets/TSS-003-004-load-balancing-ddi.yaml) | NLB VIP types, algorithms, health checks, SSL offload, GSLB |
| [TSS-004 DDI](consumption/technical-service-sheets/TSS-003-004-load-balancing-ddi.yaml) | DNS record types, DHCP options, IP allocation via IPAM |

---

## Network capabilities — the business interface

The network capability register is the business-facing layer. It describes what
the network provides in outcome language — no network jargon.

| Capability | What it delivers |
|---|---|
| [NC-001 Internet Access](consumption/network-capabilities/NC-001-internet-access.yaml) | Secure, managed outbound internet access |
| [NC-002 Partner Connectivity](consumption/network-capabilities/NC-002-partner-connectivity.yaml) | Private connectivity to named external partners |
| [NC-003 Remote Working](consumption/network-capabilities/NC-003-004-remote-working-app-hosting.yaml) | Secure remote access for managed devices |
| [NC-004 Application Hosting](consumption/network-capabilities/NC-003-004-remote-working-app-hosting.yaml) | Network layer for DC-hosted applications |

Each record defines: outcome statement · in/out of scope · how to request ·
ABBs/SBBs/patterns that underpin it · availability heatmap (technical and
commercial status separately per site).

**The translation principle:** business requests a capability. The tech team
translates into ZBB boundary rules, patterns, and SBB configuration.
The business never needs to know that translation happened.

---

## Repository structure

```
ref-arch/
├── governance/
│   ├── process-map.html              ← START HERE — visual process flow
│   ├── consumption-map.html          ← App/service dependency process
│   ├── role-card-engineer.md
│   ├── role-card-csd.md              ← CSD execution role
│   ├── role-card-sme.md
│   ├── role-card-po.md
│   ├── role-card-pa.md
│   ├── raci.yaml                     ← Full RACI — current state
│   ├── conflict-resolution.yaml      ← Cross-org escalation paths
│   ├── approved-vendor-list.yaml     ← Vendor tiers and capability gates
│   ├── github-labels.yaml            ← Label taxonomy for metrics
│   ├── metrics.yaml                  ← Quarterly governance metrics
│   ├── metrics-dashboard.jsx         ← Dwell time and volume dashboard
│   └── headcount-model.yaml          ← Evidence base for headcount case
│
├── consumption/
│   ├── network-capabilities/         ← NC-XXX business-facing capability records
│   ├── app-groups/                   ← Business application groups
│   ├── app-instances/                ← Running deployments by geography
│   ├── tech-services/                ← Infrastructure services
│   ├── service-instances/            ← Geographic service deployments
│   └── connectivity-constructs/      ← Point solutions (CC-XXX)
│
├── capabilities/                     ← Primary Capabilities (PC)
├── abbs/                             ← Architecture Building Blocks
├── sbbs/                             ← Solution Building Blocks
├── zbbs/                             ← Zonal Building Blocks
├── patterns/                         ← Approved topologies (AND rule)
├── standards/                        ← Normative rules by domain
│
├── blueprints/
│   ├── site/                         ← Site Blueprints
│   └── service/                      ← Service Blueprints
│
├── decisions/                        ← ARB/DA decision records (immutable)
├── options-papers/                   ← Options paper records
├── programmes/                       ← Roadmap programme records
├── demand/                           ← Business demand signals
├── feedback/                         ← Operational feedback register
│
├── docs/
│   ├── confluence-setup.md           ← Confluence publishing setup
│   ├── confluence-page-map.yaml      ← Source → Confluence page mapping
│   ├── setup-labels.sh               ← GitHub label taxonomy setup
│   └── branch-protection-setup.md    ← Branch protection configuration
│
└── .github/
    ├── ISSUE_TEMPLATE/
    │   ├── deviation-request.yaml
    │   ├── options-paper-request.yaml
    │   ├── endorsement-request.yaml
    │   ├── demand-signal.yaml
    │   └── operational-feedback.yaml
    └── PULL_REQUEST_TEMPLATE/
        └── pull_request_template.md
```

Engineering implementation in `net-config`:
VSBBs, hardware records, Jinja2 config templates, and variable schemas.

---

## Confluence publishing

Key governance artefacts are published to Confluence manually using a
local script authenticated with your Confluence PAT. GitHub is the source
of truth. Confluence is the reading layer for stakeholders.

**Process maps** (HTML) are served via GitHub Pages — link from Confluence,
opens in browser. No embed required.

**Role cards, RACI, CONTRIBUTING** — published as native Confluence pages
via `docs/publish-to-confluence.py` using your PAT.

**Setup:** [`docs/confluence-setup.md`](docs/confluence-setup.md)

---

## How to submit

| What you need to do | How |
|---|---|
| Deploy a compliant solution | PR with TC-01/02/03 self-certification |
| Deviate from a pattern | [Raise a Deviation Request](.github/ISSUE_TEMPLATE/deviation-request.yaml) **before building** |
| Get Thread 2 endorsement | [Raise an Endorsement Request](.github/ISSUE_TEMPLATE/endorsement-request.yaml) |
| Request a new capability | [Raise an Options Paper Request](.github/ISSUE_TEMPLATE/options-paper-request.yaml) |
| Report an operational issue | [Raise Operational Feedback](.github/ISSUE_TEMPLATE/operational-feedback.yaml) |
| Signal a business demand | [Raise a Demand Signal](.github/ISSUE_TEMPLATE/demand-signal.yaml) |

---

## Architectural principles

1. **IP address is a routing attribute** — not an identity or authorisation signal
2. **Approved components ≠ compliant topology** — the risk is in the assembly
3. **PA defines and gates; domain experts produce** — standards require operational grounding
4. **Compliance is not a separate workstream** — regulatory lenses applied at design, not audit
5. **Network's remit is packet exchange** — security policy decisions must not create network delivery accountability
6. **Retrospective deviation > undocumented risk** — the framework is not punitive
7. **Business requests capabilities; tech teams translate** — no VLANs or ports in a business request

---

## Governance mandate

PA operates under **independent architecture governance authority**, separate from
the networks service delivery organisation. Independence is by design —
it prevents marking your own homework. The mandate is agreed at GCB3 and
MD level across both organisations before the framework is operational.

See `governance/conflict-resolution.yaml` for cross-org escalation paths.
The `co-reviewed-by` field must be populated before go-live.

---

## Regulatory frameworks

| Tag | Framework |
|---|---|
| `PCI-DSS-v4` | PCI-DSS v4.0 |
| `DORA` | DORA 2022/2554 Articles 5–9 |
| `PRA-SS2/21` | PRA Supervisory Statement SS2/21 |
| `GDPR` | GDPR Art.32 |

---

*TOGAF 10 aligned · ABB/SBB taxonomy · ADM phases in all ABB records*
*Agent/RAG navigation: `agent-index.yaml`*
