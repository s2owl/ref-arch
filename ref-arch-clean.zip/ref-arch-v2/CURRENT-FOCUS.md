# Current Focus
<!-- 
  WORKING MEMORY AID — NOT A GOVERNANCE ARTEFACT
  ─────────────────────────────────────────────────
  This file is for you, not for the framework.
  Update it whenever your focus shifts.
  There are no rules about format.
  The only rule: if you're picking this up after a gap,
  read this first before opening anything else.
-->

---

## Right now

<!-- One sentence. What are you actually doing today? -->

_Not set — update this when you start a session._

---

## In flight — needs action

<!-- Things that are actively in progress and need your attention.
     Keep this short. If it's not genuinely active, move it to Pending. -->

| What | Where | Next action | Blocking? |
|---|---|---|---|
| OP-001 (IP identity) | `options-papers/OP-001-ip-identity.yaml` | ARB review — awaiting date | Yes — DEC-003/004 pending |
| XLINK Control Owners | `governance/xlinks/` | Identify named individual from Security Architecture | Yes — pre-go-live blocking |
| FEEDBACK-001 | `feedback/FEEDBACK-001-002.yaml` | Guest WiFi segregation — architecture review | No |
| ICL identification | `deployments/deployment-register.yaml` | Named ICL required per site before DP-13 can complete | Yes — pre-deployment |

---

## Next up — ready to start

<!-- Things that are defined and ready but not started yet.
     Pull from here when you finish something above. -->

- [ ] Build `resilience-tiers.html` stub for programme sponsor conversations
- [ ] Populate `SITE-NPL-01` stub for Nepal regulatory connectivity example
- [ ] Confirm Confluence page IDs in publish script once pages are created
- [ ] Variable governance straw man — schedule debate session

---

## Pending — waiting on someone else

<!-- Things that are blocked by someone outside your control.
     Name the person or team. Date when you last chased. -->

| What | Waiting on | Last chased | Escalate if no response by |
|---|---|---|---|
| XLINK Control Owner identification | Security Architecture | Not yet | 10 working days from go-live |
| OP-001 ARB date | ARB chair | Not yet | — |
| co-reviewed-by in conflict-resolution.yaml | Networks GCB3 | Not yet | Before first forum session |

---

## Parked — not forgotten, not active

<!-- Things that exist in the framework but are not being worked on now.
     The point of this section is so they don't live in your head. -->

- RTO/RPO roadmap — Q3/Q4 2026 programme — not started
- Variable governance phases 2–5 — straw man published, debate needed first
- PAT-PROXY-001 through 005 — identified, not built — Year 1
- ZTNA pattern (PAT-ZTNA) — PROG-003 pipeline, unfunded. Do not unblock until PROG-003 is funded.
- Worked example WE-001 (Nepal) — stub not yet built
- PROG-003 (ZTNA) — pipeline, unfunded. ABB-VPN-002 marked status: pipeline in ABB catalogue.

---

## Loose thoughts

<!-- Unstructured. Things that occurred to you that don't have a home yet.
     Clear this out when it gets too long by either acting or discarding. -->

_Add anything here — half-formed ideas, things someone said in a meeting,
things you noticed in the estate that the framework should probably know about._

---

## How to use this file

**Starting a session:**
1. Read "Right now" and "In flight" — do these still reflect reality?
2. Update anything that's moved
3. Pick the next thing to work on
4. Update "Right now" with one sentence

**Ending a session:**
1. Update "In flight" — what moved, what's new?
2. Move anything finished to done (or just delete it)
3. Capture any loose thoughts before you close the tab
4. Update "Right now" to say where you stopped

**After a long gap:**
1. Read this whole file before opening anything else
2. Check "Pending" — has anyone responded?
3. Check GitHub Issues for anything new
4. Then pick up from "In flight"

---

_Last updated: [date]_
_This file is not published to Confluence and is not version-governed._
_It lives in the repo root so it's always the first thing you see._
