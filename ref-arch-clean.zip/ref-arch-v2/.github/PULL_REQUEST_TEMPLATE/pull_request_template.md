# Architecture Change — Pull Request

## Change Type
- [ ] New pattern
- [ ] Pattern update
- [ ] New ABB / SBB / ZBB
- [ ] ABB / SBB / ZBB update
- [ ] New VSBB or hardware record
- [ ] New decision or options paper record
- [ ] Solution design (new deployment or topology)
- [ ] Governance / documentation
- [ ] Retrospective submission (built without prior architecture engagement)

## Summary
<!-- What changed and why — one paragraph -->

## Artefact IDs Affected
<!-- e.g. SBB-DC-001, ZBB-APP-001, VSBB-F5-OVL-001, PAT-DC-001 -->

---

## Topology Conformance Self-Assessment
<!-- Required for any solution design or VSBB/ZBB change -->
<!-- Skip only for pure documentation or governance record changes -->

- [ ] **TC-01** — All platforms used are approved VSBBs in the vendor catalogue
- [ ] **TC-02** — All traffic flows trace to a named rule in the relevant ZBB boundary contract
- [ ] **TC-03** — No traffic path exists that cannot be traced to a ZBB rule or approved pattern

**If any box is unchecked — stop. Raise a Deviation Request Issue first.**
A PR with an unaddressed topology conformance failure will not be merged.

> The topology conformance check exists because a solution can use only
> approved components and still be non-compliant. The risk is in the
> assembly and the traffic flows — not just the component list.

---

## Deviations
<!-- If TC-01, TC-02, or TC-03 failed — document the deviation here -->
<!-- Reference the Deviation Request Issue number -->

Deviation Request Issue: #___
Nature of deviation:
Risk and mitigation:
Principal architect endorsement: [ ] Obtained (Thread 2 Arch/Eng Forum)

---

## Cross-Domain Dependencies
- [ ] Cyber — firewall policy, WAF, SSL inspection, ZBB boundary enforcement
- [ ] Identity — Conditional Access, MFA, device compliance
- [ ] Application — application-layer routing, health endpoints
- [ ] DC Facilities — physical infrastructure implications
- [ ] No cross-domain dependencies

**If any cross-domain box is checked — confirm consultation is complete before merging.**

---

## Regulatory Impact
- [ ] PCI-DSS v4.0
- [ ] DORA (Articles 5–9)
- [ ] PRA SS2/21
- [ ] GDPR Art.32
- [ ] None

---

## Reviewer Guidance

| Change type | Required reviewer |
|---|---|
| Topology conformance pass, no deviations | Peer architect sufficient |
| Documented deviation, no regulatory impact | Principal architect |
| Regulatory impact or cross-domain | Principal architect |
| New pattern or wholly new capability | Principal architect + ARB decision |
| Retrospective submission | Principal architect — treat as deviation |

## Linked Issues / Endorsements
<!-- e.g. Closes #14, Endorsed in Arch/Eng Forum Thread 2 (link) -->
