#!/usr/bin/env python3
"""
docs/collect-metrics.py
Queries the GitHub API for the current quarter and appends a
metrics entry to governance/metrics.yaml.

Dwell time is calculated from GitHub's issue timeline API —
the time each item spent in each status label state. No additional
manual work required beyond applying status labels correctly.

Key diagnostic output:
  diagnosis: capacity-constraint | behaviour-problem | mixed
  This is the primary story the metrics tell — whether dwell
  is accumulating at PA (capacity) or at submitters (behaviour).

Usage:
    python docs/collect-metrics.py --quarter 2025-Q3
    python docs/collect-metrics.py --quarter 2025-Q3 --pa-login your-github-username
    python docs/collect-metrics.py --quarter 2025-Q3 --dry-run

Prerequisites:
    pip install PyGithub pyyaml
    export GITHUB_TOKEN=your_token
    Run from repo root.
"""

import argparse
import os
import sys
import yaml
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

try:
    from github import Github
    from github.GithubException import GithubException
except ImportError:
    print("pip install PyGithub pyyaml")
    sys.exit(1)


QUARTER_DATES = {
    "Q1": ("01-01", "03-31"),
    "Q2": ("04-01", "06-30"),
    "Q3": ("07-01", "09-30"),
    "Q4": ("10-01", "12-31"),
}

STATUS_LABELS = [
    "status:awaiting-pa",
    "status:awaiting-submitter",
    "status:awaiting-cyber",
    "status:awaiting-da",
    "status:in-progress",
    "status:blocked",
    "status:remediation-open",
]


def parse_quarter(q):
    year, qname = q.split("-")
    s, e = QUARTER_DATES[qname]
    start = datetime.strptime(f"{year}-{s}", "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end   = datetime.strptime(f"{year}-{e}", "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return start, end


def naive(dt):
    if dt is None: return None
    return dt.replace(tzinfo=None) if dt.tzinfo else dt


def labels(item):
    return [l.name for l in item.labels]


def has(item, prefix):
    return any(l.startswith(prefix) for l in labels(item))


def get(item, prefix):
    m = [l for l in labels(item) if l.startswith(prefix)]
    return m[0].replace(prefix, "") if m else None


def avg(vals):
    v = [x for x in vals if x is not None and x >= 0]
    return round(sum(v) / len(v), 1) if v else 0


def p90(vals):
    v = sorted([x for x in vals if x is not None and x >= 0])
    return v[int(len(v) * 0.9)] if v else 0


def cycle(item):
    c, cl = naive(item.created_at), naive(item.closed_at)
    return round((cl - c).total_seconds() / 86400, 1) if c and cl else None


def by_domain(items):
    d = {}
    for i in items:
        dom = get(i, "domain:")
        if dom: d[dom] = d.get(dom, 0) + 1
    return d


def dwell_times(issue):
    """Time spent in each status label, from GitHub timeline events."""
    dwell = defaultdict(float)
    entered = {}
    try:
        for ev in issue.get_timeline():
            lname = ev.label.name if hasattr(ev, 'label') and ev.label else None
            if not lname or lname not in STATUS_LABELS:
                continue
            t = naive(ev.created_at)
            if ev.event == "labeled":
                entered[lname] = t
            elif ev.event == "unlabeled" and lname in entered:
                if entered[lname] and t:
                    dwell[lname] += (t - entered.pop(lname)).total_seconds() / 86400
    except GithubException:
        return {}
    # Still-active labels
    now = datetime.utcnow()
    endpoint = naive(issue.closed_at) or now
    for lname, t in entered.items():
        if t:
            dwell[lname] += (endpoint - t).total_seconds() / 86400
    return dict(dwell)


def first_response(issue, pa_login=None):
    """Days from issue created to first PA comment (or any comment if no login given)."""
    created = naive(issue.created_at)
    if not created: return None
    try:
        for c in sorted(issue.get_comments(), key=lambda x: naive(x.created_at)):
            if pa_login is None or c.user.login == pa_login:
                t = naive(c.created_at)
                if t: return round((t - created).total_seconds() / 86400, 1)
    except GithubException:
        pass
    return None


def collect(repo, start, end, pa_login=None):
    sn, en = naive(start), naive(end)

    all_issues = list(repo.get_issues(state="all", since=start))
    issues = [i for i in all_issues
              if i.created_at and sn <= naive(i.created_at) <= en
              and i.pull_request is None]

    all_prs = list(repo.get_pulls(state="all"))
    prs = [p for p in all_prs
           if p.created_at and sn <= naive(p.created_at) <= en]

    print(f"  Issues: {len(issues)}  PRs: {len(prs)}")
    print("  Collecting dwell times...")

    # ── Dwell by status ───────────────────────────────────────────────────
    dwell_by_status = defaultdict(list)
    first_resp = []

    for i in issues:
        for status, days in dwell_times(i).items():
            dwell_by_status[status].append(days)
        fr = first_response(i, pa_login)
        if fr is not None:
            first_resp.append(fr)

    def dwell_stat(status):
        times = dwell_by_status.get(status, [])
        return {
            "avg_days":   avg(times),
            "p90_days":   p90(times),
            "item_count": len(times),
        }

    dwell_stats = {s.replace("status:", ""): dwell_stat(s) for s in STATUS_LABELS}

    # ── Diagnosis ─────────────────────────────────────────────────────────
    pa_avg  = dwell_stats["awaiting-pa"]["avg_days"]
    sub_avg = dwell_stats["awaiting-submitter"]["avg_days"]

    if pa_avg == 0 and sub_avg == 0:
        diagnosis = "insufficient-data"
    elif pa_avg > sub_avg * 2:
        diagnosis = "capacity-constraint"
    elif sub_avg > pa_avg * 2:
        diagnosis = "behaviour-problem"
    else:
        diagnosis = "mixed"

    DIAG_NOTES = {
        "capacity-constraint": "Dwell concentrated at awaiting-pa. PA is the bottleneck. Supports headcount Option A (CSD).",
        "behaviour-problem":   "Dwell concentrated at awaiting-submitter. Submissions are incomplete or raised too early. Process adoption issue — not a capacity problem.",
        "mixed":               "Dwell distributed across PA and submitter states. Both capacity and behaviour are contributing.",
        "insufficient-data":   "Insufficient data. Ensure status labels are being applied correctly on all Issues.",
    }

    # ── Decision points ───────────────────────────────────────────────────
    dp02 = [p for p in prs if has(p, "dp:02") or has(p, "type:compliant-solution")]
    dp03 = [i for i in issues if has(i, "type:deviation") or has(i, "dp:03")]
    dp07 = [i for i in issues if has(i, "type:endorsement") or has(i, "dp:07")]
    dp08 = [i for i in issues if has(i, "dp:08")]

    def oc(items, outcome):
        return sum(1 for i in items if outcome in labels(i))

    retro = [i for i in issues if has(i, "type:retrospective")]

    all_open_devs = [i for i in all_issues
                     if i.state == "open"
                     and (has(i, "type:deviation") or has(i, "dp:03"))
                     and i.pull_request is None]

    dev_ages = [(datetime.utcnow() - naive(i.created_at)).days
                for i in all_open_devs if naive(i.created_at)]

    # Remediations closed this quarter
    rem_closed = [i for i in all_issues
                  if i.state == "closed"
                  and "outcome:endorsed-with-conditions" in labels(i)
                  and naive(i.closed_at) and sn <= naive(i.closed_at) <= en]

    opfeed = [i for i in issues if has(i, "type:operational-feedback")]
    opfeed_open = [i for i in all_issues
                   if has(i, "type:operational-feedback") and i.state == "open"
                   and i.pull_request is None]

    prog = {}
    for i in issues:
        p = get(i, "programme:")
        if p: prog[p] = prog.get(p, 0) + 1

    def reg(tag):
        return sum(1 for i in issues if f"risk:{tag}" in labels(i) and has(i, "type:deviation"))

    artistic    = [i for i in issues if "evidence:artistic-licence" in labels(i)]
    bottleneck  = [i for i in issues if "evidence:pa-bottleneck" in labels(i)]
    cap_gap     = [i for i in issues if "evidence:capability-gap" in labels(i)]
    awaiting_pa = [i for i in all_issues
                   if "status:awaiting-pa" in labels(i) and i.state == "open"
                   and i.pull_request is None]

    return {
        "throughput": {
            "dp02_compliant_solutions": {
                "volume":             len(dp02),
                "avg_cycle_days":     avg([cycle(p) for p in dp02]),
                "p90_cycle_days":     p90([cycle(p) for p in dp02]),
            },
            "dp03_deviations": {
                "volume":             len(dp03),
                "avg_cycle_days":     avg([cycle(i) for i in dp03]),
                "p90_cycle_days":     p90([cycle(i) for i in dp03]),
                "by_outcome": {
                    "endorsed":                  oc(dp03, "outcome:endorsed"),
                    "endorsed_with_conditions":  oc(dp03, "outcome:endorsed-with-conditions"),
                    "not_endorsed":              oc(dp03, "outcome:not-endorsed"),
                },
                "by_domain": by_domain(dp03),
            },
            "dp07_endorsements": {
                "volume":             len(dp07),
                "avg_cycle_days":     avg([cycle(i) for i in dp07]),
                "p90_cycle_days":     p90([cycle(i) for i in dp07]),
                "by_outcome": {
                    "endorsed":                  oc(dp07, "outcome:endorsed"),
                    "endorsed_with_conditions":  oc(dp07, "outcome:endorsed-with-conditions"),
                    "not_endorsed":              oc(dp07, "outcome:not-endorsed"),
                },
            },
            "dp08_deviation_approvals": {
                "volume":                          len(dp08),
                "avg_cycle_days":                  avg([cycle(i) for i in dp08]),
                "open_remediations_carried_fwd":   len([i for i in all_issues if "status:remediation-open" in labels(i) and i.state == "open"]),
                "remediations_closed_this_qtr":    len(rem_closed),
                "avg_days_to_remediate":           avg([cycle(i) for i in rem_closed]),
            },
            "retrospective_submissions": {
                "volume":     len(retro),
                "rate_pct":   round(len(retro) / max(len(dp02) + len(dp03), 1) * 100, 1),
                "by_domain":  by_domain(retro),
            },
            "pa_bottleneck": {
                "events":              len(bottleneck),
                "current_queue_depth": len(awaiting_pa),
            },
            "first_response_to_issue": {
                "avg_days":    avg(first_resp),
                "p90_days":    p90(first_resp),
                "sample_size": len(first_resp),
            },
        },
        "dwell": {
            "diagnosis":      diagnosis,
            "diagnosis_note": DIAG_NOTES[diagnosis],
            "by_status":      dwell_stats,
        },
        "capability": {
            "csd_transition": {
                "thread_1_sessions_run":   0,   # manual
                "named_csd_reviewers":     0,   # manual
                "csds_meeting_trigger":    0,   # manual
                "trigger_met":             False,
            },
            "capability_gap_events": len(cap_gap),
        },
        "risk": {
            "artistic_licence": {
                "volume":    len(artistic),
                "by_domain": by_domain(artistic),
            },
            "open_deviations": {
                "total":      len(all_open_devs),
                "by_domain":  by_domain(all_open_devs),
                "oldest_days": max(dev_ages) if dev_ages else 0,
                "avg_age_days": avg(dev_ages),
            },
            "deviations_by_regulatory_tag": {
                "PCI-DSS":    reg("PCI-DSS"),
                "DORA":       reg("DORA"),
                "PRA-SS2/21": reg("PRA-SS2/21"),
            },
            "operational_feedback": {
                "raised":   len(opfeed),
                "actioned": sum(1 for i in opfeed if i.state == "closed"),
                "open":     len(opfeed_open),
            },
            "programme_events_by_programme": prog,
        },
        "narrative": "TODO — PA adds diagnosis interpretation and headcount observation here.",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--quarter",  required=True)
    parser.add_argument("--pa-login", default=None)
    parser.add_argument("--dry-run",  action="store_true")
    args = parser.parse_args()

    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("Error: GITHUB_TOKEN not set")
        sys.exit(1)

    start, end = parse_quarter(args.quarter)
    print(f"Quarter: {args.quarter}  ({start.date()} to {end.date()})")

    g    = Github(token)
    import subprocess
    url  = subprocess.check_output(["git", "remote", "get-url", "origin"], text=True).strip()
    name = url.replace("https://github.com/", "").replace(".git", "")
    repo = g.get_repo(name)
    print(f"Repo: {name}")

    data  = collect(repo, start, end, args.pa_login)
    entry = {"quarter": args.quarter, "period_start": str(start.date()), "period_end": str(end.date()), **data}

    if args.dry_run:
        print(yaml.dump([entry], default_flow_style=False, sort_keys=False))
        return

    path = Path("governance/metrics.yaml")
    doc  = yaml.safe_load(path.read_text())
    doc["quarters"] = [q for q in doc.get("quarters", []) if q["quarter"] != args.quarter]
    doc["quarters"].append(entry)
    path.write_text(yaml.dump(doc, default_flow_style=False, sort_keys=False))

    print(f"\nWritten to governance/metrics.yaml")
    print(f"\nDiagnosis: {data['dwell']['diagnosis'].upper()}")
    print(f"  {data['dwell']['diagnosis_note']}")
    print(f"\nManual: update csd_transition fields and write narrative.")


if __name__ == "__main__":
    main()
