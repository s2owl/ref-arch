#!/usr/bin/env python3
"""
docs/publish-to-confluence.py
Publishes governance artefacts from GitHub to Confluence.

Reads docs/confluence-page-map.yaml for the source → page mapping.
Requires environment variables (set as GitHub Secrets):
  CONFLUENCE_BASE_URL       e.g. https://your-org.atlassian.net/wiki
  CONFLUENCE_SPACE_KEY      e.g. NETARCH
  CONFLUENCE_PARENT_PAGE_ID numeric page ID of the parent page
  CONFLUENCE_API_TOKEN      API token or personal access token
  CONFLUENCE_USER_EMAIL     email address (Confluence Cloud only)

Usage:
  python docs/publish-to-confluence.py              # publish all
  python docs/publish-to-confluence.py --id role-csd  # publish one page
  python docs/publish-to-confluence.py --dry-run    # validate only
"""

import argparse
import os
import re
import sys
import json
import yaml
import base64
from pathlib import Path

try:
    import requests
except ImportError:
    print("pip install requests pyyaml")
    sys.exit(1)


# ── Confluence REST API ───────────────────────────────────────────────────

class ConfluenceClient:
    def __init__(self, base_url, user_email, api_token):
        self.base_url = base_url.rstrip("/")
        self.api_base = f"{self.base_url}/rest/api"
        # Cloud uses Basic auth with email:token
        # Server uses Bearer token
        if user_email:
            creds = base64.b64encode(f"{user_email}:{api_token}".encode()).decode()
            self.headers = {
                "Authorization": f"Basic {creds}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        else:
            self.headers = {
                "Authorization": f"Bearer {api_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }

    def get_page(self, page_id):
        r = requests.get(
            f"{self.api_base}/content/{page_id}",
            params={"expand": "version,body.storage"},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    def update_page(self, page_id, title, body, current_version):
        payload = {
            "version": {"number": current_version + 1},
            "title": title,
            "type": "page",
            "body": {
                "storage": {
                    "value": body,
                    "representation": "storage",
                }
            },
        }
        r = requests.put(
            f"{self.api_base}/content/{page_id}",
            headers=self.headers,
            data=json.dumps(payload),
        )
        r.raise_for_status()
        return r.json()

    def get_page_url(self, page_id):
        page = self.get_page(page_id)
        return f"{self.base_url}{page['_links']['webui']}"


# ── Content converters ────────────────────────────────────────────────────

def markdown_to_confluence(md_text):
    """
    Convert Markdown to Confluence storage format.
    Handles the most common patterns in our role cards and CONTRIBUTING.
    For complex documents, considers Pandoc as an alternative.
    """
    text = md_text

    # Remove front matter if present
    text = re.sub(r'^---\n.*?\n---\n', '', text, flags=re.DOTALL)

    # Headings
    text = re.sub(r'^#### (.+)$', r'<h4>\1</h4>', text, flags=re.MULTILINE)
    text = re.sub(r'^### (.+)$',  r'<h3>\1</h3>', text, flags=re.MULTILINE)
    text = re.sub(r'^## (.+)$',   r'<h2>\1</h2>', text, flags=re.MULTILINE)
    text = re.sub(r'^# (.+)$',    r'<h1>\1</h1>', text, flags=re.MULTILINE)

    # Horizontal rules
    text = re.sub(r'^---+$', r'<hr/>', text, flags=re.MULTILINE)

    # Bold and italic
    text = re.sub(r'\*\*\*(.+?)\*\*\*', r'<strong><em>\1</em></strong>', text)
    text = re.sub(r'\*\*(.+?)\*\*',     r'<strong>\1</strong>', text)
    text = re.sub(r'\*(.+?)\*',         r'<em>\1</em>', text)

    # Inline code
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)

    # Code blocks
    def replace_code_block(m):
        lang = m.group(1) or "none"
        code = m.group(2).strip()
        return (
            f'<ac:structured-macro ac:name="code">'
            f'<ac:parameter ac:name="language">{lang}</ac:parameter>'
            f'<ac:plain-text-body><![CDATA[{code}]]></ac:plain-text-body>'
            f'</ac:structured-macro>'
        )
    text = re.sub(r'```(\w*)\n(.*?)```', replace_code_block, text, flags=re.DOTALL)

    # Tables
    def replace_table(m):
        rows = [r.strip() for r in m.group(0).strip().split('\n') if r.strip()]
        rows = [r for r in rows if not re.match(r'^\|[-| ]+\|$', r)]
        if not rows:
            return m.group(0)
        html = '<table><tbody>'
        for i, row in enumerate(rows):
            cells = [c.strip() for c in row.strip('|').split('|')]
            tag = 'th' if i == 0 else 'td'
            html += '<tr>' + ''.join(f'<{tag}>{c}</{tag}>' for c in cells) + '</tr>'
        html += '</tbody></table>'
        return html
    text = re.sub(r'(\|.+\|\n)+', replace_table, text)

    # Blockquotes → info panel
    def replace_blockquote(m):
        content = re.sub(r'^> ?', '', m.group(0), flags=re.MULTILINE).strip()
        return (
            f'<ac:structured-macro ac:name="info">'
            f'<ac:rich-text-body><p>{content}</p></ac:rich-text-body>'
            f'</ac:structured-macro>'
        )
    text = re.sub(r'(^> .+\n?)+', replace_blockquote, text, flags=re.MULTILINE)

    # Unordered lists
    def replace_ul(m):
        items = re.findall(r'^[-*] (.+)$', m.group(0), re.MULTILINE)
        html = '<ul>' + ''.join(f'<li>{i}</li>' for i in items) + '</ul>'
        return html
    text = re.sub(r'(^[-*] .+\n?)+', replace_ul, text, flags=re.MULTILINE)

    # Ordered lists
    def replace_ol(m):
        items = re.findall(r'^\d+\. (.+)$', m.group(0), re.MULTILINE)
        html = '<ol>' + ''.join(f'<li>{i}</li>' for i in items) + '</ol>'
        return html
    text = re.sub(r'(^\d+\. .+\n?)+', replace_ol, text, flags=re.MULTILINE)

    # Paragraphs — wrap remaining bare lines
    lines = text.split('\n')
    result = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            result.append('')
        elif stripped.startswith('<'):
            result.append(stripped)
        else:
            result.append(f'<p>{stripped}</p>')
    text = '\n'.join(result)

    return text


def html_to_confluence_iframe(html_content, title):
    """
    Embed an HTML page as a Confluence HTML macro.
    Used for the process maps which are standalone HTML files.
    """
    encoded = base64.b64encode(html_content.encode('utf-8')).decode('utf-8')
    # Use Confluence HTML macro for inline HTML
    # Falls back to a note with a link if HTML macro is disabled
    body = f"""
<ac:structured-macro ac:name="html">
  <ac:plain-text-body><![CDATA[{html_content}]]></ac:plain-text-body>
</ac:structured-macro>
<ac:structured-macro ac:name="info">
  <ac:rich-text-body>
    <p>This page is auto-published from the governance repository.
    To view the full interactive version, open the source HTML file
    in the repository: <code>governance/{title.lower().replace(' ', '-').replace('&amp;', 'and')}.html</code></p>
  </ac:rich-text-body>
</ac:structured-macro>
"""
    return body


def raci_to_confluence(raci_yaml_path):
    """
    Render the RACI decision points as a Confluence table.
    Extracts current-state RACI from governance/raci.yaml.
    """
    doc = yaml.safe_load(Path(raci_yaml_path).read_text())
    decisions = doc.get("decisions", [])

    ROLES = ["PA", "CSD", "ENG", "MGR", "GCB3", "SME", "CYB", "OPS", "ARG", "DA"]

    html = """
<h2>Governance RACI — Current State</h2>
<p>R = Responsible &nbsp;|&nbsp; A = Accountable &nbsp;|&nbsp;
C = Consulted &nbsp;|&nbsp; I = Informed &nbsp;|&nbsp; — = Not involved</p>
<p><em>Auto-published from governance/raci.yaml. For full detail including notes
and target state, see the repository.</em></p>
<table>
<tbody>
<tr>
  <th>ID</th>
  <th>Decision Point</th>
"""
    for role in ROLES:
        html += f"  <th>{role}</th>\n"
    html += "</tr>\n"

    def cell_color(val):
        colors = {
            "A": "#fdf5f0", "A/R": "#fdf5f0",
            "R": "#f0f7f0",
            "C": "#f0f4f8",
            "I": "#fafafa",
            "audit": "#fffbeb",
        }
        return colors.get(str(val), "#ffffff")

    for dp in decisions:
        current = dp.get("raci", {}).get("current", {})
        html += f"""<tr>
  <td><code>{dp['id']}</code></td>
  <td>{dp['title']}</td>
"""
        for role in ROLES:
            val = current.get(role, "—")
            color = cell_color(val)
            html += f'  <td style="background:{color};text-align:center;font-weight:bold">{val}</td>\n'
        html += "</tr>\n"

    html += "</tbody></table>\n"
    return html


# ── Main ──────────────────────────────────────────────────────────────────

def load_env():
    return {
        "base_url":    os.environ.get("CONFLUENCE_BASE_URL", ""),
        "space_key":   os.environ.get("CONFLUENCE_SPACE_KEY", ""),
        "parent_id":   os.environ.get("CONFLUENCE_PARENT_PAGE_ID", ""),
        "user_email":  os.environ.get("CONFLUENCE_USER_EMAIL", ""),
        "api_token":   os.environ.get("CONFLUENCE_API_TOKEN", ""),
    }


def publish_page(client, page_def, dry_run=False):
    page_id = page_def.get("confluence_page_id")
    if not page_id:
        print(f"  SKIP {page_def['id']} — no confluence_page_id set in page map")
        print(f"       Create the page in Confluence first, then add its ID to docs/confluence-page-map.yaml")
        return False

    source = Path(page_def["source"])
    if not source.exists():
        print(f"  SKIP {page_def['id']} — source file not found: {source}")
        return False

    page_type = page_def.get("type", "markdown")
    title = page_def["confluence_title"]

    print(f"  Publishing: {page_def['id']} → '{title}' (page {page_id})")

    # Convert content
    if page_type == "html":
        body = html_to_confluence_iframe(source.read_text(), title)
    elif page_type == "raci-summary":
        body = raci_to_confluence(source)
    else:
        body = markdown_to_confluence(source.read_text())

    if dry_run:
        print(f"    DRY RUN — would update page {page_id} with {len(body)} chars")
        return True

    # Get current version
    try:
        current = client.get_page(page_id)
        version = current["version"]["number"]
    except Exception as e:
        print(f"    ERROR fetching page {page_id}: {e}")
        return False

    # Update
    try:
        client.update_page(page_id, title, body, version)
        url = client.get_page_url(page_id)
        print(f"    ✓ Updated → {url}")
        return True
    except Exception as e:
        print(f"    ERROR updating page {page_id}: {e}")
        return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--id",      default=None, help="Publish a single page by its id in the page map")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    env = load_env()
    missing = [k for k, v in env.items() if not v and k != "user_email"]
    if missing:
        print(f"Error: missing environment variables: {', '.join(missing)}")
        print("Set them as GitHub Secrets — see docs/confluence-setup.md")
        sys.exit(1)

    page_map_path = Path("docs/confluence-page-map.yaml")
    page_map = yaml.safe_load(page_map_path.read_text())
    pages = page_map.get("pages", [])

    if args.id:
        pages = [p for p in pages if p["id"] == args.id]
        if not pages:
            print(f"No page found with id '{args.id}' in docs/confluence-page-map.yaml")
            sys.exit(1)

    if args.dry_run:
        print("DRY RUN — no changes will be made to Confluence\n")
        client = None
    else:
        client = ConfluenceClient(env["base_url"], env["user_email"], env["api_token"])

    success, skipped, failed = 0, 0, 0
    for page in pages:
        result = publish_page(client, page, dry_run=args.dry_run)
        if result is True:
            success += 1
        elif result is False and page.get("confluence_page_id"):
            failed += 1
        else:
            skipped += 1

    print(f"\nDone: {success} published, {skipped} skipped (no page ID), {failed} failed")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
