# Role Card — SME / Peer Architect

> Your part in the governance process.
> One page. Keep it visible.

---

## Your accountability

You are the **domain expert** in your technical specialism.
You **produce** artefacts that PA gates — PA does not produce them for you.

| Artefact | Your role |
|---|---|
| SBB | You produce — PA reviews against ABB capability gates |
| VSBB | You produce — PA reviews against SBB capability gates |
| Standard | You produce (triggered by operational reality) — PA approves |
| Pattern | You may initiate (engineering-initiated) — PA codifies and approves |

---

## When to write a standard

Standards are triggered by **operational reality**, not speculation.

Valid triggers:
- An unwritten rule surfaced in peer review or forum
- A deviation being raised repeatedly (signals a missing rule)
- A new platform introducing undocumented norms
- A cross-domain risk that exposes a boundary gap

**Invalid trigger:** PA decides a standard should exist without an operational grounding.

When you write a standard:
1. Copy `standards/STANDARD-TEMPLATE.yaml`
2. Populate `operational_owner` — that's you. Without it the standard has no one to flag drift.
3. Set `trigger` — why does this standard exist?
4. Set `co_reviewed_by` if it intersects another domain (e.g. Cyber)
5. Write the rules using MUST / MUST NOT. Include rationale for every rule.
6. Raise a PR. PA reviews and approves.

---

## Your drift obligation

If you are the `operational_owner` of a standard or SBB,
you are accountable for flagging when reality diverges from it.

This is not an annual review. It is an ongoing obligation.
When something changes in practice, raise an **Operational Feedback** GitHub Issue.
PA assesses and updates artefacts where needed.

PA does **not** certify your artefacts annually. You flag when they're wrong.

---

## In the Arch/Eng Forum

**Thread 1 — you are Accountable for the quality of peer feedback.**
Challenge topologies against ZBB boundary contracts.
Your domain expertise is the governance value you bring.
This is how governance fluency develops.

**Thread 2 — you are Consulted.**
Provide technical input before PA makes the endorsement decision.

---

## The topology conformance challenge

When reviewing a solution in Thread 1, always ask:

1. Are all components approved VSBBs?
2. Do all traffic flows match the ZBB boundary contract for the zones involved?
   → The F5-via-firewall problem: both components approved, topology non-compliant
3. Are there flows the submitter cannot trace to a ZBB rule or pattern?

If the answer to 2 or 3 is no — that is a deviation, regardless of component approval.

---

## GitHub Issue templates

| Situation | Template |
|---|---|
| Operational standard gap found | `operational-feedback.yaml` |
| New SBB or standard ready for review | Raise a PR |

---

*See CONTRIBUTING.md for full guidance · s2owl/ref-arch*
