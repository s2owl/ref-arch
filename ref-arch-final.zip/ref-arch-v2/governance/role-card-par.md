# Role Card — PAR (Peer Architect)

> Your part in the governance process.
> One page. Keep it visible.

---

## Who you are

You are a cross-platform network generalist inside the networks
organisation. You understand how platforms interact across the
estate — how an F5 sits in front of a Checkpoint in front of
an ACI fabric — rather than specialising in just one.

You are not in PA's organisation. You report to your own director
under the Networks MD. The governance relationship between you and
PA is **lateral** — you collaborate through the forum, you do not
report into architecture.

You are not a single-technology SME. You are not an engineer
deploying to approved patterns. Your value is the breadth to
see across the domain and challenge topology, not just components.

---

## What you are developing

You already have the technical depth. What the forum develops
is **governance application** of that depth:

- Reading a Zonal Building Block (ZBB) boundary contract and
  identifying whether a proposed traffic flow violates it
- Distinguishing between "this component is approved" and
  "this topology is compliant" — these are different questions
- Challenging a solution not just on whether the right kit is
  used, but whether it is assembled correctly

This is the specific capability gap between where you are now
and holding peer review accountability.

---

## Your role in the forum

**Thread 1 — Socialise:** You are **Accountable** for the quality
of peer feedback. PA attends in the current period to model the
right challenge pattern — topology against ZBB boundary contract,
not just component list. As you internalise that model, PA steps
back and you lead.

**Thread 2 — Endorsement:** You are **Consulted**. Provide
technical input across platforms before PA makes the endorsement
decision.

---

## The transition threshold

You take accountability for compliant solution sign-off (DP-02)
when you have met all three:

1. Participated in 6 Thread 1 sessions as a named reviewer
   with documented feedback
2. Reviewed 3 Pull Requests involving topology conformance assessment
3. PA has confirmed your conformance judgement is consistent
   with framework intent on at least 2 occasions

Until then, PA validates. The threshold is a governance capability
test — not a test of your technical knowledge, which is not in doubt.

---

## The topology conformance challenge

When reviewing in Thread 1, always ask these three questions:

**TC-01** Are all components approved VSBBs?

**TC-02** Do all traffic flows match the ZBB boundary contract
for the zones involved? Does the path the traffic takes match
the enforcement model? Is every inline component named?

**TC-03** Can every traffic path be traced to a ZBB rule or
an approved pattern? If not — undocumented, and a deviation.

The F5-via-firewall example: both components approved. But if
the firewall is inline on a flow where it is not named as an
enforcement point in the ZBB boundary contract, TC-02 fails.
That is the call you are being developed to make.

---

*See CONTRIBUTING.md for full guidance · s2owl/ref-arch*
