# "Training" Gemini for this task

**There is no fine-tuning in this pipeline.** Gemini 3.5 Flash's weights
are fixed — nothing here changes the model itself. What we're actually
doing is **prompt engineering**: shaping the model's behaviour for this
one call through instructions, a strict output schema, and worked
examples. This is the correct and standard approach for a bounded
classification task like this — fine-tuning would be overkill, slower
to iterate, and unnecessary at this data volume.

There are three levers, in order of how much they matter:

## 1. The output schema (`src/schema.py`)
This is your strongest lever. Structured output with `enum` constraints
on fields like `capability` and `confidence` forces the model into a
fixed vocabulary — it physically cannot return "Access Control" when
you've constrained it to `IAM`. Get this right first; it prevents an
entire class of drift before you touch the prompt wording.

## 2. Few-shot examples (`src/prompts.py` → `FEW_SHOT_EXAMPLES`)
This is where most of your iteration time should go. For a Flash-tier
model on a domain-specific task like ABB/CBB matching, 2-3 well-chosen,
hand-validated examples typically move accuracy more than any amount of
instruction wording. Populate this with:

- One example from each band extreme you're testing (e.g. ATM/cellular,
  mid-size branch, large campus) — this teaches the model the band
  boundary, not just the classification mechanics
- Full input/output pairs, not abbreviated ones — the model learns the
  *shape* of a correct answer from seeing the whole thing

**Process:** hand-classify 2-3 sites yourself (or with a colleague) to
get a known-correct answer, add them as few-shot examples, then test
against a *different* held-out site to check the examples generalise
rather than just memorising themselves back.

## 3. Instructions (`src/prompts.py` → `SYSTEM_INSTRUCTIONS`)
Useful for stating hard rules (don't invent building blocks, don't judge
correctness, cite evidence) but has less effect on accuracy than the
two levers above once the schema is in place. Keep it short and rule-
based rather than descriptive — the schema and examples are doing the
heavy lifting.

## Validation loop

1. Hand-classify 2-3 sites → add as few-shot examples
2. Run classification against a **different**, held-out set of curated
   sites
3. Compare model output to what you know is correct, field by field
4. If `matched_cbb` or `capabilities` are wrong, check `evidence` first
   — if the cited evidence doesn't actually support the claim, that's
   usually a sign the catalogue slice or prompt needs tightening, not
   that the model is unfixably wrong
5. Only scale to the full curated batch (10-15 sites) once accuracy
   holds on the held-out set

## What NOT to do
- Don't keep adding instructions to `SYSTEM_INSTRUCTIONS` to fix errors
  one at a time — if you're seeing a pattern of errors, it's almost
  always better fixed with a clearer schema constraint or a better
  few-shot example than another paragraph of instruction text
- Don't skip the held-out validation step — testing only against the
  same sites used as few-shot examples will look artificially accurate
