# Roadmap / scope boundary

## Phase 1 (this repo): Classification
Given a site config and the ABB/SBB/VSBB/CBB catalogue, identify which
building blocks the config represents and which capabilities
(Monitoring, Segmentation, Resilience, Routing, IAM) it implements.
No judgement about correctness, compliance, or drift.

**This phase is explicitly non-agentic.** Every call is a single,
code-orchestrated request with a fixed input — the model returns
structured output and does not decide what to query or act on next.

## Phase 1.5 (not yet built): Deviation detection
Given a classified site's `matched_cbb`, diff the actual config against
what that CBB specifies, and flag deviations with rationale. This is a
separate schema and separate prompt from Phase 1 — don't combine them
into one call, since classification and deviation-judgement are
different tasks with different failure modes to validate independently.

## Phase 2 (not yet built): Divergence / pattern clustering
Given classification results across multiple sites in the same band,
identify where the same capability has been implemented via different
CBBs without a band justification — the actual "divergence" finding.
Operates on aggregated Phase 1 output, not raw config.

## Phase 3 (future value, not committed): Query layer
Natural-language query over the classified catalogue. Likely needs
retrieval/embedding once the catalogue or result set grows beyond what
fits in a single prompt context — not needed at current curated-subset
scale.

## Out of scope entirely for this build
- Live telemetry augmentation (link status, bandwidth utilisation) —
  ops-owned, not architecture-owned
- Any autonomous/agentic behaviour (the model deciding what to
  investigate or acting with write access) — would require a separate
  governance review, see business case doc
- Standard/regulatory-intent inference (why a config looks the way it
  does) — treated as a human-reviewed hypothesis only, never a stated
  finding
