# Roadmap / scope boundary

**Taxonomy note (critical):** every ABB has two independent children — SBB
(solution/transport option) and ZBB (zonal boundary control — anything that
restricts inbound/outbound communication, e.g. ACL, zonal firewall, service
mesh policy). They vary independently: two sites can share the same SBB while
differing on ZBB, or vice versa. Both are classified and measured separately
throughout this pipeline — see `src/schema.py` and
`docs/example-output/single-site-classification.json`.

**WiFi scope boundary (critical):** wave one's only input is router/switch
config from the compliance monitor. WLC/AP management (SSID names, RF
config, wireless-specific policy) is a **different source of truth**, out
of scope. WiFi ABB evidence is therefore limited to what's visible on the
wired side — a VLAN identified/trunked for WiFi traffic — never inferred
AP/WLC detail. SBB type is always `"VLAN-Identified"`, and confidence on
WiFi ABB matches is capped at medium. Integrating the WLC/AP source of
truth to get real wireless-layer classification is a future-wave item, not
current scope — see `docs/BAND_APPLICABILITY.md` and the future-value
exhibits in the business case.

**Hardening findings (critical distinction):** two genuinely different
check types, not one. **Absolute** findings (Telnet enabled, weak SNMP
strings) are always wrong regardless of band — detected and judged at
classification time, deterministic where possible. **Contextual**
findings (e.g. EIGRP/OSPF redistribution without a route-map filter) are
NOT judged at classification time — the model only detects presence.
Correctness depends on the band baseline: if every same-band site has
it, it's baseline behaviour; if only some do, that's the flag. This
reuses the SAME within-band consistency mechanism already built for
SBB/ZBB pattern-matching (`src/patterns.py`) — see `src/hardening.py`.
**This is still Wave One, not Wave Two** — Wave Two is specifically the
separate cross-band/full-scale embedding layer; contextual hardening
baselines are computed within a single band using the aggregation
mechanism already in place.

**Gateway client correction (critical):** the gateway client was rebuilt
to match the org's real reference template — an OpenAI-compatible
`chat/completions` endpoint (`{BASE_URL}/{USER_ID}/chat/completions`),
not a generic shape. Classification now uses proper OpenAI-style
function/tool calling (`CLASSIFICATION_FUNCTION` in `src/schema.py`,
`call_with_function()` in `src/gateway_client.py`) so the schema is
enforced by the API itself via `tool_choice`, not just requested in
prompt text. Both the URL construction and the tool-call response
parsing were tested against the real template's exact shape before
committing — see the test output in conversation history, not just
illustrative examples.

**GUI-only access (critical, current reality):** no programmatic API
access is available — only a GUI (choose model, upload files, paste
prompt). `src/generate_gui_prompt.py` produces a self-contained prompt
with the schema spelled out explicitly in text (no function-calling
enforcement available), and `src/validate_manual_result.py` validates
whatever comes back against the exact same schema before it enters the
pipeline — catching missing fields, wrong types, or invalid enum values
that would otherwise silently corrupt downstream tooling. On success,
output lands in the identical `data/results/` location the automated
path would use, so every deterministic tool (patterns, standards, build
guide) works the same regardless of how classification was produced.
This is manual and slower, but the governance mechanism is unchanged —
tested end to end with a valid response, a markdown-fence-wrapped
response (common GUI artefact, stripped automatically), and a
deliberately broken response (missing required field, caught precisely).

**Multi-solution inventory per ABB (schema supports it, pattern-matching
doesn't yet — honest gap, found by testing, not by inspection):** one ABB
can genuinely have multiple independent solutions — e.g. User LAN
evidencing Routing, Switching, and QoS as three separate, independently
vendor/version-realised mechanisms, not one monolithic "Wired LAN" block.
`abb_matches` already supports this structurally (multiple entries can
share the same `abb` value, no schema change needed), and `standards.py`
already aggregates correctly across them (verified: iterates every
`abb_match`, not just one). **`pattern_catalogue`'s bundle structure does
NOT yet support it** — a pattern currently expects exactly one SBB+ZBB
per ABB, so a genuinely multi-solution site will show as fully diverging
against a pattern defined for a single monolithic solution, even when
every individual solution is perfectly fine. `pattern_catalogue`'s
`bundle[abb]` would need to become a list, with matching updates to
`patterns.py`, `derive_patterns.py`, `build_guide.py`, and
`governed_submission.py`'s diagram generation. Not built yet — worth
doing once real data shows how common the multi-solution pattern
actually is, rather than speculatively rebuilding pattern-matching for
a hypothetical. Added supporting schema fields now regardless:
`vsbb_version` (OS/code version — config can differ meaningfully
between versions of the same vendor+protocol) and `effective_restriction`
on ZBB (the actual restriction enforced, e.g. "Management access
restricted to 10.100.1.0/24", not just the mechanism name) — both
optional, both backward-compatible with already-classified data
(verified: existing real results still validate against the updated schema).

## Wave One (this repo): Classification + band definition + within-band consistency
Given a site config and the ABB/{SBB,ZBB}/VSBB/CBB catalogue, classify which
building blocks the config represents and which capabilities it implements
— across the full curated set (target: ~70 sites / 300+ router+switch
configs), not a single site in isolation.

At this scale, wave one does more than label individual configs. Grouping
classification output by band **empirically derives what each band's
canonical building blocks actually are**, rather than assuming a top-down
definition. This is the measure wave one produces:

- **Per-band canonical pattern** — the CBB(s) most sites in a band actually
  use for each capability
- **Within-band consistency score** — for each band, what proportion of
  sites match the canonical pattern per capability, and which sites don't
- **Divergence findings** — sites in the same band whose implementation
  differs from the canonical pattern with no band justification (see
  `docs/example-output/wave-one-band-summary.json` for the target shape)

**Minimum sample size**: don't treat a "canonical" pattern as established
from fewer than 3-4 same-band sites — below that threshold, output is
exploratory (what patterns exist) rather than a deviation measure (what
should be there). Flag low-sample bands explicitly in output rather than
asserting a canonical pattern that isn't statistically meaningful yet.

Still no deviation-vs-actual-config judgement at this wave — that's config
vs CBB, a separate check (see Wave 1.5 below). This wave establishes what
CBB *should* apply per band and whether sites agree with each other, not
whether any single site's live config matches its CBB.

**This wave is explicitly non-agentic.** Every call is a single,
code-orchestrated request with a fixed input — the model returns
structured output and does not decide what to query or act on next.

## Engineer-facing Build Guide (this repo, starter): the inverse of everything above
Everything else in Wave One / 1.x is AUDIT-facing — given a site that
already exists, is it consistent/compliant. `src/build_guide.py` is the
inverse, BUILD-facing: given a band (a set of requirements), tell an
engineer exactly what to deploy — SBB, provider, config template, ZBB —
with zero taxonomy knowledge required. The engineer never needs to know
what an ABB or VSBB is. If a band has no governed pattern yet, the guide
says so explicitly and tells the engineer to escalate rather than
improvise — it never invents a design. Building exactly to this guide
means a site passes every consistency and rule check by construction,
not by coincidence, which is what closes the loop between governance and
delivery. See `docs/example-output/build-guide-branch-mid-mpls-sdwan.md`
(pattern exists) and `build-guide-branch-small-cellular-no-pattern.md`
(pattern doesn't exist yet, honestly reported) — both real generated
output, tested against the actual catalogue.

## Wave 1.95 (future, documented only — not built): Tunneling ABB and purpose-based consistency
Key insight: the same SBB (e.g. GRE) can serve genuinely different
purposes — redirecting to a DDoS scrubbing provider (Akamai) vs a proxy
(Zscaler) vs site-to-site VPN — and consistency needs to be measured
BY PURPOSE, not just by mechanism. "Is GRE configured consistently"
and "is our DDoS-redirect posture consistent" are different questions;
collapsing them hides the one that actually matters for a regulator or
customer.

Proposed shape (no new taxonomy tier — one new field):
- **ABB**: `Tunneling` (or `Overlay Transport`) — likely sits alongside
  WAN/User/WiFi under Branch/Campus, though possibly its own Primary
  Capability given DDoS was already scoped separately from Branch/Campus
  earlier — needs deciding once real data exists, not guessed now.
- **SBB**: mechanism — GRE, IPsec, DTLS, etc.
- **`purpose`** (new field, sibling to sbb/zbb): what the tunnel is FOR —
  e.g. `DDoS-scrubbing-redirect`, `Proxy-redirect`, `Site-to-site-VPN`.
  This is what should be grouped on for the consistency check that
  actually matters, not the SBB mechanism alone.
- **VSBB**: destination provider (Akamai, Zscaler) — same pattern as WAN
  providers already in the catalogue.

Consistency check runs two ways once built: by mechanism (existing
pattern-matching logic, unchanged) and by purpose (new — is
`DDoS-scrubbing-redirect` delivered the same way estate-wide, regardless
of which specific mechanism happens to implement it at each site). The
second is the one worth prioritising, since it answers the question a
customer or regulator actually asks.

Not built — no Akamai/Zscaler data source exists yet. Same status as
Wave 1.75 (Mist overlay): documented design, awaiting a real source of
truth before implementation.

## Wave 1.9 (this repo, starter): ABB architecture documentation
Deterministic templating over the catalogue itself (`src/abb_documentation.py`)
— one document per ABB, not per site, in the narrative format: what the
ABB delivers, its SBB options, approved VSBBs (providers), ZBB options,
how resilience and security are delivered (pulled from Wave 1.8 rules),
and an auto-generated Mermaid reference diagram of the full
ABB->SBB/ZBB->VSBB->CBB tree. No AI call — reads directly from
`data/catalogue/catalogue.json`. This becomes the automated architecture
documentation objective once populated with real (not example) catalogue
data derived from Wave One pattern results. See
`docs/example-output/abb-documentation-WAN.md` — genuinely generated by
the code against the real repo catalogue, not hand-written.

## Wave 1.85 (this repo, starter): Customer-facing resilience statement
The taxonomy (ABB/SBB/ZBB/VSBB/CBB) is architecture's internal language —
customers don't want it, they want the answer to "if something fails,
what happens to my service, and how do you know?" `src/resilience_statement.py`
deterministically templates already-computed output (classification,
pattern-match, rule compliance) into a plain-language statement: what
resilience exists, whether the design matches the governed estate
standard, and which regulatory-backed rules are confirmed. No AI call —
this is templating over structured data already produced by Waves One,
1.x (patterns), and 1.8 (standards). The taxonomy remains the evidence
trail behind the statement, not something the customer needs to read.
See `docs/example-output/resilience-statement-example.md` — genuinely
generated by the code against real repo example data, not hand-written.

**Vendor pivot readiness (extension of Wave 1.8, this repo, starter):**
because `requirement_rules` are already stated at the capability level,
never naming a vendor, evaluating a candidate vendor (e.g. a commodity
alternative like Netgear against an incumbent Cisco estate) becomes a
deterministic gap check, not a redesign — `src/vendor_pivot.py`. Given a
vendor's declared capability coverage for an ABB, it reports which
mandatory rules are already satisfied and which aren't, each with its
regulatory basis. This is a PRE-PROCUREMENT check against the existing
spec, not a replacement for classifying real config once a vendor is
actually deployed — and it deliberately says nothing about commercial,
operational, or migration-cost factors, which stay a business decision.
See `docs/example-output/vendor-pivot-readiness-example.json` — real
computed output, not fabricated, including a genuine gap the tool
correctly caught (Logging wasn't declared in either test scenario).

**Vendor requirements brief (extension of Wave 1.8, this repo, starter):**
`src/vendor_requirements_brief.py` generates a clean, handoff-ready
document listing every mandatory requirement_rule for an ABB — meant to
be brought into a vendor meeting directly, so requirements come from a
governed source instead of being recalled from memory in the room. This
is the specific failure mode it prevents: an omitted requirement, or
scope creep from someone improvising requirements beyond what's actually
governed. The response column is deliberately blank — once a vendor
fills it in, that response is the input to
`check_vendor_pivot_readiness()`, closing the loop from "here's what we
require" to "here's whether you meet it." See
`docs/example-output/vendor-requirements-brief-WAN.md` — real generated
output.

## Wave 1.8 (this repo): Requirement rules -> measurable standards
Different from patterns (empirical: what the estate DOES) and different
from hardening (config-level right/wrong). This is NORMATIVE: what the
estate MUST do, stated as a governed rule (`requirement_rules` in the
catalogue), mapped to how that requirement is actually delivered as a
managed service (`managed_service_solution`), and tagged to its
regulatory basis. Evaluating a site against these rules is deterministic
— `src/standards.py` — no AI call needed, same as pattern-matching and
hardening aggregation.

This is what turns findings into a **measurable standard**: not "this
site looks inconsistent" but "RULE-ANY-LOGGING-003 has 78.6% compliance
across this band, here are the 3 non-compliant sites, here's the
regulatory basis, here's how it's meant to be delivered." That statement
is auditable and repeatable in a way a narrative finding isn't.

**Still Wave One-tier, not Wave Two** — same distinction as hardening.
Rules are evaluated within already-classified per-site output; no
cross-band embedding involved.

## Wave 1.5 (not yet built): Config-vs-CBB deviation detection
Given a classified site's SBB or ZBB `cbb`, diff the actual config against
what that CBB specifies, and flag deviations with rationale. Separate
schema/prompt from wave one — classification and deviation-judgement are
different tasks with different failure modes to validate independently.

## Wave Two (not yet built): Cross-band / full-scale embedding
Once band definitions and within-band consistency are established from
wave one, embedding lets you go wider across the full config set at scale
— clustering to catch what wave one's per-band comparison might miss:
sites potentially misclassified into the wrong band, or implementations
that don't cleanly match any established band pattern at all. This is
where an embedding model (distinct from the reasoning model used in wave
one) earns its place — vector similarity comparison scales far better
than holding hundreds of configs in a single reasoning prompt.

Two distinct embedding applications, not to be conflated:
- **Pattern/divergence discovery** (this wave) — embed configs or
  classification outputs, cluster by similarity
- **Query layer** (separate, future) — embed the catalogue itself for
  RAG-based natural-language question answering

## Phase 3 (future value, not committed): Query layer
Natural-language query over the classified catalogue. Likely needs
retrieval/embedding once the catalogue or result set grows beyond what
fits in a single prompt context — not needed at current curated-subset
scale.

## Out of scope entirely for this build
- Live telemetry augmentation (link status, bandwidth utilisation) —
  ops-owned, not architecture-owned
- Any autonomous/agentic behaviour (the model deciding what to
  investigate or acting with write access) — would require a separate
  governance review, see business case doc
- Standard/regulatory-intent inference (why a config looks the way it
  does) — treated as a human-reviewed hypothesis only, never a stated
  finding
