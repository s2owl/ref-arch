# Band Applicability Matrix

Which ABBs a site is expected to have depends on its band. A smaller site
correctly having fewer ABBs is not a gap — it's the band definition working
as intended. Pattern-level guardrails (see `pattern_catalogue`) then govern
*which* SBB/ZBB is selected within each applicable ABB, so consistency is
still enforced at the right level even when the block count differs.

| Band | Criteria | WAN | User | WiFi | Notes |
|---|---|---|---|---|---|
| `branch-micro-atm-cellular` | Single ATM device, cellular backhaul, no local users | ✅ | ❌ | ❌ | No local user population to serve |
| `branch-small-cellular` | <10 users, cellular-only backhaul | ✅ | ✅ | ❌ | Below the threshold that justifies managed WiFi |
| `branch-remote-satellite` | <10 users, no terrestrial backhaul | ✅ | ✅ | ❌ | Same threshold logic as cellular-small |
| `branch-mid-mpls-sdwan` | 50-200 users, dual-homed MPLS + SD-WAN | ✅ | ✅ | ✅ | Full ABB set |
| `branch-large-mpls-sdwan` | 200-500 users, multi-floor | ✅ | ✅ | ✅ | Full ABB set |
| `campus-mid-fibre` | 1,000-5,000 users, fibre transport | ✅ | ✅ | ✅ | Full ABB set |
| `campus-large-darkfibre` | 10,000+ users, 10G dark fibre to DC | ✅ | ✅ | ✅ | Full ABB set |

## How this is used

- **`missing_but_expected_for_band`** in pattern-match output — an ABB the
  band *should* have but wasn't found in the config. This is a real
  candidate finding (config gap or classification miss), worth review.
- **`not_applicable_for_band`** — an ABB the band deliberately doesn't
  require. Its absence is expected and should never be surfaced as a
  divergence or gap.

This distinction is what stops the pipeline from flagging every micro-ATM
site as "missing WiFi and User" — those ABBs were never expected there in
the first place.

## Maintaining this table

This is a judgement call, not a derived fact — thresholds like "10 users"
for WiFi applicability should be reviewed and owned the same way DP
accountability is: a stated, governed decision, not an assumption baked
silently into the catalogue. Revisit as real wave-one data comes in —
you may find the actual threshold in the estate differs from this
starting assumption.
