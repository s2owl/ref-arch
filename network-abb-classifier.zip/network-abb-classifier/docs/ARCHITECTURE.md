# Architecture — Current State and Scale-Up Path

## Current architecture (validated at ~70-site scale)

```
Compliance monitor (source of truth)
        |  export/scrape
        v
Local disk (data/sites/*.json — normalised, deterministic parsing)
        |
        v
Python script (src/classify.py)
  |- fetch fresh JWT (30s lifetime, per-call, never cached)
  |- build prompt (catalogue slice + config)
  |- call gateway -> Gemini 3.5 Flash
  |- write structured JSON (data/results/*.json)
        |
        v
Deterministic aggregation (code, no AI call):
  patterns.py / hardening.py / standards.py / vendor_pivot.py
        |
        v
Generated documentation:
  abb_documentation.py / resilience_statement.py / vendor_requirements_brief.py
```

Single host, single source of truth, sequential processing, local files
as the datastore. This is deliberately simple — every failure is
visible, every result is hand-checkable, and the cost of a full re-run
is negligible (~$0.50 for 70 sites). That simplicity is appropriate at
this scale and should not be over-engineered away prematurely.

**What does not change at any scale:** reasoning (the AI call) stays
per-host, bounded, single-purpose, and non-agentic. Scaling this is a
matter of running more of the same bounded call in parallel — it is a
capacity parameter, not a redesign. Deterministic aggregation logic
(patterns, hardening, standards, vendor pivot) also doesn't change
conceptually at scale — it needs a real datastore to query instead of a
folder of files, but the logic itself is unchanged.

---

## What breaks at 1M-host scale, and what replaces it

| Current approach | Breaks because | Replacement |
|---|---|---|
| Local JSON files in `data/results/` | Filesystem isn't queryable at scale; no safe concurrent writes | Real datastore (Postgres or similar) |
| Sequential loop, one call at a time | 1M calls sequentially ≈ weeks | Parallel worker pool, batched/async calls, rate-limited against the gateway |
| Fresh JWT fetched per call, single-threaded | Fine at low concurrency | Token cache with proactive refresh, shared across the worker pool — still never held longer than necessary |
| Full re-run every time | Cheap at 70 sites; not cheap or fast at 1M | **Incremental/delta processing** — see below, the highest-leverage change |
| One compliance-monitor source | A second source (Mist, Wave 1.75) is already anticipated | **Source-of-truth registry** — see below |
| One hand-edited catalogue file | Fine solo | Needs real change-control once multiple people propose pattern/rule changes — still PA-approved, but versioned properly |
| Hand-validate every result | Feasible at 15-70 sites | Statistical sampling — validate a random subset per run, same minimum-sample-size discipline already used for pattern derivation, applied to validation itself |

---

## Incremental processing (the highest-leverage change)

At 1M hosts, reprocessing everything on every run is both slow and
wasteful — most hosts don't change config day to day. The fix is a
content-hash-based delta:

1. **On ingestion**, compute a hash of each host's normalised config
   (not the raw config — the normalised JSON, so formatting-only
   differences from the source don't trigger false changes).
2. **Compare against the hash stored from the last successful
   classification run** for that host.
3. **Unchanged hash -> skip classification entirely.** Carry forward the
   previous result untouched (still timestamped as "last verified",
   which matters for the resilience/security statements — see below).
4. **Changed hash -> reclassify.** Only this subset goes through the AI
   call.

This means a steady-state run — most hosts unchanged since last time —
costs a small fraction of a full run, both in time and in API spend.
It's also what makes daily/weekly re-runs realistic at scale, which
matters for the "resilience statement" objective: a statement is only
credible as "repeatable, not a one-off review" if it's actually being
regenerated on a cadence, and that's only affordable with delta
processing.

**One nuance worth deciding explicitly**: if a host's config is
unchanged but the *catalogue* changes (a new pattern gets approved, a
rule's regulatory basis is updated), old results may need reclassifying
even though the config didn't change. The simplest correct rule: version
the catalogue itself, and any time the catalogue version changes,
invalidate all cached results — a full re-run, but still cheaper than
doing it on every single execution.

---

## Source-of-truth registry (multi-source correlation)

The WiFi/Mist overlay design (Wave 1.75) is really a specific instance
of a general problem: multiple sources evidencing different, sometimes
overlapping, parts of the same site. At scale this needs to generalise
rather than be handled as one-off correlation logic per source pair.

Each source should declare, explicitly:
- **What it can evidence** (e.g. compliance monitor: wired config only;
  Mist: wireless/SSID config only) — same principle as the WiFi
  VLAN-only scope boundary already enforced in Wave One, generalised to
  any source
- **A join key** to correlate against other sources (e.g. VLAN ID, site
  ID, hostname)
- **Authority when sources disagree** — if two sources both claim to
  evidence the same capability with conflicting answers, which wins by
  default, and when does that get escalated to a human rather than
  silently resolved

This is a rule set to define once, not per source pair — otherwise every
new source (SD-WAN orchestrator API, DDoS provider API, CMDB) requires
bespoke correlation logic instead of plugging into a common pattern.

---

## What doesn't need new design — just more of what exists

- Classification prompt/schema — unchanged, just run more of it in
  parallel
- Pattern-matching, hardening baseline, and rule-evaluation logic — all
  operate on structured output already; querying a real datastore
  instead of local files doesn't change the logic
- Documentation generation (ABB docs, resilience/security statements,
  vendor briefs) — same templating, just triggered per-host or
  per-band on a schedule instead of manually

## Summary — what to actually build, in order, when scale-up is real

1. Move `data/results/` from local JSON to a real datastore
2. Add config-hash-based incremental processing
3. Add a worker pool + queue for parallel classification calls
4. Formalise the source-of-truth registry (generalising the Mist design)
5. Version the catalogue and tie cache invalidation to catalogue version
   changes

None of this needs to happen before the 70-site milestone — it's the
deliberate next phase once real data proves the mechanism, not a
prerequisite for it.
