# Build Guide — branch-mid-mpls-sdwan
_Criteria: 50-200 users, dual-homed MPLS + SD-WAN_

If you are building a new site matching this description, use exactly what's below. This is the governed standard — no design decisions needed on your part.

**Governed pattern:** `PTN-BR-MID-MPLS-CISCO-v1`
_Standard mid-branch build — MPLS primary transport, ACL-based boundaries, Cisco wired/wireless stack_

## WAN
- **Deploy:** MPLS (provider: BT-MPLS)
- **Config template:** `CBB-CISCO-RTG-014-v1`
- **Boundary control:** ACL-based (provider: Cisco)
- **Config template:** `CBB-CISCO-WANACL-004-v1`

## User
- **Deploy:** Wired LAN (provider: Cisco)
- **Config template:** `CBB-CISCO-LAN-001-v1`
- **Boundary control:** ACL-based (provider: Cisco)
- **Config template:** `CBB-CISCO-SEG-008-v1`

## WiFi
- **Deploy:** VLAN-Identified (provider: Cisco)
- **Config template:** `CBB-CISCO-WIFI-VLAN-001-v1`
- **Boundary control:** VLAN-ACL-isolation (provider: Cisco)
- **Config template:** `CBB-CISCO-WIFIZBB-006-v1`

_This build guide is generated directly from the governed pattern and band-applicability catalogue — if you build to this exactly, you will pass every consistency and rule check in Wave One by construction, not by coincidence._
