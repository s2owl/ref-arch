# Resilience Statement — BR-EXAMPLE-01
**Site type:** Branch (branch-mid-mpls-sdwan)

**WAN resilience:** standby 10/20/30 groups with priority 110 and preempt (confidence: high)

**Design consistency:** Fully matches the governed pattern `PTN-BR-MID-MPLS-CISCO-v1` — built to the estate standard, not a bespoke one-off design.

**Wherever WAN applies and the band has more than a single device, Resilience must be evidenced** — ✅ Confirmed
  _Regulatory basis: DORA Art. 8 — ICT third-party/connectivity resilience_
**Wherever WAN applies, perimeter/firewall protection must be evidenced at the WAN edge** — ✅ Confirmed
  _Regulatory basis: PCI-DSS v4.0 — network boundary protection_

_Last verified: 2026-07-20 — derived from a repeatable classification run against live config, not a one-off design review._
