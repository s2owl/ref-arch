# Build Guide — branch-small-cellular
_Criteria: <10 users, cellular-only backhaul, no terrestrial option_

If you are building a new site matching this description, use exactly what's below. This is the governed standard — no design decisions needed on your part.

**No governed pattern exists yet for this band.** Do not improvise a design — escalate to architecture to get a pattern approved before building. (This is expected for newer or lower-volume bands — see docs/ROADMAP.md, patterns are derived from real data, not assumed upfront.)
