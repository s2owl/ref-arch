# User — Architecture Building Block

This ABB delivers **wired lan access meeting the primary capability's user-connectivity requirement** to the Branch, Campus capability.

It is made up of **Wired LAN** SBB.

The VSBBs (approved providers) in this space are: **Cisco**.

The zones (ZBB — boundary control) look like this: **ACL-based, Zonal-firewall**.

_Note: the lists above are the possibility space — any approved SBB may in principle pair with any approved ZBB. The patterns below are the actual governed combinations — which SBB **and** which ZBB together constitute an approved build for a given band. Only a listed pattern is buildable; do not assume any SBB/ZBB combination not shown below is approved._

**Patterns defined for this ABB:**
- `PTN-BR-MID-MPLS-CISCO-v1` (band: `branch-mid-mpls-sdwan`): **Wired LAN** SBB **AND** **ACL-based** ZBB — _Standard mid-branch build — MPLS primary transport, ACL-based boundaries, Cisco wired/wireless stack_

**Resilience is delivered by:** no rule defined yet for this ABB.

**Security has these considerations:**
- Wherever the User ABB applies, Authentication must be evidenced — Delivered as a centrally managed AAA service — 802.1X + RADIUS/ISE, CBB-CISCO-AUTH-003-v1 _(regulatory basis: DORA Art. 8 / PRA SS2/21 — identity assurance for network access)_
- Wherever the User ABB applies, Network Access Control must be evidenced — Delivered via the same centrally managed AAA service as Authentication — RADIUS/ISE posture check before network admission _(regulatory basis: DORA Art. 8 / PRA SS2/21)_

**Reference diagram:**

```mermaid
graph TD
  ABB["User (ABB)"]
  ABB --> SBB_Wired_LAN["Wired LAN (SBB)"]
  SBB_Wired_LAN --> SBB_Wired_LAN_Cisco["Cisco (VSBB)"]
  SBB_Wired_LAN_Cisco --> CBB_CISCO_LAN_001_v1["CBB-CISCO-LAN-001-v1 (CBB)"]
  ABB --> ZBB_ACL_based["ACL-based (ZBB)"]
  ZBB_ACL_based --> ZBB_ACL_based_Cisco["Cisco (VSBB)"]
  ZBB_ACL_based_Cisco --> CBB_CISCO_SEG_008_v1["CBB-CISCO-SEG-008-v1 (CBB)"]
  ABB --> ZBB_Zonal_firewall["Zonal-firewall (ZBB)"]
  ZBB_Zonal_firewall --> ZBB_Zonal_firewall_Cisco["Cisco (VSBB)"]
  ZBB_Zonal_firewall_Cisco --> CBB_CISCO_SEG_011_v1["CBB-CISCO-SEG-011-v1 (CBB)"]
```
