# Governed Architecture Submission — Campus
_Prepared 2026-07-21 — for stakeholder review and sign-off. No engineering config detail included; that layer is engineering-owned (CBB) and available on request._

## What is being submitted
The **Campus** primary capability is delivered by the coordinated interoperation of 3 architecture building blocks: **WAN, User, WiFi**. Each is independently governed, with its own approved solution (SBB), boundary control (ZBB), and approved provider (VSBB) — shown below at the architecture level only.

## How these ABBs interoperate
No single ABB delivers Campus alone — each covers a distinct connectivity concern, and together they form the complete, governed stack:
- **WAN** — external transport connectivity — the boundary between this site and the wider network
- **User** — internal wired access for users and devices at the site
- **WiFi** — internal wireless access, layered on top of the wired boundary already governed by User

## Approval status

| ABB | Architecture owner | Approved pattern(s) | Status |
|---|---|---|---|
| WAN | Principal Architect (VSBB: BT-MPLS, Starlink, Vodafone) | none | ⚠️ Pending — do not build against this ABB yet |
| User | Principal Architect (VSBB: Cisco) | none | ⚠️ Pending — do not build against this ABB yet |
| WiFi | Principal Architect (VSBB: Cisco) | none | ⚠️ Pending — do not build against this ABB yet |

## Reference diagram (architecture level — no config detail)

```mermaid
graph TD
PC["Campus"]
PC --> ABB_WAN["WAN (ABB)"]
ABB_WAN --> ABB_WAN_pending["No approved pattern yet"]
PC --> ABB_User["User (ABB)"]
ABB_User --> ABB_User_pending["No approved pattern yet"]
PC --> ABB_WiFi["WiFi (ABB)"]
ABB_WiFi --> ABB_WiFi_pending["No approved pattern yet"]
```

_Engineering configuration templates (CBB) exist beneath each approved pattern above, owned and maintained by engineering per Outcome 9 — available on request, not included in this submission._

**Once submitted, this becomes the governed baseline** — any future site delivering Campus is expected to match one of the approved patterns above; divergence is tracked and reported through the standard consistency mechanism.
