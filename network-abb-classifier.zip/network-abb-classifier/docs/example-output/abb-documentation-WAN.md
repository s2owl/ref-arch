# WAN — Architecture Building Block

This ABB delivers **transport connectivity meeting the primary capability's connectivity requirement** to the Branch, Campus capability.

It is made up of **MPLS, Cellular, Satellite, ISP, DWDM** SBBs.

The VSBBs (approved providers) in this space are: **BT-MPLS, Starlink, Vodafone**.

The zones (ZBB — boundary control) look like this: **ACL-based, Zonal-firewall, DDoS-scrubbing**.

**Resilience is delivered by:**
- Delivered via dual-homed transport with HSRP/failover — CBB-CISCO-RTG-014-v1/v2 _(regulatory basis: DORA Art. 8 — ICT third-party/connectivity resilience)_

**Security has these considerations:**
- Wherever WAN applies, perimeter/firewall protection must be evidenced at the WAN edge — Delivered via managed ACL/ZBB at the WAN edge — see WAN ZBB catalogue _(regulatory basis: PCI-DSS v4.0 — network boundary protection)_

**Reference diagram:**

```mermaid
graph TD
  ABB["WAN (ABB)"]
  ABB --> SBB_MPLS["MPLS (SBB)"]
  SBB_MPLS --> SBB_MPLS_BT_MPLS["BT-MPLS (VSBB)"]
  SBB_MPLS_BT_MPLS --> CBB_CISCO_RTG_014_v1["CBB-CISCO-RTG-014-v1 (CBB)"]
  SBB_MPLS_BT_MPLS --> CBB_CISCO_RTG_014_v2["CBB-CISCO-RTG-014-v2 (CBB)"]
  ABB --> SBB_Cellular["Cellular (SBB)"]
  SBB_Cellular --> SBB_Cellular_Vodafone["Vodafone (VSBB)"]
  SBB_Cellular_Vodafone --> CBB_CISCO_CELL_003_v1["CBB-CISCO-CELL-003-v1 (CBB)"]
  ABB --> SBB_Satellite["Satellite (SBB)"]
  SBB_Satellite --> SBB_Satellite_Starlink["Starlink (VSBB)"]
  SBB_Satellite_Starlink --> CBB_CISCO_SAT_005_v1["CBB-CISCO-SAT-005-v1 (CBB)"]
  ABB --> SBB_ISP["ISP (SBB)"]
  ABB --> SBB_DWDM["DWDM (SBB)"]
  ABB --> ZBB_ACL_based["ACL-based (ZBB)"]
  ZBB_ACL_based --> ZBB_ACL_based_Cisco["Cisco (VSBB)"]
  ZBB_ACL_based_Cisco --> CBB_CISCO_WANACL_004_v1["CBB-CISCO-WANACL-004-v1 (CBB)"]
  ABB --> ZBB_Zonal_firewall["Zonal-firewall (ZBB)"]
  ABB --> ZBB_DDoS_scrubbing["DDoS-scrubbing (ZBB)"]
```
