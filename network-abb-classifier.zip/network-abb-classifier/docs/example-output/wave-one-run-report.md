# Wave One — Example Run Report

*Illustrative aggregate output across a curated multi-band sample. This is
what a real run's output would let you act on — not raw classification
data, but the decisions it points to. Fabricated numbers for illustration.*

**Sample:** 42 sites classified across 3 bands (branch-mid-mpls-sdwan: 14,
branch-small-cellular: 12, campus-mid-fibre: 16)

---

## 1. Consistency scorecard

| Band | ABB | Block | Consistency | Status |
|---|---|---|---|---|
| branch-mid-mpls-sdwan | WAN | SBB | 85.7% | ⚠️ investigate |
| branch-mid-mpls-sdwan | WAN | ZBB | 100% | ✅ |
| branch-mid-mpls-sdwan | User | SBB | 100% | ✅ |
| branch-mid-mpls-sdwan | User | ZBB | 78.6% | 🔴 divergence |
| branch-mid-mpls-sdwan | WiFi | SBB | 92.9% | ⚠️ investigate |
| branch-mid-mpls-sdwan | WiFi | ZBB | 100% | ✅ |
| branch-small-cellular | WAN | SBB | 100% | ✅ |
| branch-small-cellular | WAN | ZBB | 91.7% | ⚠️ investigate |
| branch-small-cellular | User | SBB | 100% | ✅ |
| campus-mid-fibre | WAN | SBB | 100% | ✅ |
| campus-mid-fibre | User | ZBB | 68.8% | 🔴 divergence |
| campus-mid-fibre | WiFi | SBB | 100% | ✅ |

**Read:** ZBB (boundary control) is where inconsistency concentrates —
every SBB row is ≥92%, every 🔴 is a ZBB row. That's a pattern in itself,
not just noise.

---

## 2. Divergence findings (ranked by estate exposure)

| # | Band | ABB/Block | Sites affected | Observed alternative | Band justification |
|---|---|---|---|---|---|
| 1 | campus-mid-fibre | User/ZBB | 5 of 16 (31%) | Zonal-firewall instead of ACL-based | None found |
| 2 | branch-mid-mpls-sdwan | User/ZBB | 3 of 14 (21%) | Zonal-firewall instead of ACL-based | None found |
| 3 | branch-small-cellular | WAN/ZBB | 1 of 12 (8%) | No ZBB evidenced at all | None found — flagged as gap, not variant |

**Read:** Finding #1 and #2 are the *same* divergence pattern (ACL vs
zonal-firewall for User) appearing independently in two unrelated bands —
that's stronger evidence of a real, estate-wide inconsistency than either
finding alone would be.

---

## 3. Gaps vs correctly-absent (band applicability check)

| Band | Missing but expected | Correctly not applicable |
|---|---|---|
| branch-mid-mpls-sdwan | WiFi (1 site: BR-0099) | — |
| branch-small-cellular | — | WiFi (12 sites — expected, band criteria) |
| campus-mid-fibre | — | — |

**Read:** Only one real gap in the whole sample (BR-0099). Everything
else that looks like "missing WiFi" is correctly explained by band —
this is the applicability matrix doing its job, not a blind spot.

---

## 4. Pattern-match summary

| Band | Full match | Partial match | No pattern defined |
|---|---|---|---|
| branch-mid-mpls-sdwan | 9 of 14 (64%) | 5 of 14 | — |
| branch-small-cellular | — | — | 12 of 12 (pattern not yet defined) |
| campus-mid-fibre | 11 of 16 (69%) | 5 of 16 | — |

**Read:** branch-small-cellular has no defined pattern yet — per the
iterative approach, that's expected at this stage, not a failure. Worth
defining once this band's own within-band consistency data (section 1)
stabilises.

---

## 5. Decisions this data supports

This is the point of the exercise — translating findings into choices
someone with the right authority needs to make:

1. **User/ZBB divergence (findings #1, #2) — architecture decision needed.**
   ACL-based vs Zonal-firewall is a recurring split across two bands, not
   an isolated site issue. Options: (a) formalise Zonal-firewall as an
   accepted second variant in the pattern catalogue if there's a valid
   reason it exists, or (b) treat ACL-based as canonical and open a
   remediation conversation for the 8 diverging sites. **This decision is
   architecture's to frame, not to make alone** — likely needs GCB3 input
   given operational impact of remediation either way.

2. **BR-0099 (missing WiFi, branch-mid-mpls-sdwan) — investigate, don't
   assume.** Single real gap in the sample. Before treating as a finding,
   confirm whether this is a genuine build gap or a legitimate exception
   (e.g. temporary, awaiting installation) not yet reflected in the
   catalogue.

3. **branch-small-cellular WAN/ZBB gap (finding #3) — check for a hardware-
   constrained pattern.** One site with no ZBB evidenced at all, on a
   band already known to be resource-constrained (single device,
   cellular). Worth checking whether this is the kind of hardware-limited
   case that becomes a *pattern version* (per the earlier NLB/firewall
   precedent) rather than a simple config fix.

4. **branch-mid-mpls-sdwan WAN/SBB at 85.7% — low priority.** Two sites
   on a newer CBB version (segment routing) rather than the older
   canonical one — likely a hardware-refresh artefact, not a governance
   concern. Confirm, then consider promoting the newer version to
   canonical if it's the intended direction of travel.

5. **Define the branch-small-cellular pattern next.** With 12 sites now
   classified and stable, this band has enough sample size (per the ≥4
   threshold) to move from "no pattern defined" to a formal pattern —
   good candidate for the next catalogue iteration.

---

## 6. Site type theme — WiFi installation across the estate

Bringing the band applicability matrix (`docs/BAND_APPLICABILITY.md`)
together with what an actual run observes:

| Band | Users | WAN expected | User expected | WiFi expected | WiFi observed |
|---|---|---|---|---|---|
| `branch-micro-atm-cellular` | single device | ✅ | ❌ | ❌ | 0% (0 of 9) — as expected |
| `branch-small-cellular` | <10 | ✅ | ✅ | ❌ | 0% (0 of 12) — as expected |
| `branch-remote-satellite` | <10 | ✅ | ✅ | ❌ | 0% (0 of 4) — as expected |
| `branch-mid-mpls-sdwan` | 50-200 | ✅ | ✅ | ✅ | 93% (13 of 14) — 1 real gap (BR-0099) |
| `branch-large-mpls-sdwan` | 200-500 | ✅ | ✅ | ✅ | 100% (9 of 9) |
| `campus-mid-fibre` | 1,000-5,000 | ✅ | ✅ | ✅ | 100% (16 of 16) |
| `campus-large-darkfibre` | 10,000+ | ✅ | ✅ | ✅ | 100% (3 of 3) |

**The theme:** WiFi installation tracks band size almost perfectly — it's
absent below ~10 users and universal above ~50, with a clean step at
exactly the threshold the applicability matrix predicts. That's the
signal the matrix was built to surface correctly: the three
`0%` rows are **not** flagged anywhere in the pipeline as gaps, because
they were never expected. The single `93%` row **is** flagged (BR-0099),
because it's the one band where absence genuinely breaks the pattern.

**Why this matters for the workshop:** this table is a strong opening
exhibit precisely because it validates the tool's judgement before
showing anything contentious — the audience can see the model correctly
distinguishing "this site type never has WiFi" from "this site is
missing WiFi it should have" before you show them a single divergence
finding. It builds trust in the mechanism ahead of the harder findings
in sections 2-3.



Findings #1/#2 together are the strongest single exhibit for the
workshop: the same divergence appearing independently in two bands is
harder to dismiss as noise than a single-band finding, and it's phrased
as a framework observation (a recurring pattern across the estate) 
rather than any one site or team being singled out — consistent with the
political guardrails already agreed for the demo.
