# Governed Architecture Submission — Branch
_Prepared 2026-07-21 — for stakeholder review and sign-off. No engineering config detail included; that layer is engineering-owned (CBB) and available on request._

## What is being submitted
The **Branch** primary capability is delivered by the coordinated interoperation of 3 architecture building blocks: **WAN, User, WiFi**. Each is independently governed, with its own approved solution (SBB), boundary control (ZBB), and approved provider (VSBB) — shown below at the architecture level only.

## How these ABBs interoperate
No single ABB delivers Branch alone — each covers a distinct connectivity concern, and together they form the complete, governed stack:
- **WAN** — external transport connectivity — the boundary between this site and the wider network
- **User** — internal wired access for users and devices at the site
- **WiFi** — internal wireless access, layered on top of the wired boundary already governed by User

## Approval status

| ABB | Architecture owner | Approved pattern(s) | Status |
|---|---|---|---|
| WAN | Principal Architect (VSBB: BT-MPLS, Starlink, Vodafone) | `PTN-BR-MID-MPLS-CISCO-v1` | ✅ Approved |
| User | Principal Architect (VSBB: Cisco) | `PTN-BR-MID-MPLS-CISCO-v1` | ✅ Approved |
| WiFi | Principal Architect (VSBB: Cisco) | `PTN-BR-MID-MPLS-CISCO-v1` | ✅ Approved |

## Reference diagram (architecture level — no config detail)

```mermaid
graph TD
PC["Branch"]
PC --> ABB_WAN["WAN (ABB)"]
ABB_WAN --> ABB_WAN_MPLS["SBB<br/>MPLS"]
ABB_WAN_MPLS --> ABB_WAN_MPLS_V["VSBB<br/>BT-MPLS"]
ABB_WAN --> ABB_WAN_ACL_based["ZBB<br/>ACL-based"]
ABB_WAN_ACL_based --> ABB_WAN_ACL_based_V["VSBB<br/>Cisco"]
PC --> ABB_User["User (ABB)"]
ABB_User --> ABB_User_Wired_LAN["SBB<br/>Wired LAN"]
ABB_User_Wired_LAN --> ABB_User_Wired_LAN_V["VSBB<br/>Cisco"]
ABB_User --> ABB_User_ACL_based["ZBB<br/>ACL-based"]
ABB_User_ACL_based --> ABB_User_ACL_based_V["VSBB<br/>Cisco"]
PC --> ABB_WiFi["WiFi (ABB)"]
ABB_WiFi --> ABB_WiFi_VLAN_Identified["SBB<br/>VLAN-Identified"]
ABB_WiFi_VLAN_Identified --> ABB_WiFi_VLAN_Identified_V["VSBB<br/>Cisco"]
ABB_WiFi --> ABB_WiFi_VLAN_ACL_isolation["ZBB<br/>VLAN-ACL-isolation"]
ABB_WiFi_VLAN_ACL_isolation --> ABB_WiFi_VLAN_ACL_isolation_V["VSBB<br/>Cisco"]
```

_Engineering configuration templates (CBB) exist beneath each approved pattern above, owned and maintained by engineering per Outcome 9 — available on request, not included in this submission._

**Once submitted, this becomes the governed baseline** — any future site delivering Branch is expected to match one of the approved patterns above; divergence is tracked and reported through the standard consistency mechanism.
