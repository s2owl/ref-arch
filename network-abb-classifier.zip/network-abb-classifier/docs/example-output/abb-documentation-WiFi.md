# WiFi — Architecture Building Block

This ABB delivers **wireless access meeting the primary capability's wireless-connectivity requirement** to the Branch, Campus capability.

It is made up of **VLAN-Identified** SBB.

The VSBBs (approved providers) in this space are: **Cisco**.

The zones (ZBB — boundary control) look like this: **VLAN-ACL-isolation, Zonal-firewall**.

_Note: the lists above are the possibility space — any approved SBB may in principle pair with any approved ZBB. The patterns below are the actual governed combinations — which SBB **and** which ZBB together constitute an approved build for a given band. Only a listed pattern is buildable; do not assume any SBB/ZBB combination not shown below is approved._

**Patterns defined for this ABB:**
- `PTN-BR-MID-MPLS-CISCO-v1` (band: `branch-mid-mpls-sdwan`): **VLAN-Identified** SBB **AND** **VLAN-ACL-isolation** ZBB — _Standard mid-branch build — MPLS primary transport, ACL-based boundaries, Cisco wired/wireless stack_

**Resilience is delivered by:** no rule defined yet for this ABB.

**Security has these considerations:** no rules defined yet for this ABB.

**Reference diagram:**

```mermaid
graph TD
  ABB["WiFi (ABB)"]
  ABB --> SBB_VLAN_Identified["VLAN-Identified (SBB)"]
  SBB_VLAN_Identified --> SBB_VLAN_Identified_Cisco["Cisco (VSBB)"]
  SBB_VLAN_Identified_Cisco --> CBB_CISCO_WIFI_VLAN_001_v1["CBB-CISCO-WIFI-VLAN-001-v1 (CBB)"]
  ABB --> ZBB_VLAN_ACL_isolation["VLAN-ACL-isolation (ZBB)"]
  ZBB_VLAN_ACL_isolation --> ZBB_VLAN_ACL_isolation_Cisco["Cisco (VSBB)"]
  ZBB_VLAN_ACL_isolation_Cisco --> CBB_CISCO_WIFIZBB_006_v1["CBB-CISCO-WIFIZBB-006-v1 (CBB)"]
  ABB --> ZBB_Zonal_firewall["Zonal-firewall (ZBB)"]
```
