# Vendor Requirements Brief — WAN
_Generated 2026-07-21 — current governed requirements only. This list is authoritative for this meeting; no requirement outside it should be assumed, and no requirement on it should be omitted._

These are our current mandatory requirements for any vendor solution in this space. Please respond against each row — this response will be checked against our requirements directly.

| # | Requirement | Regulatory basis | Vendor response (please complete) |
|---|---|---|---|
| 1 | Must support **Logging** — Every matched ABB must evidence Logging, regardless of which ABB it is | DORA Art. 8 / PRA SS2/21 — audit trail and log correlation | |
| 2 | Must support **Resilience** — Wherever WAN applies and the band has more than a single device, Resilience must be evidenced | DORA Art. 8 — ICT third-party/connectivity resilience | |
| 3 | Must support **Firewall / Perimeter Security** — Wherever WAN applies, perimeter/firewall protection must be evidenced at the WAN edge | PCI-DSS v4.0 — network boundary protection | |

_Reference: 3 mandatory requirement(s) currently governed for WAN. This brief is generated directly from the governed requirement catalogue, not recalled from memory, so it is complete and consistent across every vendor conversation._
