# Building Block Hierarchy

The canonical, simple reference for how a network site's architecture
decomposes — what each tier means, and how it inherits from the one
above it.

```
Primary Capability  (e.g. Branch, Campus)
        |
        v
       ABB          <- the WHAT: the major block
   (WAN / User LAN / WiFi)
        |
        +-------------------+
        v                   v
       SBB                 ZBB
  the SOLUTION         the ZONE BOUNDARY
  (WHAT delivers on     (segmentation boundaries
   the capability —      OBSERVED in the config —
   e.g. Routing, QoS,    ACL, VLAN, FW)
   MPLS, WiFi 6)
        |                   |
        v                   v
      VSBB                VSBB
  vendor-specific       vendor-specific
  protocol/method        boundary mechanism
  e.g. Cisco EIGRP,
  Juniper iBGP
        |                   |
        v                   v
       CBB                 CBB
  the CONFIG that      the CONFIG that
  achieves the         achieves the
  solution              boundary
```

## Tier definitions

| Tier | Question it answers | Definition |
|---|---|---|
| **ABB** | *What* architecture layer is this? | WAN, User LAN, or WiFi — the architecture layer. A site is typically met by more than one ABB at once. |
| **SBB** | *What* delivers the capability? | The Solution — the mechanism that delivers the capability. Examples: Routing, QoS, MPLS, WiFi 6. Two sites can deliver the same ABB via different SBBs (e.g. WAN via MPLS vs Cellular). |
| **ZBB** | Where are the segmentation boundaries? | The Zone Boundary — the segmentation boundaries actually **observed in the config**: ACL, VLAN, or firewall. Grounded in evidence, not assumed — independent of SBB, since the same SBB can pair with different ZBBs and vice versa. |
| **VSBB** | *How* is it done at a vendor level? | The vendor-specific protocol/method that realises the SBB — e.g. for a Routing SBB: Cisco EIGRP vs Juniper iBGP. Not a hardware model — a vendor's characteristic way of implementing the SBB. Sits beneath both SBB and ZBB, since each can be realised differently by different vendors. |
| **CBB** | What *config* achieves it? | The actual configuration that achieves the solution or the boundary. Engineering-owned; everything above CBB is architecture-owned. |

## Ownership boundary

Everything ABB → SBB/ZBB → VSBB is the **architecture** layer — owned
and approved by the Principal Architect. CBB is the **engineering**
layer — the config template derived from an approved VSBB, owned and
maintained by engineering. This split is what the governed submission
(`src/governed_submission.py`) reflects: it states approval down to
VSBB and stops there, deliberately excluding CBB config detail.

## Resilience is cross-cutting, not a single tier

Resilience isn't a tier of its own — it shows up as a **capability**
within SBB (e.g. dual-homed WAN, HSRP on User LAN) and is measured two
ways:

- **At the site level**: is Resilience evidenced within the relevant
  ABB's capabilities (`src/standards.py`, `src/resilience_statement.py`)
- **At the topology level**: does the site's actual device-to-device
  connectivity show redundancy, or a single point of failure
  (`src/topology_diagram.py` — see below)

Both views matter and can disagree: a site can *claim* Resilience as a
capability while its physical topology shows only one uplink per
device, or vice versa. Worth cross-checking both when either is in
question.

## The site topology view (ASCII)

Once devices are collated (`src/collate_site_configs.py`), the
building-block hierarchy above describes *what's approved*; the
topology diagram describes *what's actually connected*:

```bash
python -m src.topology_diagram <site_id>
```

Produces an ASCII connectivity diagram, tiered by device role
(Router → Core → Distribution → Access → Server), distinguishing:

- **Confirmed links** — extracted from interface `description` lines
  that explicitly reference another device (deterministic text
  matching, no AI call)
- **Assumed links** — no explicit reference found, so the role
  hierarchy is used as a default; always labelled as an assumption,
  never presented as fact
- **Resilience** — link count per device, with single-homed devices
  flagged as a potential single point of failure (caveated: this may
  be band-appropriate, not a real finding — cross-reference against
  `docs/BAND_APPLICABILITY.md`)

This is a best-effort view from config text alone — it does not
replace real topology data (LLDP/CDP neighbours, a CMDB, actual cabling
records) as an audit source of truth, but it's useful for a fast sanity
check of what a site's design actually looks like.

## How this maps to the rest of the pipeline

| This document's tier | Where it's classified | Where it's governed |
|---|---|---|
| ABB, SBB, ZBB, VSBB | `src/classify.py` output (`abb_matches`) | `data/catalogue/catalogue.json` — `sbb_catalogue`, `zbb_catalogue` |
| CBB | Referenced in classification output, not detailed | Engineering-owned config templates |
| Approved combination (pattern) | — | `pattern_catalogue` — the governed AND of SBB+ZBB per band |
| Topology (connectivity) | `src/topology_diagram.py` | Not governed — descriptive, not prescriptive |
| Resilience | Capability within SBB | `requirement_rules` (e.g. `RULE-WAN-RESILIENCE-004`) |
