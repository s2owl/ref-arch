# AI Use Case Governance Record — Network ABB Classification Pipeline

**Record type:** AI Use Case Governance Record (companion to DP register / deviation log)
**Accountable owner:** Principal Network Architect
**Status:** Active — Wave One in build/pilot
**Last reviewed:** 2026-07-21

---

## 1. Use case identification

| Field | Value |
|---|---|
| Use case name | Network ABB/SBB/ZBB/VSBB/CBB classification and governance pipeline |
| Accountable owner | Principal Network Architect (control function, independent of platform ownership) |
| Sponsor | Networks MD |
| Stakeholders | GCB3 platform leads / Network Directors |
| Governance framework reference | `ref-arch-v2`, TOGAF 10-aligned taxonomy |
| Regulatory frame | DORA Art. 8, PRA SS2/21, PCI-DSS v4.0 |

---

## 2. Scope statement

**In scope:**
- Classification of network device configuration against a governed ABB/SBB/ZBB/VSBB/CBB catalogue
- Deterministic aggregation: pattern matching, within-band consistency, hardening baseline detection, requirement-rule evaluation
- Deterministic generation of architecture documentation, resilience/security statements, vendor requirements briefs, and engineer-facing build guidance from already-classified, already-governed data

**Explicitly out of scope (would require a new governance record, not an extension of this one):**
- Any autonomous or self-directed AI behaviour — deciding what to investigate, what to query next, or when to stop
- Any write/action capability — updating the deviation log, modifying the catalogue, or altering live config
- Live telemetry augmentation (ops-owned, not architecture-owned)
- Inference of regulatory/standards intent not explicitly stated in the governed catalogue

**Governing statement:** *This use case is non-agentic. Every AI component is code-orchestrated, single-purpose, and — where retrieval is used — read-only. The model returns structured output for a fixed input; it does not decide what to act on next. Any future move to agentic or write-capable behaviour is a separate use case requiring independent governance review — it does not inherit approval from this record.*

---

## 3. Data sources and their stated boundaries

| Source | What it evidences | What it explicitly does NOT evidence |
|---|---|---|
| Compliance monitor scrape (router/switch config) | Wired-side config: routing, VLANs, ACLs, dot1x, QoS | WLC/AP-level wireless config (SSID, RF, wireless-specific policy) |
| *(Future, not yet integrated)* Juniper Mist | Wireless SSID config, WPA/auth mode, SSID-level isolation | Wired-side config |

Each source's boundary is enforced in the classification prompt itself
(e.g. the WiFi ABB is explicitly restricted to VLAN-identified evidence,
confidence capped at medium, no AP/WLC inference permitted) — this is a
stated design control, not an incidental limitation.

---

## 4. AI components

| Component | Model | Call pattern | Enforcement mechanism |
|---|---|---|---|
| Site classification | Gemini 3.5 Flash (via internal AM-token gateway) | One bounded call per site, code-orchestrated | OpenAI-style function/tool calling — schema enforced by the API (`tool_choice`), not just requested in prompt text |

All deterministic aggregation (pattern matching, hardening baselines,
rule evaluation, documentation generation, build guidance) runs as plain
code against already-classified structured output — no further AI calls.

---

## 5. Outputs produced (manifest)

| Output | Generator | Audience | Nature |
|---|---|---|---|
| Per-site classification | `src/classify.py` | Architecture | AI-generated, structured |
| Within-band consistency / divergence | `src/patterns.py` | Architecture | Deterministic |
| Hardening findings (absolute + contextual baseline) | `src/hardening.py` | Architecture | Deterministic |
| Requirement-rule compliance / measurable standards | `src/standards.py` | Architecture, audit evidence | Deterministic |
| Vendor pivot readiness | `src/vendor_pivot.py` | Architecture, procurement | Deterministic |
| Vendor requirements brief | `src/vendor_requirements_brief.py` | External vendors | Deterministic, governed-source |
| ABB architecture documentation (incl. governed patterns, AND-statement) | `src/abb_documentation.py` | Architecture, review group | Deterministic |
| Customer-facing resilience statement | `src/resilience_statement.py` | Customers/business stakeholders | Deterministic |
| Engineer-facing build guide | `src/build_guide.py` | Engineering | Deterministic, prescriptive |
| Interactive build tool | `webapp/build-guide.html` | Engineering | Deterministic, client-side only |

---

## 6. Governance controls applied

- **Band applicability guardrail** — an ABB correctly absent for a small
  band is never treated as a gap; only genuine deviations are flagged
- **Minimum sample size (≥4 sites)** before any "canonical pattern" is
  asserted — below threshold, output is exploratory, not a finding
- **No auto-approved patterns** — `pattern_catalogue` entries require PA
  review before being treated as governed; the pipeline can surface
  candidates, it cannot self-approve them
- **Vendor/provider approval sits with PA** — VSBB entries (including
  new vendors evaluated via pivot-readiness) require PA sign-off before
  being added to the catalogue
- **Findings framed as framework observations, not team/individual
  critique** — consistent with existing deviation-log handling
- **SBB vs ZBB independence maintained throughout** — resilience and
  security are never conflated with a single mechanism; both are
  measured and reported separately
- **Mechanism-vs-outcome discipline** — compliance is measured against
  stated capability outcomes, never against a specific implementation
  technique, so legitimate technical diversity is never penalised as
  non-compliance

---

## 7. Review and escalation triggers

This record should be revisited, and a fresh review triggered, if:
- Any component moves from read-only/single-purpose to agentic or
  write-capable
- A new data source is integrated (formal entry into the source-of-truth
  registry required — see `docs/ARCHITECTURE.md`)
- The AI model/vendor changes to one not already covered by existing
  data-residency and AI-procurement approval
- Scale moves beyond the current pilot (~70 sites) toward the
  full-estate/1M-host design in `docs/ARCHITECTURE.md`, which changes
  the operational profile materially

---

## 8. Sign-off

| Role | Name | Confirms |
|---|---|---|
| Accountable owner | Principal Network Architect | Use case scope, non-agentic boundary, governance controls as stated above |
| Sponsor | Networks MD | Business value, resourcing |
| Reviewed by | GCB3 / peer architects | Framework alignment, taxonomy consistency |

_This record is the artefact referenced if this use case is audited,
questioned in the workshop, or cited as precedent for a future AI use
case — keep it current as the pipeline evolves._
