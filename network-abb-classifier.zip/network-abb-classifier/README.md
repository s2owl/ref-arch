# Network ABB Classifier — Phase 1

Classifies network site configurations against a governed ABB/SBB/VSBB/CBB
architecture catalogue, using Gemini 3.5 Flash via an internal JWT-authenticated
gateway. Phase 1 scope: **classification only** — no deviation detection,
divergence clustering, or compliance judgement yet (see `docs/ROADMAP.md`).

## Setup

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env      # fill in your gateway details
```

Required environment variables (see `.env.example`):
- `GATEWAY_AUTH_URL` — your org's token endpoint
- `GATEWAY_CLIENT_ID` / `GATEWAY_CLIENT_SECRET` — service credentials
- `GATEWAY_URL` — the generation endpoint
- `GATEWAY_MODEL` — defaults to `gemini-3.5-flash`

**Note:** the gateway client (`src/gateway_client.py`) assumes a generic
request/response shape. Confirm the actual payload format with whoever
owns the gateway and adjust `call_gateway()` accordingly — this is very
unlikely to match your real gateway out of the box.

## Data you need to add

- `data/catalogue/catalogue.json` — your ABB/SBB/VSBB/CBB entries,
  each tagged with `band` and the capabilities it covers
- `data/sites/<site_id>.json` — normalised (already-parsed) config for
  each curated site, one file per site
- `src/prompts.py` — populate `FEW_SHOT_EXAMPLES` with 2-3 hand-validated
  examples before running the full batch (see `docs/PROMPT_ENGINEERING.md`)

## Running

```bash
python -m src.classify --site BR-0042   # single site, for testing
python -m src.classify                  # all curated sites in data/sites/
```

Output is written to `data/results/<site_id>.json`.

## Important: token lifetime

The gateway's JWT lives ~30 seconds. `src/auth.py` fetches a fresh token
immediately before every single call — never cache or reuse a token.
`src/gateway_client.py` retries once on a 401 in case a token expires
mid-flight.

## Docs

- `docs/PROMPT_ENGINEERING.md` — how "training" actually works here
  (prompt engineering, not fine-tuning), and the validation loop to run
  before trusting output
- `docs/ROADMAP.md` — what's explicitly out of scope for Phase 1 and
  where it fits in the wider build

## Cost

At Gemini 3.5 Flash pricing ($1.50/$9 per MTok), a full 70-site
classification run costs roughly $0.50. Iterate freely — cost is not
the constraint on this build.
