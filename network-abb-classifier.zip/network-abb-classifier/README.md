# Network ABB Classifier — Phase 1

Classifies network site configurations against a governed ABB/{SBB,ZBB}/VSBB/CBB
architecture catalogue, using Gemini 3.5 Flash via an internal JWT-authenticated
gateway. Phase 1 scope: **classification only** — no deviation detection,
divergence clustering, or compliance judgement yet (see `docs/ROADMAP.md`).

## End-to-end flow

1. **Install** — clone/unzip this repo, `pip install -r requirements.txt`
2. **Point config at the sandbox** — copy `.env.example` to `.env` and fill in
   your gateway's real `GATEWAY_BASE_URL`, `GATEWAY_USER_ID`, `GATEWAY_MODEL`, and credentials.
   Confirm the payload shape in `src/gateway_client.py` matches what your
   gateway actually expects — it's a placeholder until you do.
3. **Populate the catalogue** — replace `data/catalogue/catalogue.example.json`
   with your real ABB/{SBB,ZBB}/VSBB/CBB entries at `data/catalogue/catalogue.json`.
   This is what every config gets classified *against* — without it, nothing
   downstream means anything.
4. **Add few-shot examples** — hand-classify 2-3 sites yourself and drop them
   into `FEW_SHOT_EXAMPLES` in `src/prompts.py`. This is your single biggest
   accuracy lever (see `docs/PROMPT_ENGINEERING.md`).
5. **Save the in-scope site configs locally** — one normalised JSON file per
   site in `data/sites/` (see "Example configs" below for the expected shape
   and a worked Cisco router+switch pair).
6. **Run the script** — single site first to sanity-check, then the full
   curated batch:
   ```bash
   python -m src.classify --site BR-EXAMPLE-01
   python -m src.classify
   ```
7. **Hand-validate** — check `data/results/` against what you already know
   to be correct before trusting the output further, especially the
   `evidence` field on each capability match.

## Example configs

`examples/raw-configs/` contains an illustrative Cisco router + switch pair
(branch-style: LAN, ACL, WiFi trunk, voice VLAN, IP helpers, QoS, dot1x/NAC,
sub-interfaces, OSPF/BGP, HSRP, MPLS, SNMPv3) — **not real device config**,
for testing the pipeline's classification logic before pointing it at real
curated configs.

`examples/normalized-sites/BR-EXAMPLE-01.json` is the same pair already
normalised into the JSON shape this pipeline expects as input. To test with
it:
```bash
cp examples/normalized-sites/BR-EXAMPLE-01.json data/sites/
python -m src.classify --site BR-EXAMPLE-01
```

Note: this repo does not include the raw-config-to-JSON parsing step — that's
assumed to happen upstream (deterministic parsing, not an AI call, per the
earlier scoping decision to keep parsing separate from model reasoning). The
normalised example shows the target shape your parser should produce.

## Setup

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env      # fill in your gateway details
```

Required environment variables (see `.env.example`):
- `GATEWAY_BASE_URL` — SDK endpoint, retrieve from the AI Platform (e.g. `https://host/ai-gateway-uat-internal-proxy/v1`)
- `GATEWAY_USER_ID` — your Use Case ID (e.g. `UCXXXXXXX`)
- `GATEWAY_MODEL` — the model to use (e.g. `gemini-3.5-flash`)
- `GATEWAY_AUTH_URL` / `GATEWAY_CLIENT_ID` / `GATEWAY_CLIENT_SECRET` — only needed
  if using the client_credentials stub in `src/auth.py`; replace with your org's
  actual JWT / AM token / Entra ID issuance flow otherwise

**Note:** the gateway client (`src/gateway_client.py`) assumes a generic
request/response shape. Confirm the actual payload format with whoever
owns the gateway and adjust `call_gateway()` accordingly — this is very
unlikely to match your real gateway out of the box.

## Important: token lifetime

The gateway's JWT lives ~30 seconds. `src/auth.py` fetches a fresh token
immediately before every single call — never cache or reuse a token.
`src/gateway_client.py` retries once on a 401 in case a token expires
mid-flight.

## Docs

- `docs/PROMPT_ENGINEERING.md` — how "training" actually works here
  (prompt engineering, not fine-tuning), and the validation loop to run
  before trusting output
- `docs/ROADMAP.md` — what's explicitly out of scope for Phase 1 and
  where it fits in the wider build

## Cost

At Gemini 3.5 Flash pricing ($1.50/$9 per MTok), a full 70-site
classification run costs roughly $0.50. Iterate freely — cost is not
the constraint on this build.
