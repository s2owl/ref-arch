# Network ABB Classifier

Classifies network site configurations against a governed
ABB/{SBB,ZBB}/VSBB/CBB architecture catalogue, then generates the
governance, documentation, and engineering artefacts that follow from
it — consistency checking, rule compliance, resilience statements,
build guides, vendor briefs, stakeholder submissions, and executive
reporting at scale. Everything downstream of classification is
deterministic code, not another AI call — see `docs/ROADMAP.md` for
the full wave-by-wave scope.

**New here? Read `docs/BUILDING_BLOCK_HIERARCHY.md` first** — the
simple ABB/SBB/ZBB/VSBB/CBB model everything else in this repo is
built around.

---

## Which path am I on?

**One site, just testing** → jump to [Quick single-site test](#quick-single-site-test)

**One or a few real sites, I only have a GUI (no API)** → jump to
[GUI-only workflow](#gui-only-workflow-no-api-access)

**~200 sites, multiple devices per site, I hand-crank through a
playground** → jump to [At scale](#at-scale-e.g.-200-sites)

**I have API access** → jump to [Setup](#setup), then `python -m src.classify`

---

## Setup

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env      # fill in your gateway details
```

### Populate the catalogue before anything else

Every tool in this repo reads `data/catalogue/catalogue.json`. Start
from the illustrative example, then revise it with real data (see
"Author or revise the catalogue" below):

```bash
cp data/catalogue/catalogue.example.json data/catalogue/catalogue.json
```

**After any restructuring**, validate it:
```bash
python -m src.validate_catalogue
```
Checks every section against what each script actually expects, and
separately flags any new content you've added that nothing currently
reads — useful after recategorising or adding internal definitions, so
you know the difference between "still works" and "now inert."

**Important, applies to every tool in this repo**: none of them will
silently fall back to the fabricated example catalogue if your real
`catalogue.json` is missing — they fail loudly instead, telling you
exactly what to do. A governance artefact built on fake data by
accident is worse than an error message.

### Using this with an internal Nexus repository

If `pip install` needs to go through your org's Nexus proxy, copy
`pip.ini.example`, fill in your Nexus URL/credentials, and place it
where pip actually looks for it — **the location differs by OS, and
pip silently ignores a file in the wrong place rather than erroring**:

| Scope | Location |
|---|---|
| This venv only (recommended) | `venv/pip.ini` (Windows) or `venv/pip.conf` (macOS/Linux) |
| User-wide | `%APPDATA%\pip\pip.ini` (Windows) / `~/.config/pip/pip.conf` (Linux) / `~/Library/Application Support/pip/pip.conf` (macOS) |

If your Nexus host uses a corporate-signed cert, see `pip.ini.example`
for the `cert =` option and how to extract the right certificate chain.
**Never commit a filled-in `pip.ini`/`pip.conf`** — only the
`.example` file is tracked in git.

Required environment variables (see `.env.example`):
- `GATEWAY_URL` — the full, already-complete chat/completions endpoint (not built from parts)
- `GATEWAY_USER_ID` — your Use Case ID (e.g. `UCXXXXXXX`)
- `GATEWAY_MODEL` — the model to use
- `GATEWAY_MAX_TOKENS` — max response tokens per call (default: 2000)
- `GATEWAY_AUTH_METHOD` — `amtoken` (Internal Staff Account, default) or `jwt` (Service Account)

### Token workflow (important — this is manual)

Tokens come from the AM portal, valid ~30 minutes, no way to fetch one
automatically. Log in, copy the token, paste it (raw, nothing else)
into `data/token.txt`.

- `src/auth.py` reads `data/token.txt` fresh before every call, warns
  at ~25 minutes old, refuses past ~30 rather than let calls fail silently
- If a run outlasts one token, `src/classify.py` pauses and waits for a
  fresh one, then continues — it doesn't restart
- Already-classified sites are skipped on re-run by default (`--force`
  to redo them)

### Test connectivity before anything else

```bash
python -m src.test_connection
```

Isolates auth/network/config from classification logic entirely — no
schema, no tool calling, no catalogue. Run this first if anything's
failing; it tells you immediately whether the problem is plumbing or
your actual pipeline.

---

## Quick single-site test

```bash
cp examples/normalized-sites/BR-EXAMPLE-01.json data/sites/
python -m src.classify --site BR-EXAMPLE-01
python -m src.run_report
```

---

## Get config in — three ways

1. **Pre-normalised JSON** — `data/sites/<site_id>.json`, matching
   `examples/normalized-sites/BR-EXAMPLE-01.json`
2. **Raw device config, no conversion needed** — `data/sites/<site_id>.cfg`
   or `.txt`, paste it in as-is. The model parses it itself; see
   `examples/raw-configs/` for a worked example.
3. **Multiple devices per site** (router/core/distribution/access/server)
   — see "At scale" below; this is the normal case for real sites and
   needs collation before classification so the model sees the whole
   topology, not disconnected fragments.

Add 2-3 hand-validated examples to `FEW_SHOT_EXAMPLES` in
`src/prompts.py` before a real run — your single biggest accuracy
lever (see `docs/PROMPT_ENGINEERING.md`).

---

## GUI-only workflow (no API access)

```bash
python -m src.generate_gui_prompt <site_id>
```

Writes **two** files, since most GUIs have a short text-box limit
(commonly ~4000 chars) but support file attachments with much more
headroom:

- `gui-prompts/<site_id>-prompt.txt` — short (~500 chars), paste this
  into the GUI's text box
- `gui-prompts/<site_id>-attachment.txt` — everything else (catalogue,
  instructions, schema, config), upload this as a file

Pick a model, submit. Copy the response into
`gui-prompts/<site_id>-output.json`, then:

```bash
python -m src.validate_manual_result <site_id>
```

Validates against the same schema the API path would have enforced —
catching missing fields, wrong types, a model wrapping its answer in
prose or under a nested key despite being told not to, or ` ```json `
fences. On success, saved to `data/results/<site_id>.json` — the same
location the automated path uses, so every downstream tool works
identically either way.

---

## At scale (e.g. 200 sites)

The real workflow for a large, messy batch — devices dumped in no
particular structure, hand-cranking through a GUI one prompt at a time,
needing one report at the end that answers the critical questions
without hunting through 200 individual results.

```bash
# 1. Sort a messy dump folder into one folder per site, using the
#    device naming convention (country+site+type+number) and the
#    config's own hostname line (authoritative over the filename)
python -m src.organize_site_folders /path/to/your/dump

# 2. Group each site's devices into one topology-aware config —
#    without this, a router+core+access set becomes 3 disconnected
#    "sites" instead of 1 real one
python -m src.collate_site_configs

# 3. Generate every prompt + attachment pair at once
python -m src.generate_gui_prompt --all
#    ... hand-crank through the playground: paste -prompt.txt, upload
#    -attachment.txt, save each response as gui-prompts/<site_id>-output.json ...

# 4. Validate everything in one pass
python -m src.validate_manual_result --all

# 5. The big picture
python -m src.big_picture_report
```

Step 5 answers Monitoring, Alerting, Security, and Resilience directly
— consistency % and which sites diverge — with drill-down pointers to
every detailed report underneath. Re-running `collate_site_configs.py`
and `generate_gui_prompt.py --all` later is safe — already-collated
and already-classified sites are skipped automatically, so adding more
sites to the dump folder over time just picks up where you left off.

---

## Script taxonomy — execution order, reads, writes

Verified against the actual code, not assumed. 23 runnable scripts,
grouped by the order they need to run in. Within a group, order doesn't
matter; between groups, it does — each depends on the previous group's
output existing.

### Stage 1 — Get config in (optional steps depending on your situation)

| # | Script | Reads | Writes |
|---|---|---|---|
| 1a | `organize_site_folders.py <dump_folder>` | Any folder you point it at | `data/sites/<site_id>/` |
| 1b | `collate_site_configs.py` | `data/sites/*` (flat files or subfolders) | `data/sites/<site_id>.txt` |

Skip 1a if you're not using the bulk-dump workflow. Skip 1b if every
site is already a single device.

### Stage 2 — Classify (produces `data/results/<site_id>.json`)

| # | Script | Reads | Writes |
|---|---|---|---|
| 2a | `classify.py --site <id>` / (no flag = batch) | `data/sites/`, `data/catalogue/catalogue.json`, `data/token.txt` | `data/results/<site_id>.json` |
| 2b | `generate_gui_prompt.py <id>` / `--all` | `data/sites/`, `data/catalogue/catalogue.json` | `<id>-prompt.txt` (short, paste), `<id>-attachment.txt` (full, upload), `<id>-preview.md` |
| 2c | *(manual: paste into GUI, save response)* | — | `gui-prompts/<id>-output.json` |
| 2d | `validate_manual_result.py <id>` / `--all` | `gui-prompts/<id>-output.json` | `data/results/<id>.json` |

Use 2a **or** 2b→2c→2d, not both. Either produces the identical output shape.

### Stage 3 — Per-site analysis (needs Stage 2 complete for that site)

| # | Script | Reads | Writes |
|---|---|---|---|
| 3a | `patterns.py <id>` | `data/results/<id>.json`, catalogue | `output/pattern-match-<id>.json` |
| 3b | `standards.py <id>` | `data/results/<id>.json`, catalogue | `output/standards-<id>.txt` |
| 3c | `resilience_statement.py <id>` | `data/results/<id>.json`, catalogue | `output/resilience-statement-<id>.md` |
| 3d | `capability_contradiction.py <id>` | `data/results/<id>.json`, `data/sites/<id>` (raw config) | `output/contradictions-<id>.json` |
| 3e | `topology_diagram.py <id>` | `data/sites/<id>.txt` (must be collated) | `output/topology-<id>.txt` |

### Stage 4 — Aggregate analysis (needs multiple sites classified, ≥4 per band for real findings)

| # | Script | Reads | Writes |
|---|---|---|---|
| 4a | `hardening.py <band>` | `data/results/*.json` for that band | `output/hardening-<band>.json` |
| 4b | `capability_consistency.py` | `data/results/*.json`, all bands | `output/capability-consistency-<date>.md` |
| 4c | `run_report.py` | `data/results/*.json`, all bands | `output/run-report-<date>.md` |
| 4d | `big_picture_report.py` | Results of 4a-4c (recomputed internally) | `output/big-picture-<date>.md` |
| 4e | `derive_patterns.py` | `data/results/*.json`, all bands | `output/candidate-patterns.json` — **proposals only, never writes to catalogue.json** |

Run 4d (`big_picture_report`) first if you only have time for one — it's
the executive view with pointers into the rest.

### Stage 5 — Catalogue-only outputs (no site data needed, run anytime the catalogue exists)

| # | Script | Reads | Writes |
|---|---|---|---|
| 5a | `build_guide.py <band>` | catalogue | `output/build-guide-<band>.md` |
| 5b | `abb_documentation.py <ABB>` | catalogue | `output/abb-documentation-<ABB>.md` |
| 5c | `governed_submission.py <capability>` | catalogue | `output/governed-submission-<capability>.md` |
| 5d | `vendor_requirements_brief.py <ABB>` | catalogue | `output/vendor-requirements-brief-<ABB>.md` |
| 5e | `vendor_pivot.py <ABB> <vendor> "<caps>"` | catalogue | `output/vendor-pivot-<ABB>-<vendor>.json` |

### Catalogue authoring & validation (run whenever the catalogue changes)

| Script | Reads | Writes |
|---|---|---|
| `validate_catalogue.py` | `data/catalogue/catalogue.json` | console only, no file |
| `generate_catalogue_update_prompt.py` | — (static prompt) | `gui-prompts/catalogue-update-prompt.txt` |

### Diagnostics (run anytime, no dependencies)

| Script | Reads | Writes |
|---|---|---|
| `test_connection.py` | `data/token.txt`, `.env` config | console only, no file |
| `classify_external_proof.py <id>` | `data/sites/<id>`, catalogue | **console only** — prints the result, does not save to `data/results/` |

---

## What you get

Every command below is real and tested against actual data, not
aspirational. Each reads from a fixed location and writes to a fixed
location, so they chain together as you classify more sites.

### Classify (produces `data/results/<site_id>.json`)

| Command | What it does |
|---|---|
| `python -m src.organize_site_folders <dump_folder>` | Bulk-sorts a messy dump of device configs into `data/sites/<site_id>/`, content-first hostname parsing |
| `python -m src.collate_site_configs` | Groups multi-device sites into one topology-aware config; idempotent, safe to re-run |
| `python -m src.classify --site <id>` | Full automated classification (API path); drop `--site` to batch the curated set |
| `python -m src.generate_gui_prompt <id>` / `--all` | GUI-only: generate one or every pending prompt |
| `python -m src.validate_manual_result <id>` / `--all` | Validate GUI output before it enters the pipeline |

### Analyse what's classified (reads `data/results/`)

| Command | Scope | What it tells you |
|---|---|---|
| `python -m src.patterns <id>` | one site | Which governed pattern it matches, exactly which block diverges if partial |
| `python -m src.standards <id>` | one site | Compliance against every governed requirement rule |
| `python -m src.resilience_statement <id>` | one site | Customer-facing resilience narrative |
| `python -m src.capability_contradiction <id>` | one site | Does the config contradict a capability it claims (e.g. Segmentation claimed, ACL is `permit any any`) |
| `python -m src.topology_diagram <id>` | one site | ASCII connectivity diagram + resilience/single-point-of-failure summary (needs collation first) |
| `python -m src.hardening <band>` | one band | Absolute findings (always wrong) + contextual findings (wrong only if it diverges from the band's own baseline) |
| `python -m src.capability_consistency` | all bands | Capability-level consistency, VSBB/CBB version parity (do different vendor versions deliver the same capabilities?), unidentified capabilities (e.g. IPsec) |
| `python -m src.run_report` | all bands | Full consistency scorecard, gap analysis, pattern-match summary |
| `python -m src.big_picture_report` | everything | Executive summary — Monitoring/Alerting/Security/Resilience answered directly, drill-down pointers |
| `python -m src.derive_patterns` | all bands | Proposes candidate governed patterns from real classified data — **never writes to the catalogue directly**, pattern approval stays a PA decision |

### Generate documentation and engineering guidance (catalogue only — no site data needed)

| Command | Audience | What it produces |
|---|---|---|
| `python -m src.build_guide <band>` | Engineers | Prescriptive "deploy exactly this," zero taxonomy jargon |
| `python -m src.abb_documentation <ABB>` | Architecture | Full narrative + Mermaid diagram, governed pattern stated as an explicit AND |
| `python -m src.governed_submission <capability>` | GCB3 / MD (sign-off) | Cross-ABB, stops at VSBB, no config detail, explicit approval status |
| `python -m src.vendor_requirements_brief <ABB>` | Vendors | Handoff-ready requirements, generated from the governed catalogue |
| `python -m src.vendor_pivot <ABB> <vendor> "<caps>"` | Procurement | Gap check: does a candidate vendor meet every mandatory rule |
| `webapp/build-guide.html` | Anyone | Interactive: requirements in, governed build + live topology + deviation query out |

All generator commands also save a file to `output/` in addition to
printing, so results are shareable, not just terminal scrollback.

### Author or revise the catalogue

```bash
python -m src.generate_catalogue_update_prompt
```

Produces a prompt that ingests real site-type definitions + the
current catalogue, explicitly instructing the model not to preserve
fabricated example data (Vodafone/Starlink/etc) when revising it.

### Diagnostics

| Command | What it checks |
|---|---|
| `python -m src.test_connection` | Auth/network/config, isolated from classification logic |
| `python -m src.classify_external_proof <id>` | Proves the pipeline works via the public Gemini API, independent of your internal gateway |

---

## Docs

- `docs/BUILDING_BLOCK_HIERARCHY.md` — the ABB/SBB/ZBB/VSBB/CBB model, ownership boundary, how topology + resilience fit in
- `docs/PROMPT_ENGINEERING.md` — prompt engineering (not fine-tuning), the validation loop to run before trusting output
- `docs/ROADMAP.md` — full wave-by-wave scope, what's not built yet and why
- `docs/ARCHITECTURE.md` — pipeline design, scale-up path to full-estate volumes
- `docs/GOVERNANCE_RECORD.md` — the artefact a PA holds to govern this AI use case itself
- `docs/BAND_APPLICABILITY.md` — which ABBs are expected per band, so a small site's correct absence of WiFi is never mistaken for a gap

## Proving this works independent of the internal gateway

```bash
pip install google-genai --break-system-packages
export GEMINI_API_KEY=<your key from ai.google.dev>
python -m src.classify_external_proof BR-EXAMPLE-01
```

Runs the exact same prompt/schema against the public Gemini API. If
this succeeds and your internal gateway doesn't, that's a clean signal
the problem is gateway plumbing (auth/URL/network), not your pipeline design.

## Why AI, and what you'd lose without it

Worth being precise about this rather than assuming AI is needed for
everything — most of this pipeline (patterns, standards, hardening,
reports, documentation, build guides) is **deterministic code with zero
AI calls**. The only AI call in the whole system is the initial
classification step: turning raw config into the ABB/SBB/ZBB/VSBB/CBB
structure.

**This was tested directly, not assumed.** A deterministic, regex-based
classifier was built and run against real config, using the same
`config_indicators` already documented in `data/catalogue/capability_taxonomy.json`
(originally written as AI prompt hints, but they double as literal
string-match patterns). Result: **50 genuine capability findings**, zero
AI calls, sub-second, each with an exact matching config line as
evidence. So capability *presence* detection is provably not something
that requires AI.

**What it provably could NOT do**, confirmed by the same test:

- **Determine band.** Band depends on context that isn't a literal
  string in the config — user count, transport intent, why a design
  choice was made. There's no indicator to regex-match for "this is a
  50-200 user site."
- **Match to a specific governed CBB.** The catalogue's `sbb_catalogue`/
  `zbb_catalogue` entries currently have prose descriptions ("IOS: VLAN
  + port ACL, no zonal firewall"), not indicator patterns — there's
  nothing to deterministically match config against yet. This is
  buildable (the catalogue could be enriched with its own indicators,
  same idea as the capability taxonomy), but doesn't exist today.
- **Weigh ambiguous or novel config.** A regex either matches or it
  doesn't — it can't judge whether an unfamiliar syntax pattern serves
  the same function as a known one, or reason about maturity bands (a
  concept the AI prompt explicitly handles: "PSK-only is lower maturity,
  not a failure").
- **Produce natural-language rationale.** `band_rationale`,
  well-reasoned `evidence` text, and the resilience/security narratives
  all depend on the kind of synthesis a regex match can't produce — it
  can point at a line, not explain why it matters in context.

**The practical consequence of skipping AI entirely**: you'd get a
capability inventory — useful as a fast pre-scan or a cross-check
against AI output — but not a governed classification. No band, no
pattern matching, no consistency scoring against approved SBB/ZBB
combinations, none of the governance layer this repo is actually built
around. The deterministic-only path answers "what's in this config";
the AI-assisted path answers "does this config satisfy the governed
architecture" — those are different questions, and only the second one
is what `data/results/*.json` and everything downstream of it depends on.

## Cost

At Gemini 3.5 Flash pricing ($1.50/$9 per MTok), a full 70-site
classification run costs roughly $0.50. Iterate freely — cost is not
the constraint on this build.
