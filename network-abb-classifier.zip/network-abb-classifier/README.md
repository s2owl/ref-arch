# Network ABB Classifier

Classifies network site configurations against a governed
ABB/{SBB,ZBB}/VSBB/CBB architecture catalogue, then generates the
governance, documentation, and engineering artefacts that follow from
it — consistency checking, rule compliance, resilience statements,
build guides, vendor briefs, and stakeholder submissions. Everything
downstream of classification is deterministic code, not another AI
call — see `docs/ROADMAP.md` for the full wave-by-wave scope.

## What you get

Every command below is real and tested. Each reads from a fixed
location and writes to a fixed location, so they chain together as you
classify more sites — nothing needs re-running by hand.

### 1. Classify a site (produces `data/results/<site_id>.json`)

| Situation | Command |
|---|---|
| You have API access | `python -m src.classify --site <id>` (drop `--site` to batch the whole curated set) |
| You only have a GUI (no API) | `python -m src.generate_gui_prompt <id>` → paste into GUI → `python -m src.validate_manual_result <id>` |

Both paths produce the identical output shape — everything below works
the same regardless of which one you used.

### 2. Analyse what's classified (reads `data/results/`)

| Command | Scope | What it tells you |
|---|---|---|
| `python -m src.patterns <id>` | one site | Which governed pattern it matches, and exactly which block diverges if only partial |
| `python -m src.standards <id>` | one site | Compliance against every governed requirement rule, with regulatory basis |
| `python -m src.resilience_statement <id>` | one site | Customer-facing resilience narrative, no taxonomy jargon |
| `python -m src.hardening <band>` | one band | Absolute findings (always wrong) + contextual findings (wrong only if it diverges from the band's own baseline) |
| `python -m src.run_report` | all bands | The full aggregate: consistency scorecard, divergence findings, gap analysis, pattern-match summary, rule compliance — across everything in `data/results/` |

### 3. Generate documentation and engineering guidance (reads the catalogue only — no site data needed)

| Command | Audience | What it produces |
|---|---|---|
| `python -m src.build_guide <band>` | Engineers | Prescriptive "deploy exactly this" guidance, zero taxonomy terms |
| `python -m src.abb_documentation <ABB>` | Architecture / review group | Full narrative + Mermaid diagram down to CBB, including the governed pattern stated as an explicit AND |
| `python -m src.governed_submission <capability>` | GCB3 / Networks MD (sign-off) | Capability-level, cross-ABB, stops at VSBB (no config detail), explicit approval status per ABB |
| `python -m src.vendor_requirements_brief <ABB>` | Vendors | Handoff-ready requirements list, generated from the governed catalogue, not recalled from memory |
| `python -m src.vendor_pivot <ABB> <vendor> "<cap1,cap2,...>"` | Procurement | Deterministic gap check: does a candidate vendor's declared capability meet every mandatory rule already governing this ABB |
| `webapp/build-guide.html` | Anyone | Interactive: state requirements, get the governed build + live topology diagram + deviation query, in a browser |

### 4. Author or revise the catalogue

| Command | What it does |
|---|---|
| `python -m src.generate_catalogue_update_prompt` | Produces a prompt that ingests real site-type definitions + the current catalogue, explicitly instructing the model not to preserve fabricated example data (Vodafone/Starlink/etc) when revising it |

### 5. Diagnostics

| Command | What it checks |
|---|---|
| `python -m src.test_connection` | Isolates auth/network/config from classification logic — run this first if anything's failing |
| `python -m src.classify_external_proof <id>` | Proves the pipeline works via the public Gemini API, independent of your internal gateway — useful for isolating whether a fault is your design or the gateway |

**Important, applies to every tool in sections 2–4:** none of them will
silently fall back to the fabricated example catalogue if your real
`data/catalogue/catalogue.json` is missing — they fail loudly instead,
telling you exactly what to do. This is deliberate: a governance
artefact built on fake data by accident is worse than an error message.

---

## Setup

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env      # fill in your gateway details
```

### Using this with an internal Nexus repository

If `pip install` needs to go through your org's Nexus proxy rather than
public PyPI directly, copy `pip.ini.example`, fill in your Nexus URL and
credentials, then place it where pip actually looks for it — **the
location differs by OS and setup, and pip silently ignores a file in
the wrong place rather than erroring**:

| Scope | Location |
|---|---|
| This venv only (recommended) | `venv/pip.ini` (Windows) or `venv/pip.conf` (macOS/Linux) |
| Your user account, all projects | `%APPDATA%\pip\pip.ini` (Windows) or `~/.config/pip/pip.conf` (Linux) or `~/Library/Application Support/pip/pip.conf` (macOS) |

```bash
cp pip.ini.example venv/pip.ini      # Windows, venv-scoped
# or
cp pip.ini.example venv/pip.conf     # macOS/Linux, venv-scoped
```

Then edit that copy with your real Nexus host and credentials. **Never
commit a filled-in `pip.ini`/`pip.conf`** — only `pip.ini.example` is
tracked in git; the real file is gitignored.

Required environment variables (see `.env.example`):
- `GATEWAY_URL` — the full, already-complete chat/completions endpoint from your
  AI Platform (not built from parts — copy it exactly as given)
- `GATEWAY_USER_ID` — your Use Case ID (e.g. `UCXXXXXXX`) — used in the request
  body's `user` field, not the URL
- `GATEWAY_MODEL` — the model to use (e.g. `gemini-3.5-flash`)
- `GATEWAY_MAX_TOKENS` — max response tokens per call (default: 2000)
- `GATEWAY_AUTH_METHOD` — `amtoken` (Internal Staff Account, default — matches
  the manual ~30-min token workflow) or `jwt` (Service Account, uses the
  `X-HSBC-E2E-Trust-Token` header instead, no `Token_Type` header)
- `GATEWAY_AUTH_URL` / `GATEWAY_CLIENT_ID` / `GATEWAY_CLIENT_SECRET` — only needed
  if using the client_credentials stub in `src/auth.py` for programmatic token
  issuance; not used for the manual AM-token flow

## Populate the catalogue before anything else

Every tool above reads `data/catalogue/catalogue.json`. Start from the
illustrative example, then revise it with real data (see the catalogue
authoring section above):

```bash
cp data/catalogue/catalogue.example.json data/catalogue/catalogue.json
```

## Get site config in — three ways

1. **Pre-normalised JSON** — `data/sites/<site_id>.json`, matching the
   shape in `examples/normalized-sites/BR-EXAMPLE-01.json`
2. **Raw device config, no conversion needed** — `data/sites/<site_id>.cfg`
   or `.txt`, just paste the raw config in. The model parses it itself;
   see `examples/raw-configs/` for a worked Cisco router+switch pair.
3. Either way, add 2-3 hand-validated examples to `FEW_SHOT_EXAMPLES` in
   `src/prompts.py` before a real run — your single biggest accuracy
   lever (see `docs/PROMPT_ENGINEERING.md`).

## Token workflow (important — this is manual)

Tokens come from the AM portal and are valid ~30 minutes. There's no way
for this script to fetch one automatically — you log in, copy the token,
and paste it (just the raw token, nothing else) into `data/token.txt`.

- `src/auth.py` reads `data/token.txt` fresh before every call, and warns
  once the token is ~25 minutes old, then refuses to use it past ~30
  minutes rather than let calls silently fail.
- If a run is long enough to outlast one token, `src/classify.py` pauses
  and waits for you to paste a fresh one into `data/token.txt`, then
  continues automatically — it doesn't restart from scratch.
- Already-classified sites are skipped on re-run by default (`--force`
  to redo them), so stopping and resuming across multiple tokens is safe.

## GUI-only workflow (no API access)

If you only have model access through a GUI (choose a model, upload
files, paste a prompt — no API key, no scripting), the pipeline still
works, just with manual steps in place of the automated API call:

```bash
python -m src.generate_gui_prompt BR-EXAMPLE-01
```

This writes a single, self-contained prompt to `gui-prompts/BR-EXAMPLE-01-prompt.txt`
— catalogue, config, instructions, and the schema spelled out explicitly
(since there's no function-calling to enforce it). Copy the whole file
into your GUI, pick a model, submit.

Copy the model's JSON response into `gui-prompts/BR-EXAMPLE-01-output.json`, then:

```bash
python -m src.validate_manual_result BR-EXAMPLE-01
```

This validates the response against the exact same schema the API path
would have enforced — catching missing fields, wrong types, or invalid
enum values before they ever reach the pipeline. It also strips a common
GUI artefact (the model wrapping its answer in ` ```json ` fences despite
being told not to). On success, it's saved to `data/results/BR-EXAMPLE-01.json`
— the same location the automated path would use, so every downstream
tool in the table above works identically regardless of how the
classification was actually produced.

Repeat per site. It's slower than the automated pipeline, but the
governance mechanism — schema validation, pattern matching, consistency
checking — is identical either way.

## Proving this works independent of the internal gateway

`src/classify_external_proof.py` runs the exact same prompt and schema
against the **public** Gemini API (ai.google.dev) instead of your
internal gateway — useful for isolating whether a problem is in your
classification design or in the internal gateway plumbing, and as a
standalone demo that doesn't depend on internal infrastructure at all.

```bash
pip install google-genai --break-system-packages
# Get a free key: https://ai.google.dev/gemini-api/docs/get-started
export GEMINI_API_KEY=<your key>
python -m src.classify_external_proof BR-EXAMPLE-01
```

If this succeeds and the internal gateway doesn't, that's a clean signal
the problem is on the internal-gateway side (auth, network, URL), not
your prompt/schema/pipeline logic.

## Docs

- `docs/PROMPT_ENGINEERING.md` — how "training" actually works here
  (prompt engineering, not fine-tuning), and the validation loop to run
  before trusting output
- `docs/ROADMAP.md` — full wave-by-wave scope, including what's not
  built yet and why
- `docs/ARCHITECTURE.md` — current pipeline design and the scale-up path
  to full-estate volumes
- `docs/GOVERNANCE_RECORD.md` — the artefact a Principal Architect holds
  to govern this AI use case itself
- `docs/BAND_APPLICABILITY.md` — which ABBs are expected per band, so a
  small site's correct absence of WiFi is never mistaken for a gap

## Cost

At Gemini 3.5 Flash pricing ($1.50/$9 per MTok), a full 70-site
classification run costs roughly $0.50. Iterate freely — cost is not
the constraint on this build.
