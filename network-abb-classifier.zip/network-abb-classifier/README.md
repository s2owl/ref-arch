# Network ABB Classifier — Phase 1

Classifies network site configurations against a governed ABB/{SBB,ZBB}/VSBB/CBB
architecture catalogue, using Gemini 3.5 Flash via an internal AM-token-authenticated
gateway. Phase 1 scope: **classification only** — no deviation detection,
divergence clustering, or compliance judgement yet (see `docs/ROADMAP.md`).

## End-to-end flow

1. **Install** — clone/unzip this repo, `pip install -r requirements.txt`
2. **Point config at the sandbox** — copy `.env.example` to `.env` and fill in
   `GATEWAY_URL`, `GATEWAY_USER_ID`, `GATEWAY_MODEL`. Confirm the payload
   shape in `src/gateway_client.py` matches what your gateway actually expects.
   **Get your token**: log into the AM portal, copy your token, and paste it
   (just the raw token, nothing else) into `data/.token` — see "Token workflow"
   below, this is manual and needs repeating roughly every 30 minutes.
3. **Populate the catalogue** — replace `data/catalogue/catalogue.example.json`
   with your real ABB/{SBB,ZBB}/VSBB/CBB entries at `data/catalogue/catalogue.json`.
   This is what every config gets classified *against* — without it, nothing
   downstream means anything.
4. **Add few-shot examples** — hand-classify 2-3 sites yourself and drop them
   into `FEW_SHOT_EXAMPLES` in `src/prompts.py`. This is your single biggest
   accuracy lever (see `docs/PROMPT_ENGINEERING.md`).
5. **Save the in-scope site configs locally** — one normalised JSON file per
   site in `data/sites/` (see "Example configs" below for the expected shape
   and a worked Cisco router+switch pair).
6. **Run the script** — single site first to sanity-check, then the full
   curated batch:
   ```bash
   python -m src.classify --site BR-EXAMPLE-01
   python -m src.classify
   ```
7. **Hand-validate** — check `data/results/` against what you already know
   to be correct before trusting the output further, especially the
   `evidence` field on each capability match.

## Example configs

`examples/raw-configs/` contains an illustrative Cisco router + switch pair
(branch-style: LAN, ACL, WiFi trunk, voice VLAN, IP helpers, QoS, dot1x/NAC,
sub-interfaces, OSPF/BGP, HSRP, MPLS, SNMPv3) — **not real device config**,
for testing the pipeline's classification logic before pointing it at real
curated configs.

`examples/normalized-sites/BR-EXAMPLE-01.json` is the same pair already
normalised into the JSON shape this pipeline expects as input. To test with
it:
```bash
cp examples/normalized-sites/BR-EXAMPLE-01.json data/sites/
python -m src.classify --site BR-EXAMPLE-01
```

Note: this repo does not include the raw-config-to-JSON parsing step — that's
assumed to happen upstream (deterministic parsing, not an AI call, per the
earlier scoping decision to keep parsing separate from model reasoning). The
normalised example shows the target shape your parser should produce.

## Setup

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env      # fill in your gateway details
```

### Using this with an internal Nexus repository

If `pip install` needs to go through your org's Nexus proxy rather than
public PyPI directly, copy `pip.ini.example`, fill in your Nexus URL and
credentials, then place it where pip actually looks for it — **the
location differs by OS and setup, and pip silently ignores a file in
the wrong place rather than erroring**:

| Scope | Location |
|---|---|
| This venv only (recommended) | `venv/pip.ini` (Windows) or `venv/pip.conf` (macOS/Linux) |
| Your user account, all projects | `%APPDATA%\pip\pip.ini` (Windows) or `~/.config/pip/pip.conf` (Linux) or `~/Library/Application Support/pip/pip.conf` (macOS) |

```bash
cp pip.ini.example venv/pip.ini      # Windows, venv-scoped
# or
cp pip.ini.example venv/pip.conf     # macOS/Linux, venv-scoped
```

Then edit that copy with your real Nexus host and credentials. **Never
commit a filled-in `pip.ini`/`pip.conf`** — only `pip.ini.example` is
tracked in git; the real file is gitignored.

Required environment variables (see `.env.example`):
- `GATEWAY_URL` — the full, already-complete chat/completions endpoint from your
  AI Platform (not built from parts — copy it exactly as given)
- `GATEWAY_USER_ID` — your Use Case ID (e.g. `UCXXXXXXX`) — used in the request
  body's `user` field, not the URL
- `GATEWAY_MODEL` — the model to use (e.g. `gemini-3.5-flash`)
- `GATEWAY_MAX_TOKENS` — max response tokens per call (default: 2000)
- `GATEWAY_AUTH_METHOD` — `amtoken` (Internal Staff Account, default — matches
  the manual ~30-min token workflow) or `jwt` (Service Account, uses the
  `X-HSBC-E2E-Trust-Token` header instead, no `Token_Type` header)
- `GATEWAY_AUTH_URL` / `GATEWAY_CLIENT_ID` / `GATEWAY_CLIENT_SECRET` — only needed
  if using the client_credentials stub in `src/auth.py` for programmatic token
  issuance; not used for the manual AM-token flow

**Note:** the gateway client (`src/gateway_client.py`) matches the org's
reference template (OpenAI-compatible `chat/completions`, function/tool
calling) — confirm it still matches if your gateway setup differs.

## Token workflow (important — this is manual)

Tokens come from the AM portal and are valid ~30 minutes. There's no way
for this script to fetch one automatically — you log in, copy the token,
and paste it (just the raw token, nothing else) into `data/.token`.

- `src/auth.py` reads `data/.token` fresh before every call, and warns
  once the token is ~25 minutes old, then refuses to use it past ~30
  minutes rather than let calls silently fail.
- If a run is long enough to outlast one token, `src/classify.py` pauses
  and waits for you to paste a fresh one into `data/.token`, then
  continues automatically — it doesn't restart from scratch.
- Already-classified sites are skipped on re-run by default (`--force`
  to redo them), so stopping and resuming across multiple tokens is safe.

## Docs

- `docs/PROMPT_ENGINEERING.md` — how "training" actually works here
  (prompt engineering, not fine-tuning), and the validation loop to run
  before trusting output
- `docs/ROADMAP.md` — what's explicitly out of scope for Phase 1 and
  where it fits in the wider build

## Cost

At Gemini 3.5 Flash pricing ($1.50/$9 per MTok), a full 70-site
classification run costs roughly $0.50. Iterate freely — cost is not
the constraint on this build.
