"""
Proves the classification pipeline works end-to-end using the PUBLIC
Gemini API (ai.google.dev) directly — completely independent of the
internal gateway. This isolates "does my prompt/schema/logic actually
work" from "is my internal gateway/auth/network set up correctly" —
useful when troubleshooting the internal path, and as a standalone demo
that doesn't depend on internal infrastructure at all.

This reuses the EXACT same build_prompt() and CLASSIFICATION_SCHEMA
already built and tested against the internal gateway — the only thing
that changes is which API is called. If this works and the internal
gateway doesn't, the problem is definitively on the internal-gateway
side, not your classification design.

Setup:
  1. Get a free API key from https://ai.google.dev/gemini-api/docs/get-started
     (click "Get API key" — this is Google AI Studio, separate from any
     work account or internal platform)
  2. pip install google-genai --break-system-packages
  3. export GEMINI_API_KEY=<your key>     (or set it in .env)
  4. python -m src.classify_external_proof

NOTE: could not be live-tested in this environment — the sandbox this
was built in only allows egress to a fixed domain allowlist, which does
not include generativelanguage.googleapis.com. The SDK calls below are
verified against the actual installed google-genai package signatures,
but you should run this yourself with a real key to confirm the live
call succeeds.
"""
import json
import os

from google import genai
from google.genai import types

from src.config_loader import load_site_config, load_catalogue_slice
from src.prompts import build_prompt
from src.schema import CLASSIFICATION_SCHEMA

MODEL = os.environ.get("GEMINI_PUBLIC_MODEL", "gemini-3.5-flash")


def classify_via_public_api(site_id: str) -> dict:
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY not set. Get a free key from "
            "https://ai.google.dev/gemini-api/docs/get-started and "
            "export it, or add it to .env"
        )

    client = genai.Client(api_key=api_key)

    config = load_site_config(site_id)
    catalogue_slice = load_catalogue_slice()
    prompt = build_prompt(config, catalogue_slice)

    response = client.models.generate_content(
        model=MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=CLASSIFICATION_SCHEMA,
        ),
    )

    return json.loads(response.text)


if __name__ == "__main__":
    import sys

    site_id = sys.argv[1] if len(sys.argv) > 1 else "BR-EXAMPLE-01"
    print(f"Classifying '{site_id}' via the PUBLIC Gemini API (not the internal gateway)...")
    try:
        result = classify_via_public_api(site_id)
        print()
        print("\u2705 SUCCESS — public API call worked, pipeline logic is proven independent")
        print("   of the internal gateway. Full result:")
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"\u274c Failed: {e}")
