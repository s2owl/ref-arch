"""
Validates data/catalogue/catalogue.json against what every script in
this repo actually expects to read — run this after any restructuring
to confirm nothing silently broke.

Two categories of finding, deliberately kept separate:
  - MISSING/malformed: something a script expects isn't there, or is
    the wrong shape. This WILL cause problems — errors or, worse,
    silent empty results.
  - UNUSED: extra top-level content you've added that no current
    script reads. Not a bug — but if this is where your new internal
    definitions/scopes live, nothing downstream benefits from them
    until a script is built or updated to consume them. Surfaced so
    you know the difference between "changed and still works" and
    "changed and now inert."

Usage:
    python -m src.validate_catalogue
"""
import json
from pathlib import Path

CATALOGUE_PATH = Path(__file__).parent.parent / "data" / "catalogue" / "catalogue.json"

EXPECTED_SECTIONS = {
    "primary_capabilities": {
        "type": dict,
        "used_by": ["governed_submission.py", "config_loader.py"],
        "check": lambda v: all("abbs" in pc for pc in v.values()),
        "check_desc": "each entry needs an 'abbs' list",
    },
    "abbs": {
        "type": dict,
        "used_by": ["abb_documentation.py", "governed_submission.py"],
        "check": lambda v: all("sbb_types" in a or "zbb_types" in a for a in v.values()),
        "check_desc": "each entry needs 'sbb_types' and/or 'zbb_types'",
    },
    "band_applicability_matrix": {
        "type": list,
        "used_by": ["patterns.py", "build_guide.py", "run_report.py"],
        "check": lambda v: all("band" in b and "applicable_abbs" in b for b in v),
        "check_desc": "each entry needs 'band' and 'applicable_abbs'",
    },
    "sbb_catalogue": {
        "type": list,
        "used_by": ["abb_documentation.py", "build_guide.py"],
        "check": lambda v: all("abb" in e and "sbb_type" in e and "provider" in e for e in v),
        "check_desc": "each entry needs 'abb', 'sbb_type', 'provider'",
    },
    "zbb_catalogue": {
        "type": list,
        "used_by": ["abb_documentation.py", "build_guide.py"],
        "check": lambda v: all("abb" in e and "zbb_type" in e and "provider" in e for e in v),
        "check_desc": "each entry needs 'abb', 'zbb_type', 'provider'",
    },
    "pattern_catalogue": {
        "type": list,
        "used_by": ["patterns.py", "build_guide.py", "governed_submission.py", "derive_patterns.py"],
        "check": lambda v: all("pattern_id" in p and "band" in p and "bundle" in p for p in v),
        "check_desc": "each entry needs 'pattern_id', 'band', 'bundle'",
    },
    "requirement_rules": {
        "type": list,
        "used_by": ["standards.py", "vendor_pivot.py", "vendor_requirements_brief.py", "big_picture_report.py"],
        "check": lambda v: all("rule_id" in r and "applies_to_abb" in r and "requires_capability" in r for r in v),
        "check_desc": "each entry needs 'rule_id', 'applies_to_abb', 'requires_capability'",
    },
    "hardening_checks": {
        "type": dict,
        "used_by": ["prompts.py (dynamic hardening instructions)"],
        "check": lambda v: "absolute" in v and "contextual" in v,
        "check_desc": "needs 'absolute' and 'contextual' lists",
    },
}


def validate():
    if not CATALOGUE_PATH.exists():
        print(f"\u274c No catalogue found at {CATALOGUE_PATH}.")
        print("   Copy catalogue.example.json to catalogue.json to get started.")
        return False

    try:
        catalogue = json.loads(CATALOGUE_PATH.read_text())
    except json.JSONDecodeError as e:
        print(f"\u274c catalogue.json is not valid JSON: {e}")
        return False

    print(f"Validating {CATALOGUE_PATH}\n")

    all_ok = True
    for section, spec in EXPECTED_SECTIONS.items():
        if section not in catalogue:
            print(f"\u274c MISSING: '{section}' — used by {', '.join(spec['used_by'])}")
            all_ok = False
            continue

        value = catalogue[section]
        if not isinstance(value, spec["type"]):
            print(f"\u274c WRONG TYPE: '{section}' should be a {spec['type'].__name__}, "
                  f"found {type(value).__name__} — used by {', '.join(spec['used_by'])}")
            all_ok = False
            continue

        try:
            if not spec["check"](value):
                print(f"\u26a0\ufe0f  STRUCTURE: '{section}' exists but some entries are missing "
                      f"required fields ({spec['check_desc']}) — used by {', '.join(spec['used_by'])}")
                all_ok = False
                continue
        except Exception as e:
            print(f"\u26a0\ufe0f  STRUCTURE: couldn't fully check '{section}': {e}")
            all_ok = False
            continue

        count = len(value)
        print(f"\u2705 {section}: {count} entrie(s), structure OK — used by {', '.join(spec['used_by'])}")

    unused_keys = set(catalogue.keys()) - set(EXPECTED_SECTIONS.keys()) - {"_note"}
    if unused_keys:
        print(f"\n\U0001F4CC Additional content found that NO current script reads yet:")
        for key in sorted(unused_keys):
            print(f"   - '{key}'")
        print("   This is where new internal definitions/scopes likely live if you've")
        print("   just added them — not a bug, but nothing downstream benefits from")
        print("   this content until a script is built or updated to consume it.")
        print("   Tell me what's in here and what you want it to drive, and I'll wire it in.")

    print()
    if all_ok:
        print("\u2705 All expected sections present and structurally sound.")
    else:
        print("\u26a0\ufe0f  One or more sections need attention — see above before relying on affected tools.")

    return all_ok


if __name__ == "__main__":
    import sys
    ok = validate()
    sys.exit(0 if ok else 1)
