"""
Vendor requirements brief.

Deterministic templating over requirement_rules (Wave 1.8) — produces a
document meant to be physically handed to a vendor in a meeting, not
internal architecture documentation. No ABB/SBB/CBB jargon, no internal
IDs beyond what's needed for traceability — just: here is what we
require, here is why, here is where you tell us how you meet it.

This exists specifically so requirements come from a governed, stated
source rather than being recalled from memory in the room — the failure
mode this was built to prevent is either an omission (forgetting a real
requirement) or scope creep (someone improvising requirements beyond
what's actually governed, "boiling the ocean").

The response column is deliberately left blank — once the vendor fills
it in, that response becomes the input to
src/vendor_pivot.check_vendor_pivot_readiness().
"""
import datetime
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def _load_catalogue() -> dict:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        path = DATA_DIR / "catalogue" / "catalogue.example.json"
    return json.loads(path.read_text())


def generate_vendor_requirements_brief(abb: str) -> str:
    catalogue = _load_catalogue()
    rules = [
        r for r in catalogue.get("requirement_rules", [])
        if r["applies_to_abb"] in (abb, "*") and r["mandatory"]
    ]

    lines = [
        f"# Vendor Requirements Brief — {abb}",
        f"_Generated {datetime.date.today().isoformat()} — current governed requirements only. "
        f"This list is authoritative for this meeting; no requirement outside it should be assumed, "
        f"and no requirement on it should be omitted._",
        "",
        "These are our current mandatory requirements for any vendor solution in "
        "this space. Please respond against each row — this response will be "
        "checked against our requirements directly.",
        "",
        "| # | Requirement | Regulatory basis | Vendor response (please complete) |",
        "|---|---|---|---|",
    ]

    for i, rule in enumerate(rules, 1):
        lines.append(
            f"| {i} | Must support **{rule['requires_capability']}** — {rule['description']} "
            f"| {rule['regulatory_basis']} | |"
        )

    lines.append("")
    lines.append(f"_Reference: {len(rules)} mandatory requirement(s) currently governed for {abb}. "
                  f"This brief is generated directly from the governed requirement catalogue, "
                  f"not recalled from memory, so it is complete and consistent across every vendor conversation._")

    return "\n".join(lines)
