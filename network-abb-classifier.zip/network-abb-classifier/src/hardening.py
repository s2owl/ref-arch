"""
Hardening findings aggregation.

Two different mechanisms, deliberately:

- ABSOLUTE findings (e.g. Telnet enabled) are already fully judged at
  classification time — nothing to aggregate, just collect and report.

- CONTEXTUAL findings (e.g. EIGRP redistribution without a filter) are
  NOT judged at classification time — the model only reports whether
  they're present. This module determines whether a contextual finding
  is actually a divergence by comparing against the band baseline —
  the SAME mechanism as SBB/ZBB pattern-matching (src/patterns.py), not
  a new one. If every same-band site has it, it's baseline behaviour;
  if only some do, that's the flag. Same minimum-sample-size discipline
  as everywhere else in this pipeline (>= 4 sites before asserting a
  baseline).
"""

MIN_SAMPLE_SIZE = 4


def collect_absolute_findings(classification_results: list) -> list:
    """Absolute findings need no aggregation — just collect across sites."""
    findings = []
    for result in classification_results:
        for obs in result.get("hardening_observations", []):
            if obs["type"] == "absolute" and obs["detected"]:
                findings.append({
                    "site_id": result["site_id"],
                    "finding": obs["finding"],
                    "severity": obs["severity"],
                    "evidence": obs["evidence"],
                })
    return findings


def compute_contextual_baseline(classification_results: list, band: str) -> dict:
    """
    For a given band, determine the baseline for each contextual finding
    and flag sites that diverge from it.
    """
    band_results = [r for r in classification_results if r.get("band") == band]

    if len(band_results) < MIN_SAMPLE_SIZE:
        return {
            "band": band,
            "sample_size_status": f"insufficient (< {MIN_SAMPLE_SIZE} threshold)",
            "note": "Too few sites in this band to establish a baseline — findings shown as observed only, not flagged.",
            "findings_by_name": {},
        }

    # Group by finding name
    by_finding = {}
    for result in band_results:
        for obs in result.get("hardening_observations", []):
            if obs["type"] != "contextual":
                continue
            name = obs["finding"]
            by_finding.setdefault(name, {"detected_sites": [], "not_detected_sites": []})
            if obs["detected"]:
                by_finding[name]["detected_sites"].append(result["site_id"])
            else:
                by_finding[name]["not_detected_sites"].append(result["site_id"])

    findings_summary = {}
    for name, data in by_finding.items():
        total = len(data["detected_sites"]) + len(data["not_detected_sites"])
        detected_pct = round(100 * len(data["detected_sites"]) / total, 1) if total else 0

        if detected_pct >= 60 or detected_pct <= 40:
            # Clear majority one way = baseline behaviour; the minority diverges
            baseline = "present" if detected_pct > 50 else "absent"
            diverging = data["not_detected_sites"] if baseline == "present" else data["detected_sites"]
            status = "baseline" if not diverging else "baseline_with_divergence"
        else:
            # Genuinely close to 50/50 — likely two legitimate sub-populations,
            # not a baseline with outliers. Needs architecture review, not an
            # automatic divergence flag.
            baseline = "mixed"
            diverging = []
            status = "no_clear_baseline"

        findings_summary[name] = {
            "baseline": baseline,
            "status": status,
            "detected_pct": detected_pct,
            "diverging_sites": diverging,
        }

    return {
        "band": band,
        "sample_size_status": f"sufficient (>= {MIN_SAMPLE_SIZE} threshold)",
        "findings_by_name": findings_summary,
    }
