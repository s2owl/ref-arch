"""
Builds a Mermaid connectivity diagram from a collated multi-device site
config (src/collate_site_configs.py output), with an acknowledgement of
observed ZBBs (zone boundaries) where classification has already run.

Two sources of connectivity, clearly distinguished in the diagram:
  - CONFIRMED: an interface `description` line in one device's config
    explicitly names another device in the same site (e.g.
    "description TRUNK-TO-BR-EXAMPLE-01-RTR"). Deterministic text
    matching, no AI call. Drawn as a solid edge.
  - ASSUMED: no explicit reference found, so the role hierarchy
    (Access -> Distribution -> Core -> Router) is used as a default.
    This is a guess, not a fact — drawn as a dashed edge, always
    labelled as such.

ZBB acknowledgement: if data/results/<site_id>.json already exists
(classification has run), the observed zone boundary per ABB is shown
as a note alongside the diagram — e.g. "User: ACL-based (observed in
config)". This does NOT attempt to attach ZBB to individual devices —
ZBB is an ABB-level finding, not necessarily 1:1 with a single device —
it's a legend, not a per-node label.

This does NOT replace real topology data (LLDP/CDP neighbours, a CMDB,
actual cabling records) — it's a best-effort view from what's visible
in config text alone, useful for a quick sanity check, not an audit
source of truth.
"""
import json
import re
from pathlib import Path

from src.mermaid_utils import safe_mermaid_id

SITES_DIR = Path(__file__).parent.parent / "data" / "sites"
RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"

DEVICE_SECTION = re.compile(
    r'=== DEVICE: (\S+) \| ROLE: (\w+).*?===\n(.*?)(?=\n=== DEVICE:|\Z)',
    re.DOTALL
)
DESCRIPTION_LINE = re.compile(r'description\s+(.+)', re.IGNORECASE)

ROLE_ORDER = ["Server", "Access", "Distribution", "Core", "Router"]  # bottom to top


def parse_collated_file(site_id: str) -> list:
    """Returns [{hostname, role, raw_config}, ...] from the collated file."""
    path = SITES_DIR / f"{site_id}.txt"
    if not path.exists():
        raise FileNotFoundError(f"No collated file at {path} — run collate_site_configs.py first.")
    text = path.read_text()
    devices = []
    for m in DEVICE_SECTION.finditer(text):
        hostname, role, raw_config = m.groups()
        devices.append({"hostname": hostname, "role": role, "raw_config": raw_config})
    return devices


def find_confirmed_links(devices: list) -> set:
    """
    Scans each device's description lines for another device's hostname
    (normalising dashes/underscores since we've already seen those vary).
    Returns a set of frozenset({device_a, device_b}) pairs.
    """
    hostnames = [d["hostname"] for d in devices]
    normalized = {h: re.sub(r'[-_]', '', h.upper()) for h in hostnames}

    links = set()
    for device in devices:
        for desc_match in DESCRIPTION_LINE.finditer(device["raw_config"]):
            desc_norm = re.sub(r'[-_]', '', desc_match.group(1).upper())
            for other_hostname, other_norm in normalized.items():
                if other_hostname == device["hostname"]:
                    continue
                if other_norm in desc_norm:
                    links.add(frozenset({device["hostname"], other_hostname}))
    return links


def find_assumed_links(devices: list, confirmed: set) -> set:
    """
    For any device with no confirmed link at all, assume a connection
    to the nearest device one tier up in the role hierarchy.
    """
    assumed = set()
    devices_with_confirmed = {h for pair in confirmed for h in pair}

    by_role = {}
    for d in devices:
        by_role.setdefault(d["role"], []).append(d["hostname"])

    for device in devices:
        if device["hostname"] in devices_with_confirmed:
            continue
        role_idx = ROLE_ORDER.index(device["role"]) if device["role"] in ROLE_ORDER else -1
        for higher_role in ROLE_ORDER[role_idx + 1:]:
            if higher_role in by_role:
                assumed.add(frozenset({device["hostname"], by_role[higher_role][0]}))
                break
    return assumed


def analyse_resilience(devices: list, confirmed: set, assumed: set) -> dict:
    """
    Counts links per device (confirmed + assumed together) and flags
    any device with only one link as a single point of failure. This
    is a link-count view, not a judgement on whether single-homing is
    ACCEPTABLE for that device's band/role — cross-reference against
    docs/BAND_APPLICABILITY.md before treating this as a finding.
    """
    link_count = {d["hostname"]: 0 for d in devices}
    all_links = confirmed | assumed
    for pair in all_links:
        for host in pair:
            if host in link_count:
                link_count[host] += 1

    single_homed = [h for h, count in link_count.items() if count <= 1]
    return {"link_count": link_count, "single_homed": single_homed}


def load_observed_zbb(site_id: str) -> dict:
    """
    Best-effort: if this site has already been classified, pull the
    observed ZBB per ABB from data/results/. Returns {} if not
    classified yet — this is an acknowledgement when available, not a
    requirement to run classification first.
    """
    result_path = RESULTS_DIR / f"{site_id}.json"
    if not result_path.exists():
        return {}
    try:
        result = json.loads(result_path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}

    zbb_by_abb = {}
    for m in result.get("abb_matches", []):
        zbb = m.get("zbb", {})
        if zbb.get("type"):
            zbb_by_abb[m["abb"]] = zbb["type"]
    return zbb_by_abb


def render_mermaid(site_id: str, devices: list, confirmed: set, assumed: set) -> str:
    resilience = analyse_resilience(devices, confirmed, assumed)
    observed_zbb = load_observed_zbb(site_id)

    node_ids = {d["hostname"]: safe_mermaid_id(d["hostname"]) for d in devices}
    role_of = {d["hostname"]: d["role"] for d in devices}

    lines = ["```mermaid", "graph TD"]

    # Nodes, grouped by role subgraph for a top-down tiered layout
    by_role = {}
    for d in devices:
        by_role.setdefault(d["role"], []).append(d["hostname"])

    for role in reversed(ROLE_ORDER):
        if role not in by_role:
            continue
        for hostname in by_role[role]:
            node_id = node_ids[hostname]
            count = resilience["link_count"].get(hostname, 0)
            label = f"{hostname}<br/>({role})"
            lines.append(f'  {node_id}["{label}"]')
            if count <= 1:
                lines.append(f"  style {node_id} fill:#e0575b")

    # Confirmed links — solid
    for pair in confirmed:
        a, b = sorted(pair)
        lines.append(f"  {node_ids[a]} --- {node_ids[b]}")

    # Assumed links — dashed, labelled
    for pair in assumed:
        a, b = sorted(pair)
        lines.append(f'  {node_ids[a]} -.->|assumed| {node_ids[b]}')

    lines.append("```")

    mermaid_block = "\n".join(lines)

    # Text sections alongside the diagram
    out = [f"# Connectivity diagram — {site_id}", "", mermaid_block, ""]

    out.append("Legend: solid = confirmed (from interface description), "
               "dashed = assumed (role hierarchy only, not confirmed). "
               "Red fill = single point of failure (may be band-appropriate — "
               "see docs/BAND_APPLICABILITY.md before treating as a finding).")

    out.append("")
    if observed_zbb:
        out.append("Zone boundaries observed (ZBB), from classification already run:")
        for abb, zbb_type in sorted(observed_zbb.items()):
            out.append(f"  - {abb}: {zbb_type}")
    else:
        out.append("Zone boundaries (ZBB) not shown — this site hasn't been classified "
                    "yet. Run classification first if you want ZBB acknowledged here.")

    if resilience["single_homed"]:
        out.append("")
        out.append("Single point of failure: " + ", ".join(resilience["single_homed"]))

    return "\n".join(out)


def generate_topology_diagram(site_id: str) -> str:
    devices = parse_collated_file(site_id)
    confirmed = find_confirmed_links(devices)
    assumed = find_assumed_links(devices, confirmed)
    return render_mermaid(site_id, devices, confirmed, assumed)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m src.topology_diagram <site_id>")
        print("(site_id must already be collated — run collate_site_configs.py first)")
        sys.exit(1)

    site_id = sys.argv[1]
    diagram = generate_topology_diagram(site_id)
    print(diagram)

    out_dir = Path(__file__).parent.parent / "output"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / f"topology-{site_id}.md"
    out_path.write_text(diagram)
    print(f"\nSaved to {out_path}")
