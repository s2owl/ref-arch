"""
Builds a simple ASCII connectivity diagram from a collated multi-device
site config (src/collate_site_configs.py output).

Two sources of connectivity, clearly distinguished in the output:
  - CONFIRMED: an interface `description` line in one device's config
    explicitly names another device in the same site (e.g.
    "description TRUNK-TO-BR-EXAMPLE-01-RTR"). Deterministic text
    matching, no AI call.
  - ASSUMED: no explicit reference found, so the role hierarchy
    (Access -> Distribution -> Core -> Router) is used as a default.
    This is a guess, not a fact — always labelled as such.

This does NOT replace real topology data (LLDP/CDP neighbours, a CMDB,
actual cabling records) — it's a best-effort view from what's visible
in config text alone, useful for a quick sanity check, not an audit
source of truth.
"""
import re
from pathlib import Path

SITES_DIR = Path(__file__).parent.parent / "data" / "sites"

DEVICE_SECTION = re.compile(
    r'=== DEVICE: (\S+) \| ROLE: (\w+).*?===\n(.*?)(?=\n=== DEVICE:|\Z)',
    re.DOTALL
)
DESCRIPTION_LINE = re.compile(r'description\s+(.+)', re.IGNORECASE)

ROLE_ORDER = ["Server", "Access", "Distribution", "Core", "Router"]  # bottom to top


def parse_collated_file(site_id: str) -> list:
    """Returns [{hostname, role, raw_config}, ...] from the collated file."""
    path = SITES_DIR / f"{site_id}.txt"
    if not path.exists():
        raise FileNotFoundError(f"No collated file at {path} — run collate_site_configs.py first.")
    text = path.read_text()
    devices = []
    for m in DEVICE_SECTION.finditer(text):
        hostname, role, raw_config = m.groups()
        devices.append({"hostname": hostname, "role": role, "raw_config": raw_config})
    return devices


def find_confirmed_links(devices: list) -> set:
    """
    Scans each device's description lines for another device's hostname
    (normalising dashes/underscores since we've already seen those vary).
    Returns a set of frozenset({device_a, device_b}) pairs.
    """
    hostnames = [d["hostname"] for d in devices]
    normalized = {h: re.sub(r'[-_]', '', h.upper()) for h in hostnames}

    links = set()
    for device in devices:
        for desc_match in DESCRIPTION_LINE.finditer(device["raw_config"]):
            desc_norm = re.sub(r'[-_]', '', desc_match.group(1).upper())
            for other_hostname, other_norm in normalized.items():
                if other_hostname == device["hostname"]:
                    continue
                if other_norm in desc_norm:
                    links.add(frozenset({device["hostname"], other_hostname}))
    return links


def find_assumed_links(devices: list, confirmed: set) -> set:
    """
    For any device with no confirmed link at all, assume a connection
    to the nearest device one tier up in the role hierarchy.
    """
    assumed = set()
    devices_with_confirmed = {h for pair in confirmed for h in pair}

    by_role = {}
    for d in devices:
        by_role.setdefault(d["role"], []).append(d["hostname"])

    for device in devices:
        if device["hostname"] in devices_with_confirmed:
            continue
        role_idx = ROLE_ORDER.index(device["role"]) if device["role"] in ROLE_ORDER else -1
        for higher_role in ROLE_ORDER[role_idx + 1:]:
            if higher_role in by_role:
                # Assume link to the first device in the nearest higher tier
                assumed.add(frozenset({device["hostname"], by_role[higher_role][0]}))
                break
    return assumed


def analyse_resilience(devices: list, confirmed: set, assumed: set) -> dict:
    """
    Counts links per device (confirmed + assumed together) and flags
    any device with only one link as a single point of failure. This
    is a link-count view, not a judgement on whether single-homing is
    ACCEPTABLE for that device's band/role — a Router with one uplink
    might be correct for a micro-ATM band (see docs/BAND_APPLICABILITY.md)
    and wrong for a mid-branch band. Cross-reference against the band
    before treating a single-homed flag as a finding.
    """
    link_count = {d["hostname"]: 0 for d in devices}
    all_links = confirmed | assumed
    for pair in all_links:
        for host in pair:
            if host in link_count:
                link_count[host] += 1

    single_homed = [h for h, count in link_count.items() if count <= 1]
    return {"link_count": link_count, "single_homed": single_homed}


def render_ascii(site_id: str, devices: list, confirmed: set, assumed: set) -> str:
    by_role = {}
    for d in devices:
        by_role.setdefault(d["role"], []).append(d["hostname"])

    lines = [f"Connectivity diagram — {site_id}", "=" * (24 + len(site_id)), ""]

    # Draw top-down: Router, Core, Distribution, Access
    for role in reversed(ROLE_ORDER):
        if role not in by_role:
            continue
        hosts = by_role[role]
        row = "  ".join(f"[{h}]" for h in hosts)
        lines.append(f"{role:14} {row}")
        if role != ROLE_ORDER[0]:
            lines.append(" " * 15 + "|" * len(hosts) if len(hosts) <= 1 else " " * 15 + "  |  " * len(hosts))

    lines.append("")
    lines.append("Confirmed links (from config interface descriptions):")
    if confirmed:
        for pair in confirmed:
            a, b = sorted(pair)
            lines.append(f"  {a} \u2500\u2500\u2500 {b}")
    else:
        lines.append("  (none found in config text)")

    lines.append("")
    lines.append("Assumed links (no explicit reference found — based on role hierarchy only):")
    if assumed:
        for pair in assumed:
            a, b = sorted(pair)
            lines.append(f"  {a} \u2504\u2504\u2504 {b}  [ASSUMED, not confirmed]")
    else:
        lines.append("  (none — every device has a confirmed link)")

    resilience = analyse_resilience(devices, confirmed, assumed)
    lines.append("")
    lines.append("Resilience (link count per device — confirmed + assumed):")
    for hostname, count in resilience["link_count"].items():
        flag = "  \u26a0\ufe0f SINGLE POINT OF FAILURE" if count <= 1 else ""
        lines.append(f"  {hostname}: {count} link(s){flag}")
    if resilience["single_homed"]:
        lines.append("")
        lines.append("  Note: single-homing may be correct for this band (e.g. a micro-ATM")
        lines.append("  site is expected to have one WAN link) — cross-reference against")
        lines.append("  docs/BAND_APPLICABILITY.md before treating this as a finding.")

    return "\n".join(lines)


def generate_topology_diagram(site_id: str) -> str:
    devices = parse_collated_file(site_id)
    confirmed = find_confirmed_links(devices)
    assumed = find_assumed_links(devices, confirmed)
    return render_ascii(site_id, devices, confirmed, assumed)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m src.topology_diagram <site_id>")
        print("(site_id must already be collated — run collate_site_configs.py first)")
        sys.exit(1)

    site_id = sys.argv[1]
    diagram = generate_topology_diagram(site_id)
    print(diagram)

    out_dir = Path(__file__).parent.parent / "output"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / f"topology-{site_id}.txt"
    out_path.write_text(diagram)
    print(f"\nSaved to {out_path}")
