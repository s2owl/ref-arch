"""
Vendor pivot readiness check.

The requirement_rules catalogue (Wave 1.8) is already vendor-agnostic —
"must have Authentication" never names Cisco. That means evaluating a
candidate vendor (e.g. a commodity alternative like Netgear) against an
ABB's existing rules is a simple, deterministic gap check: does this
vendor's declared capability coverage satisfy every mandatory rule
already governing this ABB? No AI call, no redesign — the spec already
exists, this just checks a new vendor against it.

This does NOT replace real classification of the vendor's actual config
once it exists (Wave One would still classify real Netgear config the
same way it classifies Cisco config) — this is a PRE-PROCUREMENT check:
"is this vendor even capable of meeting our stated requirements before
we invest in building it out."
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def _load_catalogue() -> dict:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        raise FileNotFoundError(
            f"No catalogue found at {path}. This tool will not silently fall "
            f"back to example/fabricated data — copy "
            f"data/catalogue/catalogue.example.json to catalogue.json to "
            f"explicitly start from illustrative data, or set up your real "
            f"governed catalogue first."
        )
    return json.loads(path.read_text())


def check_vendor_pivot_readiness(abb: str, candidate_vendor: str, declared_capabilities: set) -> dict:
    """
    declared_capabilities: the set of capabilities the candidate vendor
    can deliver for this ABB (from a vendor datasheet, PoC, or RFP
    response — not yet classified config, since none exists pre-adoption).
    """
    catalogue = _load_catalogue()
    rules = [
        r for r in catalogue.get("requirement_rules", [])
        if r["applies_to_abb"] in (abb, "*") and r["mandatory"]
    ]

    covered = []
    gaps = []
    for rule in rules:
        if rule["requires_capability"] in declared_capabilities:
            covered.append(rule["rule_id"])
        else:
            gaps.append({
                "rule_id": rule["rule_id"],
                "description": rule["description"],
                "missing_capability": rule["requires_capability"],
                "regulatory_basis": rule["regulatory_basis"],
            })

    total = len(rules)
    readiness_pct = round(100 * len(covered) / total, 1) if total else None

    return {
        "abb": abb,
        "candidate_vendor": candidate_vendor,
        "rules_checked": total,
        "rules_covered": len(covered),
        "readiness_pct": readiness_pct,
        "verdict": "ready" if not gaps else "gaps_found",
        "gaps": gaps,
        "note": (
            "This checks stated/declared vendor capability against existing "
            "requirement rules only — it does not replace classifying real "
            "config once the vendor is actually deployed, and says nothing "
            "about commercial, operational, or migration-cost factors, "
            "which remain a business decision, not an architecture one."
        ),
    }


if __name__ == "__main__":
    import sys
    import json
    if len(sys.argv) < 4:
        print("Usage: python -m src.vendor_pivot <ABB> <vendor_name> <capability1,capability2,...>")
        print('Example: python -m src.vendor_pivot WAN Netgear "Routing,Resilience"')
        sys.exit(1)
    abb, vendor, caps_str = sys.argv[1], sys.argv[2], sys.argv[3]
    declared = set(c.strip() for c in caps_str.split(","))
    result = check_vendor_pivot_readiness(abb, vendor, declared)
    print(json.dumps(result, indent=2))

    out_dir = Path(__file__).parent.parent / "output"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / f"vendor-pivot-{abb}-{vendor}.json"
    out_path.write_text(json.dumps(result, indent=2))
    print(f"\nSaved to {out_path}")
