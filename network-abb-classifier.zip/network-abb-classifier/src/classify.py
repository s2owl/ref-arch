"""
Phase 1: classify curated site configs against the ABB/SBB/VSBB/CBB
catalogue. Run this after populating data/sites/ and data/catalogue/,
and after adding at least 1-2 hand-validated few-shot examples in
prompts.py.

Usage:
    python -m src.classify                  # run all curated sites
    python -m src.classify --site BR-0042    # run a single site
"""
import argparse
import json
import time
from pathlib import Path

from src.config_loader import load_site_config, load_catalogue_slice, list_curated_sites
from src.prompts import build_prompt
from src.schema import CLASSIFICATION_FUNCTION
from src.gateway_client import call_with_function

RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"


def classify_site(site_id: str) -> dict:
    config = load_site_config(site_id)
    # First pass: no band filter, since band itself is part of what
    # we're asking the model to determine. Once bands are well-
    # established you may prefer to pre-filter here.
    catalogue_slice = load_catalogue_slice()
    prompt = build_prompt(config, catalogue_slice)

    # Function calling means the gateway/model enforces the schema —
    # this returns already-parsed arguments, not text to parse ourselves.
    result = call_with_function(prompt, CLASSIFICATION_FUNCTION)
    return result


def save_result(site_id: str, result: dict) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RESULTS_DIR / f"{site_id}.json"
    out_path.write_text(json.dumps(result, indent=2))
    print(f"  -> saved {out_path}")


def already_classified(site_id: str) -> bool:
    return (RESULTS_DIR / f"{site_id}.json").exists()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--site", help="Classify a single site_id instead of the full curated set")
    parser.add_argument("--pause", type=float, default=0.5, help="Seconds to pause between calls")
    parser.add_argument("--force", action="store_true", help="Reclassify sites that already have a saved result")
    args = parser.parse_args()

    sites = [args.site] if args.site else list_curated_sites()
    if not sites:
        print("No site configs found in data/sites/. Add some JSON files first.")
        return

    if not args.force:
        remaining = [s for s in sites if not already_classified(s)]
        skipped = len(sites) - len(remaining)
        if skipped:
            print(f"Skipping {skipped} already-classified site(s) (use --force to redo them).")
        sites = remaining

    if not sites:
        print("Nothing to do — all requested sites already have results. Use --force to reclassify.")
        return

    # Rough time estimate — AM tokens are valid ~30 min, so it's worth
    # knowing upfront whether this run is likely to outlast one token.
    est_seconds_per_call = 3  # rough model-latency assumption
    est_total = len(sites) * (args.pause + est_seconds_per_call)
    if est_total > 20 * 60:
        print(f"\u26a0\ufe0f  Estimated run time ~{int(est_total / 60)} min for {len(sites)} sites — "
              f"AM tokens last ~30 min, so you may need to refresh data/.token partway through. "
              f"Already-classified sites are skipped automatically on re-run, so it's safe to "
              f"stop and resume.")

    print(f"Classifying {len(sites)} site(s)...")
    for site_id in sites:
        print(f"[{site_id}] classifying...")
        while True:
            try:
                result = classify_site(site_id)
                save_result(site_id, result)
                break
            except Exception as e:
                msg = str(e)
                if "AM token" in msg or "data/.token" in msg:
                    print(f"  !! token issue: {msg}")
                    input("  Paste a fresh token into data/.token, then press Enter to retry this site "
                          "(or Ctrl+C to stop and resume later)...")
                    continue  # retry the same site with the refreshed token
                print(f"  !! failed: {msg}")
                break
        time.sleep(args.pause)

    print("Done. Hand-validate data/results/ against known-correct answers before trusting output.")


if __name__ == "__main__":
    main()
