"""
Phase 1: classify curated site configs against the ABB/SBB/VSBB/CBB
catalogue. Run this after populating data/sites/ and data/catalogue/,
and after adding at least 1-2 hand-validated few-shot examples in
prompts.py.

Usage:
    python -m src.classify                  # run all curated sites
    python -m src.classify --site BR-0042    # run a single site
"""
import argparse
import json
import time
from pathlib import Path

from src.config_loader import load_site_config, load_catalogue_slice, list_curated_sites
from src.prompts import build_prompt
from src.schema import CLASSIFICATION_SCHEMA
from src.gateway_client import call_gateway

RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"


def classify_site(site_id: str) -> dict:
    config = load_site_config(site_id)
    # First pass: no band filter, since band itself is part of what
    # we're asking the model to determine. Once bands are well-
    # established you may prefer to pre-filter here.
    catalogue_slice = load_catalogue_slice()
    prompt = build_prompt(config, catalogue_slice)

    raw = call_gateway(prompt, CLASSIFICATION_SCHEMA)
    # Adjust this extraction to match your gateway's actual response shape
    result = json.loads(raw["output"]) if isinstance(raw.get("output"), str) else raw.get("output", raw)
    return result


def save_result(site_id: str, result: dict) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RESULTS_DIR / f"{site_id}.json"
    out_path.write_text(json.dumps(result, indent=2))
    print(f"  -> saved {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--site", help="Classify a single site_id instead of the full curated set")
    parser.add_argument("--pause", type=float, default=0.5, help="Seconds to pause between calls")
    args = parser.parse_args()

    sites = [args.site] if args.site else list_curated_sites()
    if not sites:
        print("No site configs found in data/sites/. Add some JSON files first.")
        return

    print(f"Classifying {len(sites)} site(s)...")
    for site_id in sites:
        print(f"[{site_id}] classifying...")
        try:
            result = classify_site(site_id)
            save_result(site_id, result)
        except Exception as e:
            print(f"  !! failed: {e}")
        time.sleep(args.pause)

    print("Done. Hand-validate data/results/ against known-correct answers before trusting output.")


if __name__ == "__main__":
    main()
