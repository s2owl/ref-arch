"""
Capability-level consistency, VSBB/CBB version parity, and unidentified
capability surfacing.

Three checks, genuinely distinct from what run_report.py already does:

1. CAPABILITY-LEVEL consistency — re-slices the same classified data by
   CAPABILITY rather than by ABB+block-type. For each capability
   evidenced anywhere in a band, which CBB(s)/VSBB(s) deliver it, and
   is that consistent? This is the finer-grained view the ABB/block
   view alone doesn't give — a capability like "Segmentation" might be
   evidenced via more than one ZBB type within the same band.

2. VERSION PARITY — different VSBB/CBB versions of the SAME SBB type
   should still deliver the same SET of capabilities. If Cisco 3750
   (v1) delivers {Routing, Resilience, QoS} but Cisco 9300 (v2) only
   evidences {Routing, Resilience}, that's a capability gap introduced
   by the version difference — nothing else in this pipeline checks
   this specifically.

3. UNIDENTIFIED CAPABILITIES — aggregates unmatched_elements across all
   classified sites. If something like IPsec keeps showing up as
   unmatched, that's a signal the governed capability taxonomy needs
   extending, not that the config is wrong.

Deterministic, no AI call — reslicing and cross-referencing already-
classified structured output, same principle as everything else here.
"""
import json
import datetime
from pathlib import Path
from collections import defaultdict

RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"
OUTPUT_DIR = Path(__file__).parent.parent / "output"

# Capabilities relevant to a security/cyber review — used to produce
# the filtered ACL-specific section.
SECURITY_RELEVANT_CAPABILITIES = {
    "Segmentation", "Network Access Control", "Firewall / Perimeter Security",
    "IAM", "Authentication", "Port Security", "Control Plane Protection",
    "AAA (Device & Session)", "Crypto / Key Management",
}


def load_all_results() -> list:
    return [json.loads(p.read_text()) for p in RESULTS_DIR.glob("*.json")]


def compute_capability_consistency(band_results: list) -> dict:
    """
    For each (ABB, capability) evidenced anywhere in this band, which
    SBB+ZBB CBB combination delivers it, at what consistency, with
    which sites diverging.

    Keyed by (ABB, capability) — not capability alone — because
    capabilities are zone-scoped (Segmentation under User LAN is a
    different concern from Segmentation under WiFi, per
    capability_taxonomy.json's zone structure). Each occurrence is
    recorded ONCE per site using the full SBB+ZBB pairing as the
    delivery signature, not split into a separate sbb-attributed and
    zbb-attributed occurrence — a capability's evidence isn't reliably
    attributable to one block or the other from the schema alone, so
    guessing which one would be worse than reporting the pairing.
    """
    # (abb, capability) -> [(site_id, sbb_cbb, zbb_cbb, sbb_vsbb, zbb_vsbb), ...]
    occurrences = defaultdict(list)

    for result in band_results:
        for abb_match in result.get("abb_matches", []):
            abb = abb_match["abb"]
            sbb = abb_match.get("sbb", {})
            zbb = abb_match.get("zbb", {})
            signature = (sbb.get("cbb"), zbb.get("cbb"), sbb.get("vsbb"), zbb.get("vsbb"))
            for cap in abb_match.get("capabilities", []):
                occurrences[(abb, cap["capability"])].append((result["site_id"], *signature))

    report = {}
    for (abb, capability), entries in occurrences.items():
        total = len(entries)
        by_signature = defaultdict(list)
        for site_id, sbb_cbb, zbb_cbb, sbb_vsbb, zbb_vsbb in entries:
            by_signature[(sbb_cbb, zbb_cbb, sbb_vsbb, zbb_vsbb)].append(site_id)

        canonical_sig, canonical_sites = max(by_signature.items(), key=lambda kv: len(kv[1]))
        diverging = [
            {"sbb_cbb": sig[0], "zbb_cbb": sig[1], "sites": sites}
            for sig, sites in by_signature.items() if sig != canonical_sig
        ]

        report[(abb, capability)] = {
            "abb": abb,
            "capability": capability,
            "canonical_sbb_cbb": canonical_sig[0],
            "canonical_zbb_cbb": canonical_sig[1],
            "canonical_sbb_vsbb": canonical_sig[2],
            "canonical_zbb_vsbb": canonical_sig[3],
            "consistency_pct": round(100 * len(canonical_sites) / total, 1) if total else None,
            "sites_matching": len(canonical_sites),
            "total_sites": total,
            "diverging": diverging,
            "security_relevant": capability in SECURITY_RELEVANT_CAPABILITIES,
        }

    return report


def check_vsbb_version_parity(band_results: list) -> list:
    """
    For each (ABB, block_type, SBB/ZBB type), collect the capability set
    evidenced under each distinct CBB variant. If variants of the same
    type deliver different capability sets, that's a version-introduced
    gap — flag it.
    """
    variants = defaultdict(lambda: defaultdict(set))

    for result in band_results:
        for abb_match in result.get("abb_matches", []):
            abb = abb_match["abb"]
            caps_here = {c["capability"] for c in abb_match.get("capabilities", [])}
            for block_type in ("sbb", "zbb"):
                block = abb_match.get(block_type, {})
                block_key = (abb, block_type, block.get("type"))
                variants[block_key][block.get("cbb")] |= caps_here

    gaps = []
    for block_key, cbb_caps in variants.items():
        if len(cbb_caps) < 2:
            continue  # only one variant in use, nothing to compare
        all_caps = set().union(*cbb_caps.values())
        for cbb, caps in cbb_caps.items():
            missing = all_caps - caps
            if missing:
                gaps.append({
                    "abb": block_key[0],
                    "block": block_key[1],
                    "type": block_key[2],
                    "cbb": cbb,
                    "missing_capabilities": sorted(missing),
                    "note": f"Other CBB variant(s) of this same {block_key[2]} type evidence "
                            f"{', '.join(sorted(missing))}, but this one doesn't — version-introduced gap.",
                })

    return gaps


def surface_unidentified_capabilities(all_results: list) -> dict:
    """Aggregates unmatched_elements across every classified site."""
    occurrences = defaultdict(list)
    for result in all_results:
        for element in result.get("unmatched_elements", []):
            occurrences[element].append(result["site_id"])
    return dict(occurrences)


def generate_report() -> str:
    from src.run_report import group_by_band

    all_results = load_all_results()
    if not all_results:
        return "# Capability Consistency Report\n\nNo classified results found."

    grouped = group_by_band(all_results)
    today = datetime.date.today().isoformat()
    lines = [f"# Capability Consistency Report", f"\nGenerated {today} from {len(all_results)} classified site(s).\n"]

    for band, band_results in sorted(grouped.items()):
        lines.append(f"## Band: `{band}` ({len(band_results)} site(s))\n")

        cap_report = compute_capability_consistency(band_results)

        lines.append("### Capability-level consistency\n")
        lines.append("| ABB | Capability | Canonical SBB CBB | Canonical ZBB CBB | Consistency | Diverging |")
        lines.append("|---|---|---|---|---|---|")
        for (abb, cap), data in sorted(cap_report.items()):
            diverging_str = "; ".join(
                f"{d['sbb_cbb']}/{d['zbb_cbb']} ({', '.join(d['sites'])})" for d in data["diverging"]
            ) or "—"
            lines.append(
                f"| {abb} | {cap} | `{data['canonical_sbb_cbb']}` | `{data['canonical_zbb_cbb']}` | "
                f"{data['consistency_pct']}% ({data['sites_matching']}/{data['total_sites']}) | {diverging_str} |"
            )

        security_caps = {k: d for k, d in cap_report.items() if d["security_relevant"]}
        if security_caps:
            lines.append("\n### Security-relevant capabilities (for cyber review)\n")
            lines.append("| ABB | Capability | Consistency | Diverging sites |")
            lines.append("|---|---|---|---|")
            for (abb, cap), data in sorted(security_caps.items()):
                diverging_sites = sorted({s for d in data["diverging"] for s in d["sites"]})
                lines.append(f"| {abb} | {cap} | {data['consistency_pct']}% | {', '.join(diverging_sites) or '—'} |")

        parity_gaps = check_vsbb_version_parity(band_results)
        if parity_gaps:
            lines.append("\n### VSBB/CBB version parity gaps\n")
            lines.append("_Different versions of the same SBB/ZBB type should deliver the same capabilities._\n")
            for gap in parity_gaps:
                lines.append(f"- **{gap['abb']} / {gap['block'].upper()} / {gap['type']}** (`{gap['cbb']}`): "
                              f"missing {', '.join(gap['missing_capabilities'])} — {gap['note']}")

        lines.append("\n---\n")

    unidentified = surface_unidentified_capabilities(all_results)
    if unidentified:
        lines.append("## Unidentified capabilities (candidates for taxonomy review)\n")
        lines.append("_Config elements the model couldn't map to any governed capability —_")
        lines.append("_may indicate the taxonomy needs extending, not that the config is wrong._\n")
        for element, sites in sorted(unidentified.items(), key=lambda kv: -len(kv[1])):
            lines.append(f"- **{element}** — seen at: {', '.join(sites)}")

    return "\n".join(lines)


if __name__ == "__main__":
    report = generate_report()
    print(report)

    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / f"capability-consistency-{datetime.date.today().isoformat()}.md"
    out_path.write_text(report)
    print(f"\nSaved to {out_path}")
