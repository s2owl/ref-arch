"""
Organizes a folder of raw device configs — potentially hundreds, dumped
flat or in any subfolder structure — into data/sites/<site_id>/
subfolders, one per site. Uses the same content-first hostname parsing
as collate_site_configs.py (the config's own hostname line is
authoritative, filename is only a fallback).

This is the entry point for scale: point it at wherever you've dumped
200 sites' worth of device configs, and it sorts them into the
structure collate_site_configs.py already knows how to consume.

Usage:
    python -m src.organize_site_folders /path/to/dump/folder
"""
import shutil
import sys
from pathlib import Path
from collections import defaultdict

from src.hostname_parser import extract_hostname_from_config, parse_device_name

SITES_DIR = Path(__file__).parent.parent / "data" / "sites"


def organize(input_folder: str) -> dict:
    input_path = Path(input_folder)
    if not input_path.exists():
        raise FileNotFoundError(f"Input folder not found: {input_path}")

    files = [
        p for p in input_path.rglob("*")
        if p.is_file() and p.suffix.lower() in (".cfg", ".txt")
    ]

    organized = defaultdict(list)
    unmatched = []

    for f in files:
        try:
            raw = f.read_text(errors="ignore")
        except Exception:
            unmatched.append((f, "could not read file"))
            continue

        content_hostname = extract_hostname_from_config(raw)
        parsed = parse_device_name(content_hostname) if content_hostname else None

        if not parsed:
            parsed = parse_device_name(f.stem)

        if not parsed:
            unmatched.append((f, "neither content hostname nor filename matched the naming convention"))
            continue

        organized[parsed["site_id"]].append((f, parsed))

    for site_id, devices in organized.items():
        site_folder = SITES_DIR / site_id
        site_folder.mkdir(parents=True, exist_ok=True)
        for f, parsed in devices:
            dest = site_folder / f.name
            shutil.copy2(f, dest)

    return {"organized": dict(organized), "unmatched": unmatched}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m src.organize_site_folders /path/to/dump/folder")
        sys.exit(1)

    result = organize(sys.argv[1])

    print(f"Organized {sum(len(v) for v in result['organized'].values())} device file(s) "
          f"into {len(result['organized'])} site(s):\n")
    for site_id, devices in sorted(result["organized"].items()):
        roles = ", ".join(f"{p['role']}" for _, p in devices)
        print(f"  {site_id}: {len(devices)} device(s) ({roles})")

    if result["unmatched"]:
        print(f"\n\u26a0\ufe0f  {len(result['unmatched'])} file(s) could not be matched — left untouched:")
        for f, reason in result["unmatched"]:
            print(f"  - {f.name}: {reason}")

    print(f"\nNext: python -m src.collate_site_configs")
