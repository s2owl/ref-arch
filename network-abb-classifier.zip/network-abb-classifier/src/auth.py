"""
JWT token handling for the internal AI gateway.

IMPORTANT: tokens from this gateway live for ~30 seconds. This module
deliberately does NOT cache tokens — call get_jwt_token() immediately
before each request, never store the result for reuse.
"""
import os
import requests

# Fill these in from whatever your org's auth service actually requires.
# Common patterns: client_credentials OAuth2 flow, or an internal token
# endpoint that takes a service account key.
AUTH_URL = os.environ.get("GATEWAY_AUTH_URL", "https://your-org/auth/token")
CLIENT_ID = os.environ.get("GATEWAY_CLIENT_ID")
CLIENT_SECRET = os.environ.get("GATEWAY_CLIENT_SECRET")


def get_jwt_token() -> str:
    """
    Fetch a fresh JWT. Call this right before every API request —
    do not store the return value across calls or loop iterations.
    """
    if not CLIENT_ID or not CLIENT_SECRET:
        raise RuntimeError(
            "GATEWAY_CLIENT_ID / GATEWAY_CLIENT_SECRET not set. "
            "Set them as environment variables (see .env.example)."
        )

    response = requests.post(
        AUTH_URL,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        },
        timeout=10,
    )
    response.raise_for_status()
    return response.json()["access_token"]
