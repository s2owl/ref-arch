"""
Token handling for the internal AI gateway.

Matches the org's real template: the gateway accepts <jwt token>, <AM
token>, or <entra id> as a Bearer token. Whichever issuance mechanism
your org uses, this module's job is the same: hand back a FRESH token
immediately before every request — tokens live ~30 seconds, so never
cache or reuse one across calls.

Fill in _fetch_token_from_issuer() with however your org actually issues
tokens (client_credentials OAuth2, an internal token endpoint, an Entra ID
app registration, etc). This is deliberately left as a stub since the
issuance mechanism is org-specific and wasn't shown in the reference
template — only the consumption side (Bearer header) was.
"""
import os

CLIENT_ID = os.environ.get("GATEWAY_CLIENT_ID")
CLIENT_SECRET = os.environ.get("GATEWAY_CLIENT_SECRET")
AUTH_URL = os.environ.get("GATEWAY_AUTH_URL")


def _fetch_token_from_issuer() -> str:
    """
    Replace this with your org's actual token issuance call. Left as a
    stub because the reference template only showed the consumption side
    (TOKEN = "<YOUR_TOKEN_HERE>", used as a Bearer header) — confirm the
    actual issuance flow (JWT / AM token / Entra ID) with whoever
    provisioned your gateway access before wiring this up for real.
    """
    if not AUTH_URL or not CLIENT_ID or not CLIENT_SECRET:
        raise RuntimeError(
            "Token issuance not configured. Set GATEWAY_AUTH_URL, "
            "GATEWAY_CLIENT_ID, GATEWAY_CLIENT_SECRET as environment "
            "variables, or replace this function with your org's actual "
            "JWT / AM token / Entra ID issuance call."
        )
    import requests
    response = requests.post(
        AUTH_URL,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        },
        timeout=10,
    )
    response.raise_for_status()
    return response.json()["access_token"]


def get_fresh_token() -> str:
    """
    Call this immediately before every API request — do not store the
    return value across calls or loop iterations. Tokens live ~30
    seconds on this gateway.
    """
    return _fetch_token_from_issuer()
