"""
Token handling for the internal AI gateway — AM token flow.

This is a MANUAL, session-bound token, not something this script can
fetch on its own: you log into the AM portal, copy a token, and it's
valid for ~30 minutes from issuance. This module's job is narrower than
a full auth client — it reads whatever token you last pasted into
data/.token, tracks how old it is, and fails LOUDLY (not silently) once
it's past its window, because retrying an expired manual token will
just fail again — there's nothing to auto-refresh.

Workflow:
  1. Log into the AM portal, copy your token
  2. Paste it (just the raw token, nothing else) into data/.token
  3. Run your classification job
  4. If the job runs longer than ~30 minutes, get a fresh token and
     paste it into data/.token again — the next call will pick it up
     automatically without restarting the script
"""
import time
from pathlib import Path

TOKEN_FILE = Path(__file__).parent.parent / "data" / ".token"
TOKEN_LIFETIME_SECONDS = 30 * 60  # 30 minutes
WARN_THRESHOLD_SECONDS = 25 * 60  # start warning at 25 minutes, before it actually expires


def get_fresh_token() -> str:
    """
    Reads the current token from data/.token every time it's called —
    so if you paste a fresh one mid-run (after re-logging into AM), the
    very next API call picks it up without restarting anything.

    Raises clearly if the file is missing/empty, or if the token is
    old enough that it has likely expired.
    """
    if not TOKEN_FILE.exists():
        raise RuntimeError(
            f"No token found at {TOKEN_FILE}. Log into the AM portal, "
            f"copy your token, and paste it (just the raw token, nothing "
            f"else) into that file."
        )

    token = TOKEN_FILE.read_text().strip()
    if not token:
        raise RuntimeError(f"{TOKEN_FILE} exists but is empty. Paste your AM token into it.")

    age_seconds = time.time() - TOKEN_FILE.stat().st_mtime

    if age_seconds >= TOKEN_LIFETIME_SECONDS:
        raise RuntimeError(
            f"Token in {TOKEN_FILE} is {int(age_seconds / 60)} minutes old — "
            f"AM tokens are valid ~30 minutes, so this one has likely expired. "
            f"Get a fresh token from the AM portal and paste it into {TOKEN_FILE}, "
            f"then re-run (already-classified sites don't need to be redone)."
        )

    if age_seconds >= WARN_THRESHOLD_SECONDS:
        remaining = int((TOKEN_LIFETIME_SECONDS - age_seconds) / 60)
        print(f"  \u26a0\ufe0f  Token is {int(age_seconds / 60)} min old — "
              f"~{remaining} min left. Consider refreshing it soon if you have "
              f"many sites left to classify.")

    return token
