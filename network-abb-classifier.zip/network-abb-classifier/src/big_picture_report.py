"""
The big-picture report — what you look at first across a large batch
of sites, answering the critical questions (Monitoring, Alerting,
Security, Resilience) directly, with drill-down pointers to the
detailed reports underneath for anyone who needs to go further.

Combines already-built pieces rather than recomputing anything:
  - run_report.py — consistency scorecard, gaps, pattern-match summary
  - capability_consistency.py — capability-level detail, version parity,
    unidentified capabilities
  - hardening.py — absolute + contextual findings, per band
No new analysis logic here — this is a synthesis/executive-summary
layer over what's already computed.

Usage:
    python -m src.big_picture_report
"""
import datetime
from pathlib import Path

from src.run_report import load_all_results, group_by_band
from src.capability_consistency import compute_capability_consistency, surface_unidentified_capabilities
from src.hardening import collect_absolute_findings, MIN_SAMPLE_SIZE

OUTPUT_DIR = Path(__file__).parent.parent / "output"

MONITORING_CAPS = {"Monitoring", "IP SLA", "Telemetry / Logging", "Logging"}
ALERTING_CAPS = {"Alerting"}
SECURITY_CAPS = {
    "Segmentation", "Network Access Control", "Firewall / Perimeter Security",
    "IAM", "Authentication", "Port Security", "Control Plane Protection",
    "AAA (Device & Session)", "Crypto / Key Management",
}
RESILIENCE_CAPS = {"Resilience", "Resilience Mapping", "FHRP Resilience"}


def _pillar_summary(all_cap_reports: dict, target_caps: set) -> dict:
    """
    Rolls up consistency across every (abb, capability) entry whose
    capability is in target_caps, across ALL bands — one headline
    number for a pillar like 'Resilience'.
    """
    matching = [
        data for (abb, cap), data in all_cap_reports.items() if cap in target_caps
    ]
    if not matching:
        return {"status": "no data", "sites_evidencing": 0}

    total_sites = sum(d["total_sites"] for d in matching)
    matching_sites = sum(d["sites_matching"] for d in matching)
    diverging = [s for d in matching for div in d["diverging"] for s in div["sites"]]

    return {
        "overall_consistency_pct": round(100 * matching_sites / total_sites, 1) if total_sites else None,
        "sites_evidencing": total_sites,
        "diverging_sites": sorted(set(diverging)),
        "capabilities_included": sorted({d["capability"] for d in matching}),
    }


def generate_big_picture_data() -> dict:
    """Structured version of the big-picture report — same pillars, for importing elsewhere."""
    all_results = load_all_results()
    if not all_results:
        return {"sites_classified": 0}

    grouped = group_by_band(all_results)
    all_cap_reports = {}
    for band, band_results in grouped.items():
        if len(band_results) < MIN_SAMPLE_SIZE:
            continue
        all_cap_reports.update(compute_capability_consistency(band_results))

    return {
        "sites_classified": len(all_results),
        "bands_count": len(grouped),
        "pillars": {
            "monitoring": _pillar_summary(all_cap_reports, MONITORING_CAPS),
            "alerting": _pillar_summary(all_cap_reports, ALERTING_CAPS),
            "security": _pillar_summary(all_cap_reports, SECURITY_CAPS),
            "resilience": _pillar_summary(all_cap_reports, RESILIENCE_CAPS),
        },
        "absolute_hardening_findings": [
            f for band, band_results in grouped.items() for f in collect_absolute_findings(band_results)
        ],
        "unidentified_capabilities": surface_unidentified_capabilities(all_results),
        "bands": {
            band: {"site_count": len(band_results), "sufficient_sample": len(band_results) >= MIN_SAMPLE_SIZE}
            for band, band_results in grouped.items()
        },
    }


def generate_big_picture_report() -> str:
    all_results = load_all_results()
    today = datetime.date.today().isoformat()

    if not all_results:
        return "# Big Picture Report\n\nNo classified results found in data/results/."

    grouped = group_by_band(all_results)

    all_cap_reports = {}
    for band, band_results in grouped.items():
        if len(band_results) < MIN_SAMPLE_SIZE:
            continue
        band_cap_report = compute_capability_consistency(band_results)
        all_cap_reports.update(band_cap_report)

    monitoring = _pillar_summary(all_cap_reports, MONITORING_CAPS)
    alerting = _pillar_summary(all_cap_reports, ALERTING_CAPS)
    security = _pillar_summary(all_cap_reports, SECURITY_CAPS)
    resilience = _pillar_summary(all_cap_reports, RESILIENCE_CAPS)

    lines = [
        "# Big Picture Report",
        f"\nGenerated {today} from **{len(all_results)} classified sites** across **{len(grouped)} bands**.\n",
        "## Critical questions\n",
        "| Pillar | Consistency | Sites with divergence |",
        "|---|---|---|",
    ]
    for name, pillar in [("Monitoring", monitoring), ("Alerting", alerting),
                          ("Security", security), ("Resilience", resilience)]:
        pct = pillar.get("overall_consistency_pct")
        pct_str = f"{pct}%" if pct is not None else "no data yet"
        diverging = pillar.get("diverging_sites", [])
        shown = ", ".join(diverging[:5]) + ("..." if len(diverging) > 5 else "")
        lines.append(f"| **{name}** | {pct_str} | {len(diverging)} site(s){': ' + shown if diverging else ''} |")

    # Mermaid diagram — visual read of the same four pillars, colour-coded
    lines.append("\n```mermaid")
    lines.append("graph LR")
    lines.append(f'  ROOT["{len(all_results)} sites classified"]')
    for name, pillar in [("Monitoring", monitoring), ("Alerting", alerting),
                          ("Security", security), ("Resilience", resilience)]:
        pct = pillar.get("overall_consistency_pct")
        node_id = name.upper()
        if pct is None:
            label = f"{name}<br/>no data yet"
        else:
            label = f"{name}<br/>{pct}%"
        lines.append(f'  ROOT --> {node_id}["{label}"]')
        diverging = pillar.get("diverging_sites", [])
        if diverging:
            lines.append(f'  style {node_id} fill:#f2a65a')
        elif pct is not None:
            lines.append(f'  style {node_id} fill:#4fd1c5')
    lines.append("```")

    lines.append("\n## Absolute hardening findings (across all bands)\n")
    total_absolute = 0
    for band, band_results in grouped.items():
        findings = collect_absolute_findings(band_results)
        total_absolute += len(findings)
        for f in findings:
            lines.append(f"- [{f['severity']}] `{f['site_id']}` ({band}): {f['finding']}")
    if total_absolute == 0:
        lines.append("- None found.")

    unidentified = surface_unidentified_capabilities(all_results)
    if unidentified:
        lines.append(f"\n## Unidentified capabilities ({len(unidentified)} distinct)\n")
        for element, sites in sorted(unidentified.items(), key=lambda kv: -len(kv[1]))[:10]:
            lines.append(f"- {element} — {len(sites)} site(s)")

    lines.append("\n## Bands at a glance\n")
    lines.append("| Band | Sites | Sample size |")
    lines.append("|---|---|---|")
    for band, band_results in sorted(grouped.items()):
        status = "sufficient" if len(band_results) >= MIN_SAMPLE_SIZE else f"below minimum ({MIN_SAMPLE_SIZE})"
        lines.append(f"| `{band}` | {len(band_results)} | {status} |")

    lines.append("\n## Drill in\n")
    lines.append("- `python -m src.run_report` — full consistency scorecard, gap analysis, pattern-match summary per band")
    lines.append("- `python -m src.capability_consistency` — capability-level detail, VSBB/CBB version parity, security-relevant filter")
    lines.append("- `python -m src.hardening <band>` — absolute + contextual hardening detail for one band")
    lines.append("- `python -m src.resilience_statement <site_id>` — customer-facing narrative for one site")
    lines.append("- `python -m src.standards <site_id>` — rule compliance for one site")
    lines.append("- `python -m src.topology_diagram <site_id>` — ASCII connectivity + resilience for one site (once collated)")
    lines.append("- `python -m src.derive_patterns` — propose governed patterns from what's been classified so far")

    return "\n".join(lines)


if __name__ == "__main__":
    import json as _json

    report = generate_big_picture_report()
    print(report)

    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / f"big-picture-{datetime.date.today().isoformat()}.md"
    out_path.write_text(report)
    print(f"\nSaved to {out_path}")

    json_data = generate_big_picture_data()
    json_path = OUTPUT_DIR / f"big-picture-{datetime.date.today().isoformat()}.json"
    json_path.write_text(_json.dumps(json_data, indent=2))
    print(f"Saved to {json_path} (structured, for importing elsewhere)")
