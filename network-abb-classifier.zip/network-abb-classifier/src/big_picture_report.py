"""
The big-picture report — what you look at first across a large batch
of sites, answering the critical questions (Monitoring, Alerting,
Security, Resilience) directly, with drill-down pointers to the
detailed reports underneath for anyone who needs to go further.

Combines already-built pieces rather than recomputing anything:
  - run_report.py — consistency scorecard, gaps, pattern-match summary
  - capability_consistency.py — capability-level detail, version parity,
    unidentified capabilities
  - hardening.py — absolute + contextual findings, per band
No new analysis logic here — this is a synthesis/executive-summary
layer over what's already computed.

Usage:
    python -m src.big_picture_report
"""
import datetime
from pathlib import Path

from src.run_report import load_all_results, group_by_band
from src.capability_consistency import compute_capability_consistency, surface_unidentified_capabilities
from src.hardening import collect_absolute_findings, MIN_SAMPLE_SIZE

OUTPUT_DIR = Path(__file__).parent.parent / "output"


def _count_devices_for_site(site_id: str) -> int:
    """
    Counts devices in a site's collated config (the '=== DEVICE:' markers
    written by collate_site_configs.py). Falls back to 1 if the collated
    file isn't found (e.g. a single-device site that was never collated).
    """
    sites_dir = Path(__file__).parent.parent / "data" / "sites"
    collated_path = sites_dir / f"{site_id}.txt"
    if not collated_path.exists():
        return 1
    return max(1, collated_path.read_text().count("=== DEVICE:"))

MONITORING_CAPS = {"Monitoring", "Alerting", "IP SLA", "Telemetry / Logging", "Logging"}
SECURITY_CAPS = {
    "Segmentation", "Network Access Control", "Firewall / Perimeter Security",
    "IAM", "Authentication", "Port Security", "Control Plane Protection",
    "AAA (Device & Session)", "Crypto / Key Management",
}
RESILIENCE_CAPS = {"Resilience", "Resilience Mapping", "FHRP Resilience"}


def _pillar_summary(all_cap_reports: dict, target_caps: set) -> dict:
    """
    Rolls up consistency across every (abb, capability) entry whose
    capability is in target_caps, across ALL bands — one headline
    number for a pillar like 'Resilience'.
    """
    matching = [
        data for (abb, cap), data in all_cap_reports.items() if cap in target_caps
    ]
    if not matching:
        return {"status": "no data", "sites_evidencing": 0}

    total_sites = sum(d["total_sites"] for d in matching)
    matching_sites = sum(d["sites_matching"] for d in matching)
    diverging = [s for d in matching for div in d["diverging"] for s in div["sites"]]

    return {
        "overall_consistency_pct": round(100 * matching_sites / total_sites, 1) if total_sites else None,
        "sites_evidencing": total_sites,
        "diverging_sites": sorted(set(diverging)),
        "capabilities_included": sorted({d["capability"] for d in matching}),
    }


def generate_big_picture_data() -> dict:
    """Structured version of the big-picture report — same pillars, for importing elsewhere."""
    all_results = load_all_results()
    if not all_results:
        return {"sites_classified": 0}

    grouped = group_by_band(all_results)
    all_cap_reports = {}
    for band, band_results in grouped.items():
        if len(band_results) < MIN_SAMPLE_SIZE:
            continue
        all_cap_reports.update(compute_capability_consistency(band_results))

    _, heatmap_data = build_sbb_consistency_heatmap(grouped)

    return {
        "sites_classified": len(all_results),
        "devices_classified": sum(_count_devices_for_site(r["site_id"]) for r in all_results),
        "bands_count": len(grouped),
        "pillars": {
            "monitoring_alerting": _pillar_summary(all_cap_reports, MONITORING_CAPS),
            "security": _pillar_summary(all_cap_reports, SECURITY_CAPS),
            "resilience": _pillar_summary(all_cap_reports, RESILIENCE_CAPS),
        },
        "sbb_consistency_heatmap": heatmap_data,
        "absolute_hardening_findings": [
            f for band, band_results in grouped.items() for f in collect_absolute_findings(band_results)
        ],
        "unidentified_capabilities": surface_unidentified_capabilities(all_results),
        "bands": {
            band: {"site_count": len(band_results), "sufficient_sample": len(band_results) >= MIN_SAMPLE_SIZE}
            for band, band_results in grouped.items()
        },
    }


def _sbb_type_for_cbb(band_results: list, abb: str, cbb: str) -> str:
    """Looks up the SBB type name (e.g. 'MPLS') for a given canonical
    CBB, from whichever site actually has it — the consistency
    computation only tracks CBB IDs, not the human-readable type."""
    for result in band_results:
        for m in result.get("abb_matches", []):
            if m["abb"] == abb and m.get("sbb", {}).get("cbb") == cbb:
                return m["sbb"].get("type", "?")
    return "?"


def build_sbb_consistency_heatmap(grouped: dict) -> tuple:
    """
    Rows = bands (site types). Columns = ABBs (WAN/User/WiFi — cell
    shows SBB consistency % AND the canonical SBB type, e.g. "90% (MPLS)")
    PLUS cross-cutting pillars (Monitoring & Alerting, Security,
    Resilience — computed PER BAND, cell shows capability consistency %).

    A band legitimately not evidencing a cross-cutting pillar at all
    (e.g. a small site with no Resilience capability, which is correct
    per docs/BAND_APPLICABILITY.md, not a gap) shows "—", never a false
    red — this is "no data for this band", distinct from "evidenced but
    inconsistent".

    Returns (markdown_table, raw_data_dict) — raw data for the JSON export.
    """
    from src.run_report import compute_block_consistency

    all_abbs = set()
    band_block_data = {}
    band_cap_reports = {}
    skipped_bands = []

    for band, band_results in sorted(grouped.items()):
        if len(band_results) < MIN_SAMPLE_SIZE:
            skipped_bands.append(band)
            continue
        consistency = compute_block_consistency(band_results)
        band_block_data[band] = consistency
        all_abbs.update(consistency.keys())
        band_cap_reports[band] = compute_capability_consistency(band_results)

    all_abbs = sorted(all_abbs)
    if not band_block_data:
        return ("_No bands have enough sites yet for a heatmap (minimum "
                 f"{MIN_SAMPLE_SIZE} per band)._"), {}

    pillar_columns = [
        ("Monitoring & Alerting", MONITORING_CAPS),
        ("Security", SECURITY_CAPS),
        ("Resilience", RESILIENCE_CAPS),
    ]
    columns = all_abbs + [name for name, _ in pillar_columns]

    def _cell(pct):
        if pct is None:
            return "\U0001F534"
        return "\U0001F7E2" if pct >= 90 else ("\U0001F7E1" if pct >= 70 else "\U0001F534")

    lines = ["| Band | " + " | ".join(columns) + " |"]
    lines.append("|---|" + "---|" * len(columns))

    raw = {}
    for band in sorted(band_block_data.keys()):
        band_results_lookup = grouped[band]
        row = [f"`{band}`"]
        raw[band] = {}

        for abb in all_abbs:
            sbb_data = band_block_data[band].get(abb, {}).get("sbb")
            if sbb_data is None:
                row.append("—")
                raw[band][abb] = None
            else:
                pct = sbb_data["consistency_pct"]
                sbb_type = _sbb_type_for_cbb(band_results_lookup, abb, sbb_data["canonical_cbb"])
                row.append(f"{_cell(pct)} {pct}% ({sbb_type})")
                raw[band][abb] = {"consistency_pct": pct, "sbb_type": sbb_type}

        for name, cap_set in pillar_columns:
            pillar = _pillar_summary(band_cap_reports[band], cap_set)
            pct = pillar.get("overall_consistency_pct")
            if pct is None:
                row.append("—")
                raw[band][name] = None
            else:
                row.append(f"{_cell(pct)} {pct}%")
                raw[band][name] = pct

        lines.append("| " + " | ".join(row) + " |")

    table = "\n".join(lines)
    if skipped_bands:
        table += (f"\n\n_Not shown (below minimum sample size of {MIN_SAMPLE_SIZE}): "
                   f"{', '.join(f'`{b}`' for b in skipped_bands)}_")
    table += ("\n\n_\u2014 means no data for this band/column \u2014 e.g. a smaller site type "
              "correctly not evidencing Resilience is expected, not a gap. Cross-reference "
              "docs/BAND_APPLICABILITY.md before treating a \u2014 as a finding._")

    return table, raw


def generate_big_picture_report() -> str:
    all_results = load_all_results()
    today = datetime.date.today().isoformat()

    if not all_results:
        return "# Big Picture Report\n\nNo classified results found in data/results/."

    grouped = group_by_band(all_results)

    all_cap_reports = {}
    for band, band_results in grouped.items():
        if len(band_results) < MIN_SAMPLE_SIZE:
            continue
        band_cap_report = compute_capability_consistency(band_results)
        all_cap_reports.update(band_cap_report)

    monitoring_alerting = _pillar_summary(all_cap_reports, MONITORING_CAPS)
    security = _pillar_summary(all_cap_reports, SECURITY_CAPS)
    resilience = _pillar_summary(all_cap_reports, RESILIENCE_CAPS)

    total_devices = sum(_count_devices_for_site(r["site_id"]) for r in all_results)

    lines = [
        "# Big Picture Report",
        f"\nGenerated {today} — **{total_devices} devices** categorised across "
        f"**{len(all_results)} sites** and **{len(grouped)} band type{'s' if len(grouped) != 1 else ''}**.\n",
        "## Critical questions\n",
        "| Pillar | Consistency | Sites with divergence |",
        "|---|---|---|",
    ]
    for name, pillar in [("Monitoring & Alerting", monitoring_alerting),
                          ("Security", security), ("Resilience", resilience)]:
        pct = pillar.get("overall_consistency_pct")
        pct_str = f"{pct}%" if pct is not None else "no data yet"
        diverging = pillar.get("diverging_sites", [])
        shown = ", ".join(diverging[:5]) + ("..." if len(diverging) > 5 else "")
        lines.append(f"| **{name}** | {pct_str} | {len(diverging)} site(s){': ' + shown if diverging else ''} |")

    # Mermaid diagram — visual read of the same four pillars, colour-coded
    from src.mermaid_utils import safe_mermaid_id
    lines.append("\n```mermaid")
    lines.append("graph LR")
    lines.append(f'  ROOT["{total_devices} devices, {len(all_results)} sites"]')
    for name, pillar in [("Monitoring & Alerting", monitoring_alerting),
                          ("Security", security), ("Resilience", resilience)]:
        pct = pillar.get("overall_consistency_pct")
        node_id = safe_mermaid_id(name)
        if pct is None:
            label = f"{name}<br/>no data yet"
        else:
            label = f"{name}<br/>{pct}%"
        lines.append(f'  ROOT --> {node_id}["{label}"]')
        diverging = pillar.get("diverging_sites", [])
        if diverging:
            lines.append(f'  style {node_id} fill:#f2a65a')
        elif pct is not None:
            lines.append(f'  style {node_id} fill:#4fd1c5')
    lines.append("```")

    heatmap_table, heatmap_data = build_sbb_consistency_heatmap(grouped)
    lines.append("\n## Consistency heatmap (band \u00d7 ABB + cross-cutting pillars)\n")
    lines.append("_Rows are site types, columns are ABBs, cells are SBB consistency \u2014_")
    lines.append("_\U0001F7E2 \u226590% \u2003 \U0001F7E1 70-89% \u2003 \U0001F534 <70% \u2003 \u2014 no data/not applicable_\n")
    lines.append(heatmap_table)

    lines.append("\n## Absolute hardening findings (across all bands)\n")
    total_absolute = 0
    for band, band_results in grouped.items():
        findings = collect_absolute_findings(band_results)
        total_absolute += len(findings)
        for f in findings:
            lines.append(f"- [{f['severity']}] `{f['site_id']}` ({band}): {f['finding']}")
    if total_absolute == 0:
        lines.append("- None found.")

    unidentified = surface_unidentified_capabilities(all_results)
    if unidentified:
        lines.append(f"\n## Unidentified capabilities ({len(unidentified)} distinct)\n")
        for element, sites in sorted(unidentified.items(), key=lambda kv: -len(kv[1]))[:10]:
            lines.append(f"- {element} — {len(sites)} site(s)")

    lines.append("\n## Bands at a glance\n")
    lines.append("| Band | Sites | Sample size |")
    lines.append("|---|---|---|")
    for band, band_results in sorted(grouped.items()):
        status = "sufficient" if len(band_results) >= MIN_SAMPLE_SIZE else f"below minimum ({MIN_SAMPLE_SIZE})"
        lines.append(f"| `{band}` | {len(band_results)} | {status} |")

    lines.append("\n## Drill in\n")
    lines.append("- `python -m src.run_report` — full consistency scorecard, gap analysis, pattern-match summary per band")
    lines.append("- `python -m src.capability_consistency` — capability-level detail, VSBB/CBB version parity, security-relevant filter")
    lines.append("- `python -m src.hardening <band>` — absolute + contextual hardening detail for one band")
    lines.append("- `python -m src.resilience_statement <site_id>` — customer-facing narrative for one site")
    lines.append("- `python -m src.standards <site_id>` — rule compliance for one site")
    lines.append("- `python -m src.topology_diagram <site_id>` — ASCII connectivity + resilience for one site (once collated)")
    lines.append("- `python -m src.derive_patterns` — propose governed patterns from what's been classified so far")

    return "\n".join(lines)


if __name__ == "__main__":
    import json as _json

    report = generate_big_picture_report()
    print(report)

    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / f"big-picture-{datetime.date.today().isoformat()}.md"
    out_path.write_text(report)
    print(f"\nSaved to {out_path}")

    json_data = generate_big_picture_data()
    json_path = OUTPUT_DIR / f"big-picture-{datetime.date.today().isoformat()}.json"
    json_path.write_text(_json.dumps(json_data, indent=2))
    print(f"Saved to {json_path} (structured, for importing elsewhere)")
