"""
Builds a pre-filled classification scaffold — as much of the output
structure as code can determine deterministically, leaving PLACEHOLDER
markers only where genuine judgment is needed (band, SBB/VSBB/CBB
catalogue matching).

Why: every schema-compliance failure so far has come from asking the
model to generate the ENTIRE complex nested structure from scratch —
that's a wide-open task, and it kept inventing its own shape instead.
Filling in a blank is a much narrower, more reliable task than
constructing a structure from nothing. This uses the same
config_indicators already in capability_taxonomy.json (proven,
tested, deterministic — see the reverted rule_based_classifier.py
exploration) to pre-populate capabilities, evidence, and ABB grouping,
so the model's job shrinks to: pick the band, pick the right SBB/VSBB/
CBB catalogue entries, and confirm/adjust confidence — not invent
key names.
"""
import json
from pathlib import Path

TAXONOMY_PATH = Path(__file__).parent.parent / "data" / "catalogue" / "capability_taxonomy.json"

ZONE_TO_ABB = {
    "WAN": "WAN",
    "User LAN": "User",
    "WiFi": "WiFi",
}
CROSS_CUTTING_ZONES = {"Cross-Cutting / Platform", "Cross-Cutting / Hardening", "Cross-Cutting / Config Correctness"}


def _load_indicators() -> list:
    taxonomy = json.loads(TAXONOMY_PATH.read_text())
    flattened = []
    for zone_entry in taxonomy.get("zones", []):
        zone = zone_entry["zone"]
        for cap in zone_entry.get("capabilities", []):
            for indicator in cap.get("config_indicators", []):
                flattened.append({
                    "capability": cap["capability"],
                    "zone": zone,
                    "indicator": indicator,
                })
    return flattened


def _detect_capabilities(raw_config: str) -> dict:
    """Returns {abb_or_'cross_cutting': [{"capability","evidence"}, ...]}."""
    indicators = _load_indicators()
    lines = [l for l in raw_config.splitlines() if not l.strip().startswith("!")]
    results = {}

    for entry in indicators:
        indicator_lower = entry["indicator"].lower()
        for line in lines:
            if indicator_lower in line.lower():
                abb = ZONE_TO_ABB.get(entry["zone"], "cross_cutting")
                results.setdefault(abb, [])
                candidate = {"capability": entry["capability"], "evidence": line.strip()}
                if candidate not in results[abb]:
                    results[abb].append(candidate)

    return results


def build_scaffold(site_id: str, raw_config: str) -> dict:
    """
    Returns a classification skeleton, structurally matching
    CLASSIFICATION_SCHEMA, with capabilities/evidence/ABB grouping
    pre-filled by deterministic indicator matching, and PLACEHOLDER
    strings only where the model must actually decide something
    (band, SBB/VSBB/CBB type, confidence).
    """
    detected = _detect_capabilities(raw_config)

    abb_matches = []
    for abb, caps in detected.items():
        if abb == "cross_cutting":
            continue
        abb_matches.append({
            "abb": abb,
            "sbb": {
                "type": "PLACEHOLDER \u2014 pick the matching SBB type for this ABB from the catalogue",
                "vsbb": "PLACEHOLDER \u2014 vendor-specific protocol/method, e.g. 'Cisco EIGRP'",
                "cbb": "PLACEHOLDER \u2014 matching CBB id from the catalogue",
            },
            "zbb": {
                "type": "PLACEHOLDER \u2014 pick the matching ZBB type for this ABB from the catalogue",
                "vsbb": "PLACEHOLDER",
                "cbb": "PLACEHOLDER",
                "effective_restriction": "PLACEHOLDER \u2014 the actual restriction observed, e.g. 'VLAN 10 cannot reach VLAN 20', or omit if none evidenced",
            },
            "capabilities": [
                {"capability": c["capability"], "evidence": c["evidence"], "confidence": "PLACEHOLDER \u2014 high/medium/low"}
                for c in caps
            ],
        })

    cross_cutting = detected.get("cross_cutting", [])
    if cross_cutting and abb_matches:
        for c in cross_cutting:
            abb_matches[0]["capabilities"].append(
                {"capability": c["capability"], "evidence": c["evidence"], "confidence": "PLACEHOLDER \u2014 high/medium/low"}
            )

    return {
        "site_id": site_id,
        "primary_capability": "PLACEHOLDER \u2014 e.g. Branch, Campus",
        "band": "PLACEHOLDER \u2014 pick exactly ONE band from the catalogue's band_applicability_matrix",
        "band_rationale": "PLACEHOLDER \u2014 why this band, based on the config evidence",
        "abb_matches": abb_matches,
        "unmatched_elements": [],
        "hardening_observations": [],
    }


def build_scaffold_prompt_block(site_id: str, raw_config: str) -> str:
    """Formats the scaffold as instructional text for embedding in a prompt."""
    scaffold = build_scaffold(site_id, raw_config)
    placeholder_count = json.dumps(scaffold).count("PLACEHOLDER")

    return f"""PRE-BUILT SCAFFOLD (code already did the deterministic part):

The capabilities below were detected by DETERMINISTIC code matching known
config indicators — NOT by you. Do not second-guess or remove them unless
you find clear evidence they're wrong. Your job is ONLY to fill in the
{placeholder_count} fields marked PLACEHOLDER — do not restructure this,
do not rename keys, do not add new top-level keys. Return the exact same
structure with every PLACEHOLDER replaced by a real value, grounded in
the catalogue and config.

{json.dumps(scaffold, indent=2)}
"""


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m src.scaffold_builder <site_id>")
        sys.exit(1)

    from src.config_loader import load_site_config, is_raw_config

    site_id = sys.argv[1]
    config = load_site_config(site_id)
    if not is_raw_config(config):
        print("This tool works on raw config text, not pre-normalised JSON.")
        sys.exit(1)

    scaffold = build_scaffold(site_id, config)
    placeholder_count = json.dumps(scaffold).count("PLACEHOLDER")
    filled_caps = sum(len(m["capabilities"]) for m in scaffold["abb_matches"])

    print(f"Scaffold for {site_id}: {len(scaffold['abb_matches'])} ABB(s) pre-detected, "
          f"{filled_caps} capabilit(y/ies) pre-filled with evidence, "
          f"{placeholder_count} fields still need AI judgment.\n")
    print(json.dumps(scaffold, indent=2))
