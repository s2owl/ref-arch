"""
Validates a manually pasted GUI response against CLASSIFICATION_SCHEMA
before it's trusted and copied into data/results/. This is the gate
that replaces function-calling enforcement in the GUI-only workflow —
without it, a malformed or incomplete response could silently enter the
pipeline and corrupt every downstream tool (patterns, standards, build
guide) that assumes valid, complete classification output.

Usage:
    python -m src.validate_manual_result BR-EXAMPLE-01

Reads gui-prompts/<site_id>-output.json, validates it, and on success
copies it into data/results/<site_id>.json — the exact location
src/classify.py would have written it to, so every downstream tool
works identically regardless of how the classification was produced.
"""
import json
import sys
from pathlib import Path

import jsonschema

from src.schema import CLASSIFICATION_SCHEMA

GUI_DIR = Path(__file__).parent.parent / "gui-prompts"
RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"


def validate_manual_result(site_id: str) -> bool:
    raw_path = GUI_DIR / f"{site_id}-output.json"
    if not raw_path.exists():
        print(f"\u274c No file found at {raw_path}")
        print(f"   Paste the model's raw JSON response into that file first.")
        return False

    raw_text = raw_path.read_text().strip()

    # Common GUI artefact: the model wraps output in ```json fences
    # despite being told not to. Strip them defensively rather than
    # failing on something this easy to fix.
    if raw_text.startswith("```"):
        lines = raw_text.split("\n")
        raw_text = "\n".join(lines[1:-1]) if lines[-1].strip() == "```" else "\n".join(lines[1:])

    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError as e:
        print(f"\u274c Not valid JSON: {e}")
        print(f"   Check for stray text before/after the JSON, or truncated output "
              f"if the GUI has a response length limit.")
        return False

    try:
        jsonschema.validate(instance=parsed, schema=CLASSIFICATION_SCHEMA)
    except jsonschema.exceptions.ValidationError as e:
        print(f"\u274c JSON is valid but doesn't match the required schema:")
        print(f"   {e.message}")
        print(f"   At path: {' -> '.join(str(p) for p in e.absolute_path) or '(root)'}")
        print(f"   This usually means the model missed a required field, used the wrong "
              f"type, or used a value outside the allowed enum (e.g. an unlisted capability "
              f"tag). Check the model's response against the schema and either re-prompt "
              f"or fix the output manually.")
        return False

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RESULTS_DIR / f"{site_id}.json"
    out_path.write_text(json.dumps(parsed, indent=2))

    print(f"\u2705 Valid — matches schema exactly. Saved to {out_path}")
    print(f"   This site is now usable by every downstream tool (patterns.py, "
          f"standards.py, build_guide.py, etc.) exactly as if it came from the API.")
    return True


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m src.validate_manual_result <site_id>")
        print("       python -m src.validate_manual_result --all   (validate every *-output.json waiting in gui-prompts/)")
        sys.exit(1)

    if sys.argv[1] == "--all":
        output_files = sorted(GUI_DIR.glob("*-output.json"))
        if not output_files:
            print(f"No *-output.json files found in {GUI_DIR}/. Nothing to validate.")
            sys.exit(0)

        results = {"valid": [], "invalid": []}
        for f in output_files:
            site_id = f.stem.replace("-output", "")
            print(f"--- {site_id} ---")
            success = validate_manual_result(site_id)
            (results["valid"] if success else results["invalid"]).append(site_id)
            print()

        print("=" * 40)
        print(f"Summary: {len(results['valid'])} valid, {len(results['invalid'])} invalid")
        if results["invalid"]:
            print(f"Invalid: {', '.join(results['invalid'])}")
            print("Fix these in the GUI and re-run --all, or validate them individually for detail.")
        sys.exit(0 if not results["invalid"] else 1)

    success = validate_manual_result(sys.argv[1])
    sys.exit(0 if success else 1)
