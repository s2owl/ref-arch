"""
Validates a manually pasted GUI response against CLASSIFICATION_SCHEMA
before it's trusted and copied into data/results/. This is the gate
that replaces function-calling enforcement in the GUI-only workflow —
without it, a malformed or incomplete response could silently enter the
pipeline and corrupt every downstream tool (patterns, standards, build
guide) that assumes valid, complete classification output.

Usage:
    python -m src.validate_manual_result BR-EXAMPLE-01

Reads gui-prompts/<site_id>-output.json, validates it, and on success
copies it into data/results/<site_id>.json — the exact location
src/classify.py would have written it to, so every downstream tool
works identically regardless of how the classification was produced.
"""
import json
import sys
from pathlib import Path

import jsonschema

from src.schema import CLASSIFICATION_SCHEMA

GUI_DIR = Path(__file__).parent.parent / "gui-prompts"
RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"


def _extract_json_object(text: str) -> str:
    """
    Finds the first balanced {...} block in text and returns it as a
    substring. Handles the common GUI failure mode where the model
    adds prose before/after the JSON ("Here's the classification: {...}"
    or "{...} Let me know if you need anything else!") despite being
    told not to — bracket-matching correctly handles nested objects,
    unlike a naive first-'{'-to-last-'}' slice which would grab any
    trailing prose containing stray braces too.
    """
    start = text.find("{")
    if start == -1:
        return text  # no JSON object found at all — let the caller's parse error be informative

    depth = 0
    for i, char in enumerate(text[start:], start=start):
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]

    return text[start:]  # unbalanced — likely truncated response, let the caller's parse error surface this


def validate_manual_result(site_id: str) -> bool:
    raw_path = GUI_DIR / f"{site_id}-output.json"
    if not raw_path.exists():
        print(f"\u274c No file found at {raw_path}")
        print(f"   Paste the model's raw JSON response into that file first.")
        return False

    raw_text = raw_path.read_text().strip()

    # Common GUI artefact: the model wraps output in ```json fences
    # despite being told not to. Strip them defensively rather than
    # failing on something this easy to fix.
    if raw_text.startswith("```"):
        lines = raw_text.split("\n")
        raw_text = "\n".join(lines[1:-1]) if lines[-1].strip() == "```" else "\n".join(lines[1:])

    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError:
        # Whole file isn't valid JSON as-is — likely wrapped in prose
        # despite instructions not to. Try extracting just the JSON
        # object before giving up.
        extracted = _extract_json_object(raw_text)
        try:
            parsed = json.loads(extracted)
            print(f"\u2139\ufe0f  Note: the response had extra text around the JSON "
                  f"(the model added prose despite instructions) — extracted and "
                  f"parsed the JSON object successfully anyway.")
        except json.JSONDecodeError as e:
            print(f"\u274c Not valid JSON, even after trying to extract a JSON object from surrounding text: {e}")
            print(f"   Check for a truncated response (GUI length limit), or open the file "
                  f"and confirm there's actually a complete {{...}} object in there somewhere.")
            return False

    # Common GUI artefact: the model wraps the real object under a key
    # ("result", "classification", "response", etc.) despite being told
    # to return it flat. If site_id isn't where the schema expects it,
    # check one level down for a nested object that has it — don't
    # guess the wrapper key name, just find the payload.
    if "site_id" not in parsed and isinstance(parsed, dict):
        nested_candidates = [v for v in parsed.values() if isinstance(v, dict) and "site_id" in v]
        if len(nested_candidates) == 1:
            print(f"\u2139\ufe0f  Note: the response wrapped the classification under a key "
                  f"instead of returning it flat — unwrapped it automatically.")
            parsed = nested_candidates[0]
        elif len(nested_candidates) > 1:
            print(f"\u274c Found {len(nested_candidates)} nested objects that look like a "
                  f"classification (each has a 'site_id') — can't tell which one is correct. "
                  f"Fix the response manually to return a single flat object.")
            return False

    try:
        jsonschema.validate(instance=parsed, schema=CLASSIFICATION_SCHEMA)
    except jsonschema.exceptions.ValidationError as e:
        print(f"\u274c JSON is valid but doesn't match the required schema:")
        print(f"   {e.message}")
        print(f"   At path: {' -> '.join(str(p) for p in e.absolute_path) or '(root)'}")
        print(f"   This usually means the model missed a required field, used the wrong "
              f"type, or used a value outside the allowed enum (e.g. an unlisted capability "
              f"tag). Check the model's response against the schema and either re-prompt "
              f"or fix the output manually.")
        return False

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RESULTS_DIR / f"{site_id}.json"
    out_path.write_text(json.dumps(parsed, indent=2))

    print(f"\u2705 Valid — matches schema exactly. Saved to {out_path}")
    print(f"   This site is now usable by every downstream tool (patterns.py, "
          f"standards.py, build_guide.py, etc.) exactly as if it came from the API.")
    return True


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m src.validate_manual_result <site_id>")
        print("       python -m src.validate_manual_result --all   (validate every *-output.json waiting in gui-prompts/)")
        sys.exit(1)

    if sys.argv[1] == "--all":
        output_files = sorted(GUI_DIR.glob("*-output.json"))
        if not output_files:
            print(f"No *-output.json files found in {GUI_DIR}/. Nothing to validate.")
            sys.exit(0)

        results = {"valid": [], "invalid": []}
        for f in output_files:
            site_id = f.stem.replace("-output", "")
            print(f"--- {site_id} ---")
            success = validate_manual_result(site_id)
            (results["valid"] if success else results["invalid"]).append(site_id)
            print()

        print("=" * 40)
        print(f"Summary: {len(results['valid'])} valid, {len(results['invalid'])} invalid")
        if results["invalid"]:
            print(f"Invalid: {', '.join(results['invalid'])}")
            print("Fix these in the GUI and re-run --all, or validate them individually for detail.")
        sys.exit(0 if not results["invalid"] else 1)

    success = validate_manual_result(sys.argv[1])
    sys.exit(0 if success else 1)
