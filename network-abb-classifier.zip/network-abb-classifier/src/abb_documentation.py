"""
Wave 1.9: ABB architecture documentation generator.

Deterministic templating over the catalogue itself (not per-site
classification output — this is architecture-level documentation, one
doc per ABB, not one per site). Produces the narrative format:

  This ABB delivers X to Y capability.
  It is made up of A/B/C SBB.
  The VSBBs in this space are: ...
  The zones look like this: ...
  Resilience is delivered by: ...
  Security has these considerations: ...
  Reference diagram: [Mermaid]

No AI call — this reads directly from data/catalogue/catalogue.json,
which is itself either hand-curated or derived from Wave One pattern
data (once real 70-site results exist).
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def _load_catalogue() -> dict:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        path = DATA_DIR / "catalogue" / "catalogue.example.json"
    return json.loads(path.read_text())


def _primary_capabilities_for_abb(catalogue: dict, abb: str) -> list:
    return [
        name for name, pc in catalogue.get("primary_capabilities", {}).items()
        if abb in pc.get("abbs", [])
    ]


def _providers_for_abb(catalogue: dict, abb: str) -> list:
    providers = {
        entry["provider"] for entry in catalogue.get("sbb_catalogue", [])
        if entry["abb"] == abb and entry.get("approved")
    }
    return sorted(providers)


def _rules_for_abb(catalogue: dict, abb: str, capability: str) -> list:
    return [
        r for r in catalogue.get("requirement_rules", [])
        if r["applies_to_abb"] in (abb, "*") and r["requires_capability"] == capability
    ]


def generate_mermaid_diagram(catalogue: dict, abb: str) -> str:
    abb_def = catalogue["abbs"][abb]
    lines = ["```mermaid", "graph TD", f'  ABB["{abb} (ABB)"]']

    for sbb_type in abb_def.get("sbb_types", []):
        sbb_node = f"SBB_{sbb_type.replace(' ', '_').replace('-', '_')}"
        lines.append(f'  ABB --> {sbb_node}["{sbb_type} (SBB)"]')
        for entry in catalogue.get("sbb_catalogue", []):
            if entry["abb"] == abb and entry["sbb_type"] == sbb_type:
                vsbb_node = f"{sbb_node}_{entry['provider'].replace('-', '_')}"
                lines.append(f'  {sbb_node} --> {vsbb_node}["{entry["provider"]} (VSBB)"]')
                for cbb in entry.get("cbbs", []):
                    cbb_node = cbb["cbb_id"].replace("-", "_")
                    lines.append(f'  {vsbb_node} --> {cbb_node}["{cbb["cbb_id"]} (CBB)"]')

    for zbb_type in abb_def.get("zbb_types", []):
        zbb_node = f"ZBB_{zbb_type.replace(' ', '_').replace('-', '_')}"
        lines.append(f'  ABB --> {zbb_node}["{zbb_type} (ZBB)"]')
        for entry in catalogue.get("zbb_catalogue", []):
            if entry["abb"] == abb and entry["zbb_type"] == zbb_type:
                vsbb_node = f"{zbb_node}_{entry['provider'].replace('-', '_')}"
                lines.append(f'  {zbb_node} --> {vsbb_node}["{entry["provider"]} (VSBB)"]')
                for cbb in entry.get("cbbs", []):
                    cbb_node = cbb["cbb_id"].replace("-", "_")
                    lines.append(f'  {vsbb_node} --> {cbb_node}["{cbb["cbb_id"]} (CBB)"]')

    lines.append("```")
    return "\n".join(lines)


def generate_abb_documentation(abb: str) -> str:
    catalogue = _load_catalogue()
    abb_def = catalogue["abbs"][abb]
    primary_caps = _primary_capabilities_for_abb(catalogue, abb)
    providers = _providers_for_abb(catalogue, abb)

    lines = [f"# {abb} — Architecture Building Block\n"]

    lines.append(
        f"This ABB delivers **{abb_def['description'].split('.')[0].strip().rstrip('.').lower()}** "
        f"to the {', '.join(primary_caps)} capability.\n"
    )

    sbb_list = abb_def.get("sbb_types", [])
    lines.append(f"It is made up of **{', '.join(sbb_list)}** SBB{'s' if len(sbb_list) != 1 else ''}.\n")

    lines.append(f"The VSBBs (approved providers) in this space are: **{', '.join(providers) if providers else 'none approved yet'}**.\n")

    zbb_list = abb_def.get("zbb_types", [])
    lines.append(f"The zones (ZBB — boundary control) look like this: **{', '.join(zbb_list) if zbb_list else 'none defined yet'}**.\n")

    lines.append(
        "_Note: the lists above are the possibility space — any approved SBB "
        "may in principle pair with any approved ZBB. The patterns below are "
        "the actual governed combinations — which SBB **and** which ZBB "
        "together constitute an approved build for a given band. Only a "
        "listed pattern is buildable; do not assume any SBB/ZBB combination "
        "not shown below is approved._\n"
    )

    patterns_for_abb = [
        p for p in catalogue.get("pattern_catalogue", []) if abb in p.get("bundle", {})
    ]
    if patterns_for_abb:
        lines.append("**Patterns defined for this ABB:**")
        for p in patterns_for_abb:
            bundle = p["bundle"][abb]
            lines.append(
                f"- `{p['pattern_id']}` (band: `{p['band']}`): "
                f"**{bundle['sbb_type']}** SBB **AND** **{bundle['zbb_type']}** ZBB "
                f"— _{p.get('rationale', '')}_"
            )
        lines.append("")
    else:
        lines.append("**Patterns defined for this ABB:** none yet — no approved SBB+ZBB combination "
                      "has been governed for this ABB. Do not build against it until one is.\n")

    resilience_rules = _rules_for_abb(catalogue, abb, "Resilience")
    if resilience_rules:
        lines.append("**Resilience is delivered by:**")
        for r in resilience_rules:
            lines.append(f"- {r['managed_service_solution']} _(regulatory basis: {r['regulatory_basis']})_")
        lines.append("")
    else:
        lines.append("**Resilience is delivered by:** no rule defined yet for this ABB.\n")

    security_caps = ["Firewall / Perimeter Security", "Authentication", "Network Access Control", "Segmentation"]
    security_rules = []
    for cap in security_caps:
        security_rules.extend(_rules_for_abb(catalogue, abb, cap))
    if security_rules:
        lines.append("**Security has these considerations:**")
        for r in security_rules:
            lines.append(f"- {r['description']} — {r['managed_service_solution']} _(regulatory basis: {r['regulatory_basis']})_")
        lines.append("")
    else:
        lines.append("**Security has these considerations:** no rules defined yet for this ABB.\n")

    lines.append("**Reference diagram:**\n")
    lines.append(generate_mermaid_diagram(catalogue, abb))

    return "\n".join(lines)
