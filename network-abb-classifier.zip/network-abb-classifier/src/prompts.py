"""
Prompt construction for site classification.

There is no model fine-tuning in this pipeline — Gemini's weights are
fixed. "Training" here means prompt engineering: clear instructions,
a strict output schema (see schema.py), and few-shot examples that show
the model what a correct classification looks like. This file is where
almost all of your iteration effort should go.
"""

SYSTEM_INSTRUCTIONS = """You are classifying a network site's configuration against a
governed architecture hierarchy: Primary Capability -> ABB -> {{SBB, ZBB}} -> VSBB -> CBB.

A single site (e.g. a Branch) is typically met by MULTIPLE ABBs — for example
WAN (transport), User (wired LAN), and WiFi — each with its own SBB and ZBB chains.
A router+switch config pair will usually evidence more than one ABB; do not force
everything into a single ABB match.

Each ABB has TWO independent children — do not conflate them:
- SBB: the solution/transport option (e.g. for WAN: MPLS, Cellular, Satellite, ISP,
  DWDM; for User: Wired LAN)
- ZBB: the zonal boundary control mechanism — anything that restricts inbound or
  outbound communication for that ABB's traffic (e.g. ACL-based, Zonal-firewall,
  Service-mesh-policy). SBB and ZBB can vary independently: two sites may share the
  same SBB while differing on ZBB, or vice versa. Always identify both separately,
  even if one is minimal (e.g. no explicit boundary control found).

WiFi ABB scope limit: you are only given router/switch config. You can see whether
a WiFi VLAN exists and is trunked/allowed on an interface, but you CANNOT see actual
AP or WLC configuration (SSID names, RF settings, wireless-specific security policy)
— that lives on a different source of truth, out of scope for this classification.
For the WiFi ABB: only ever use sbb type "VLAN-Identified", never infer "Autonomous AP"
or "WLC-managed" or similar from indirect signals, and cap confidence at "medium" or
lower for WiFi ABB matches, since the evidence is wired-side only and cannot confirm
actual wireless configuration.

Rules:
1. Identify the primary_capability (e.g. Branch, Campus) the site satisfies.
2. For each ABB evidenced in the config (WAN, User, WiFi, etc.), identify BOTH:
   - sbb: {{type, vsbb, cbb}} — the solution/transport option, its provider/
     architecture-boundary realisation (vsbb), and the versioned config template (cbb)
   - zbb: {{type, vsbb, cbb}} — the boundary control mechanism, its vsbb, and cbb
   Only use providers/vendors/blocks present in the supplied catalogue — do not
   invent or assume one from vendor defaults.
3. Select the band based on the site's actual requirements (user count, link type,
   bandwidth) as evidenced in the config or accompanying metadata — state your
   rationale.
4. Within each ABB match, for each capability in the governed list below, identify
   whether the config implements it, and cite the specific config element as
   evidence. If a capability is not evidenced, omit it rather than guessing.

   Governed capability list: {capability_tags}

5. If part of the config doesn't map confidently to anything in the catalogue,
   list it under unmatched_elements instead of forcing a match.
6. This is classification only. Do not judge whether the configuration is correct,
   optimal, or compliant — that is a separate task, out of scope here.
7. Base every claim only on the catalogue and config provided. Do not use outside
   knowledge of vendor defaults or typical configurations.
8. Check for hardening findings and report them under hardening_observations:
   - ABSOLUTE findings (e.g. Telnet enabled instead of SSH-only, weak/default SNMP
     community strings, no ACL on VTY lines): these are always wrong regardless of
     band. Set type="absolute" and assign a severity.
   - CONTEXTUAL findings (e.g. EIGRP/OSPF redistribution into another protocol
     without a route-map filter): DO NOT judge whether this is a problem — you
     cannot know without seeing the rest of the band. Only detect and report
     whether it's present, with evidence. Set type="contextual" and
     severity="not_applicable". Whether this is actually a divergence gets
     decided later by comparing against other same-band sites, not by you.
"""

# Few-shot examples are the single highest-leverage lever you have for
# accuracy with a Flash-tier model. Populate this with 2-3 real, hand-
# validated examples spanning different bands (e.g. one small/ATM-type
# site, one mid-size branch, one large campus) before running the full
# curated batch. Keep examples concise — full input/output pairs, not
# abbreviated.
FEW_SHOT_EXAMPLES = [
    # {
    #     "config": {...},
    #     "catalogue_slice": {...},
    #     "expected_output": {...},  # the hand-validated correct answer
    # },
]


def build_prompt(config: dict, catalogue_slice: dict) -> str:
    import json
    from src.schema import CAPABILITY_TAGS

    instructions = SYSTEM_INSTRUCTIONS.format(capability_tags=", ".join(CAPABILITY_TAGS))

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    return f"""{instructions}
{examples_block}

CATALOGUE:
{json.dumps(catalogue_slice)}

CONFIG TO CLASSIFY:
{json.dumps(config)}
"""
