"""
Prompt construction for site classification.

There is no model fine-tuning in this pipeline — Gemini's weights are
fixed. "Training" here means prompt engineering: clear instructions,
a strict output schema (see schema.py), and few-shot examples that show
the model what a correct classification looks like. This file is where
almost all of your iteration effort should go.
"""

SYSTEM_INSTRUCTIONS = """You are classifying a network site's configuration against a
governed architecture building block (ABB/SBB/VSBB/CBB) catalogue.

Rules:
1. Match the config to exactly one ABB, SBB, VSBB and CBB from the supplied catalogue.
   Do not invent building blocks that are not in the catalogue.
2. Select the band based on the site's actual requirements (user count, link type,
   bandwidth) as evidenced in the config or accompanying metadata — state your
   rationale.
3. For each capability in the governed list below, identify whether the config
   implements it, and cite the specific config element as evidence. If a capability
   is not evidenced in the config, omit it from the capabilities list rather than
   guessing.

   Governed capability list: {capability_tags}

4. If part of the config doesn't map confidently to anything in the catalogue,
   list it under unmatched_elements instead of forcing a match.
5. This is classification only. Do not judge whether the configuration is correct,
   optimal, or compliant — that is a separate task, out of scope here.
6. Base every claim only on the catalogue and config provided. Do not use outside
   knowledge of vendor defaults or typical configurations.
"""

# Few-shot examples are the single highest-leverage lever you have for
# accuracy with a Flash-tier model. Populate this with 2-3 real, hand-
# validated examples spanning different bands (e.g. one small/ATM-type
# site, one mid-size branch, one large campus) before running the full
# curated batch. Keep examples concise — full input/output pairs, not
# abbreviated.
FEW_SHOT_EXAMPLES = [
    # {
    #     "config": {...},
    #     "catalogue_slice": {...},
    #     "expected_output": {...},  # the hand-validated correct answer
    # },
]


def build_prompt(config: dict, catalogue_slice: dict) -> str:
    import json
    from src.schema import CAPABILITY_TAGS

    instructions = SYSTEM_INSTRUCTIONS.format(capability_tags=", ".join(CAPABILITY_TAGS))

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    return f"""{instructions}
{examples_block}

CATALOGUE:
{json.dumps(catalogue_slice)}

CONFIG TO CLASSIFY:
{json.dumps(config)}
"""
