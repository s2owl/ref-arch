"""
Prompt construction for site classification.

There is no model fine-tuning in this pipeline — Gemini's weights are
fixed. "Training" here means prompt engineering: clear instructions,
a strict output schema (see schema.py), matching hints from the
capability taxonomy (config_indicators), and few-shot examples. This
file is where almost all of your iteration effort should go.
"""
import json
from pathlib import Path

CATALOGUE_DIR = Path(__file__).parent.parent / "data" / "catalogue"

SYSTEM_INSTRUCTIONS = """You are classifying a network site's configuration against a
governed architecture hierarchy: Primary Capability -> ABB -> {{SBB, ZBB}} -> VSBB -> CBB.

A single site (e.g. a Branch) is typically met by MULTIPLE ABBs — for example
WAN (transport), User (wired LAN), and WiFi — each with its own SBB and ZBB chains.
A router+switch config pair will usually evidence more than one ABB; do not force
everything into a single ABB match.

Each ABB has TWO independent children — do not conflate them:
- SBB: the SOLUTION — the realisation of the capability, HOW something is done
  (e.g. for WAN: MPLS, Cellular, Satellite, ISP, DWDM; for User: Wired LAN)
- ZBB: the ZONE BOUNDARY — how traffic is isolated for that ABB (ACL, VLAN,
  firewall, service-mesh policy). SBB and ZBB can vary independently: two sites
  may share the same SBB while differing on ZBB, or vice versa. Always identify
  both separately, even if one is minimal (e.g. no explicit boundary control found).
- VSBB (within sbb/zbb): the VENDOR VERSIONING of the solution — e.g. "Cisco 3750",
  not just "Cisco". Be as specific as the config/catalogue evidence allows.
- CBB (within sbb/zbb): the specific CONFIG that achieves the solution.

WiFi ABB scope: evidence for WiFi typically splits across TWO sources that must
BOTH be checked before concluding a capability is absent — cloud/controller config
(e.g. Mist WLAN/SSID policy) covering SSID-to-VLAN mapping, auth mode, and
per-SSID policy; and the wired anchor config (e.g. EX/switch port config) covering
the physical trunk/access port carrying WiFi VLANs. If you are only given
router/switch config with no cloud/controller config, you can only see the wired
anchor — cap confidence at "medium" or lower and do not infer cloud-side
capabilities (SSID auth mode, RF settings, roaming behaviour) from wired
evidence alone. A trunk with no per-SSID VLAN policy visible is "VLAN-tag-only"
— note this distinction, don't assume the fuller capability is present.

MATURITY, not just presence: some capabilities exist on a maturity band rather
than a strict pass/fail — e.g. WiFi auth with PSK-only vs RADIUS-bound is a
lower-maturity band, not a failure; record which band is evidenced rather than
treating a lower band as "capability absent". Note the maturity level in the
evidence field where relevant (e.g. "PSK-only, no RADIUS binding evidenced").

Rules:
1. Identify the primary_capability (e.g. Branch, Campus) the site satisfies.
2. For each ABB evidenced in the config (WAN, User, WiFi, etc.), identify BOTH:
   - sbb: {{type, vsbb, cbb}} — the solution, its vendor-versioned realisation (vsbb),
     and the config that achieves it (cbb)
   - zbb: {{type, vsbb, cbb}} — the zone boundary mechanism, its vsbb, and cbb
   Only use providers/vendors/blocks present in the supplied catalogue — do not
   invent or assume one from vendor defaults.
3. Select the band based on the site's actual requirements (user count, link type,
   bandwidth) as evidenced in the config or accompanying metadata — state your
   rationale.
4. Within each ABB match, for each capability in the governed list below, identify
   whether the config implements it, and cite the specific config element as
   evidence. If a capability is not evidenced, omit it rather than guessing.
   Use the CAPABILITY INDICATORS reference below as matching hints — concrete
   syntax/directives that typically evidence each capability — but this is a
   hint list, not exhaustive; use judgement for config that doesn't literally
   match an indicator string but clearly serves the same function.

   Governed capability list: {capability_tags}

   {capability_indicators}

5. If part of the config doesn't map confidently to anything in the catalogue,
   list it under unmatched_elements instead of forcing a match.
6. This is classification only. Do not judge whether the configuration is correct,
   optimal, or compliant — that is a separate task, out of scope here.
7. Base every claim only on the catalogue and config provided. Do not use outside
   knowledge of vendor defaults or typical configurations.
8. Check for hardening findings and report them under hardening_observations,
   using the GOVERNED HARDENING CHECKS list below:
   - ABSOLUTE findings: always wrong regardless of band. Set type="absolute"
     and assign a severity.
   - CONTEXTUAL findings: correctness depends on the band's own baseline, NOT
     judged here. Only detect and report whether present, with evidence. Set
     type="contextual" and severity="not_applicable". Whether this is actually
     a divergence gets decided later by comparing against other same-band
     sites, not by you.

   {hardening_checks_block}
"""

# Few-shot examples are the single highest-leverage lever you have for
# accuracy with a Flash-tier model. Populate this with 2-3 real, hand-
# validated examples spanning different bands (e.g. one small/ATM-type
# site, one mid-size branch, one large campus) before running the full
# curated batch. Keep examples concise — full input/output pairs, not
# abbreviated.
FEW_SHOT_EXAMPLES = [
    # {
    #     "config": {...},
    #     "catalogue_slice": {...},
    #     "expected_output": {...},  # the hand-validated correct answer
    # },
]


def _build_capability_indicators_block() -> str:
    """
    Loads data/catalogue/capability_taxonomy.json (if present) and
    formats each capability's config_indicators as a compact reference
    the model can use as matching hints. Falls back to an empty string
    if the taxonomy file doesn't exist yet — this is additive, not
    required for the pipeline to run.
    """
    path = CATALOGUE_DIR / "capability_taxonomy.json"
    if not path.exists():
        return ""

    taxonomy = json.loads(path.read_text())
    lines = ["CAPABILITY INDICATORS (matching hints, by zone):"]
    for zone in taxonomy.get("zones", []):
        zone_name = zone.get("zone", "")
        lines.append(f"\n{zone_name}:")
        for cap in zone.get("capabilities", []):
            indicators = ", ".join(cap.get("config_indicators", []))
            line = f"  - {cap['capability']}: {indicators}"
            if cap.get("maturity_flag"):
                line += f" [maturity note: {cap['maturity_flag']}]"
            if cap.get("risk_flag"):
                line += f" [risk note: {cap['risk_flag']}]"
            lines.append(line)
        if zone.get("platform_note"):
            lines.append(f"  (platform note: {zone['platform_note']})")

    return "\n".join(lines)


def _build_hardening_checks_block() -> str:
    """
    Loads hardening_checks from data/catalogue/catalogue.json (falling
    back to the example if the real one doesn't exist yet) and formats
    the absolute/contextual lists for the prompt. Dynamic rather than
    hardcoded so the prompt always matches what's actually governed.
    """
    path = CATALOGUE_DIR / "catalogue.json"
    if not path.exists():
        path = CATALOGUE_DIR / "catalogue.example.json"
    if not path.exists():
        return ""

    catalogue = json.loads(path.read_text())
    checks = catalogue.get("hardening_checks", {})
    if not checks:
        return ""

    lines = ["GOVERNED HARDENING CHECKS:", "\nAbsolute (always wrong):"]
    for c in checks.get("absolute", []):
        lines.append(f"  - {c['finding']} [severity: {c['severity']}]")
    lines.append("\nContextual (detect only, do not judge):")
    for c in checks.get("contextual", []):
        lines.append(f"  - {c['finding']}")

    return "\n".join(lines)


def build_prompt(config: dict, catalogue_slice: dict) -> str:
    from src.schema import CAPABILITY_TAGS

    indicators_block = _build_capability_indicators_block()
    hardening_block = _build_hardening_checks_block()
    instructions = SYSTEM_INSTRUCTIONS.format(
        capability_tags=", ".join(CAPABILITY_TAGS),
        capability_indicators=indicators_block,
        hardening_checks_block=hardening_block,
    )

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    return f"""{instructions}
{examples_block}

CATALOGUE:
{json.dumps(catalogue_slice)}

CONFIG TO CLASSIFY:
{json.dumps(config)}
"""
