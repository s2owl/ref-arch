"""
Prompt construction for site classification.

There is no model fine-tuning in this pipeline — Gemini's weights are
fixed. "Training" here means prompt engineering: clear instructions,
a strict output schema (see schema.py), matching hints from the
capability taxonomy (config_indicators), and few-shot examples. This
file is where almost all of your iteration effort should go.
"""
import json
from pathlib import Path

CATALOGUE_DIR = Path(__file__).parent.parent / "data" / "catalogue"

SYSTEM_INSTRUCTIONS = """You are classifying a network site's configuration against a
governed architecture hierarchy: Primary Capability -> ABB -> {{SBB, ZBB}} -> VSBB -> CBB.

A single site (e.g. a Branch) is typically met by MULTIPLE ABBs — for example
WAN (transport), User (wired LAN), and WiFi — each with its own SBB and ZBB chains.
A router+switch config pair will usually evidence more than one ABB; do not force
everything into a single ABB match.

INVENTORY, not just presence: one ABB can have MULTIPLE distinct solutions. If
User LAN genuinely evidences separate, independently-realised solutions — e.g.
Routing (via one protocol/vendor combination), Switching, and QoS as distinct
mechanisms with their own config — report them as SEPARATE entries in
abb_matches, all sharing the same "abb" value (e.g. three entries with
abb="User": one for Routing, one for Switching, one for QoS), each with its
own sbb/zbb/capabilities. Do not collapse genuinely distinct solutions into
one generic entry just because they share an ABB.

Where evidenced, populate vsbb_version (the OS/code version, e.g. "IOS-XE
17.3") — config can differ meaningfully between versions of the same
vendor+protocol, and this makes that visible. Omit if not evidenced; do not guess.

For ZBB specifically, populate effective_restriction — the actual real-world
restriction the boundary enforces (e.g. "Management access restricted to
10.100.1.0/24 only", "VLAN 10 cannot reach VLAN 20"), not just the mechanism
name. Ground this in what's observed in the config, never inferred intent.

Each ABB has TWO independent children — do not conflate them:
- SBB: the SOLUTION — WHAT delivers on the capability (e.g. Routing, QoS,
  MPLS, WiFi 6; for WAN: MPLS, Cellular, Satellite, ISP, DWDM; for User: Wired LAN)
- ZBB: the ZONE BOUNDARY — the segmentation boundaries actually OBSERVED IN
  THE CONFIG for that ABB (ACL, VLAN, firewall, service-mesh policy). Ground
  this in evidence you can point to, not an assumed default. SBB and ZBB can
  vary independently: two sites may share the same SBB while differing on
  ZBB, or vice versa. Always identify both separately, even if one is
  minimal (e.g. no explicit boundary control found).
- VSBB (within sbb/zbb): the vendor-specific PROTOCOL/METHOD that realises
  the SBB — e.g. for a Routing SBB: "Cisco EIGRP" vs "Juniper iBGP". This is
  NOT a hardware model — it's the vendor's characteristic way of implementing
  the SBB. Be as specific as the config/catalogue evidence allows.
- CBB (within sbb/zbb): the specific CONFIG that achieves the solution.

WiFi ABB scope: evidence for WiFi typically splits across TWO sources that must
BOTH be checked before concluding a capability is absent — cloud/controller config
(e.g. Mist WLAN/SSID policy) covering SSID-to-VLAN mapping, auth mode, and
per-SSID policy; and the wired anchor config (e.g. EX/switch port config) covering
the physical trunk/access port carrying WiFi VLANs. If you are only given
router/switch config with no cloud/controller config, you can only see the wired
anchor — cap confidence at "medium" or lower and do not infer cloud-side
capabilities (SSID auth mode, RF settings, roaming behaviour) from wired
evidence alone. A trunk with no per-SSID VLAN policy visible is "VLAN-tag-only"
— note this distinction, don't assume the fuller capability is present.

MATURITY, not just presence: some capabilities exist on a maturity band rather
than a strict pass/fail — e.g. WiFi auth with PSK-only vs RADIUS-bound is a
lower-maturity band, not a failure; record which band is evidenced rather than
treating a lower band as "capability absent". Note the maturity level in the
evidence field where relevant (e.g. "PSK-only, no RADIUS binding evidenced").

Rules:
1. Identify the primary_capability (e.g. Branch, Campus) the site satisfies.
2. For each ABB evidenced in the config (WAN, User, WiFi, etc.), identify BOTH:
   - sbb: {{type, vsbb, cbb}} — the solution, its vendor-versioned realisation (vsbb),
     and the config that achieves it (cbb)
   - zbb: {{type, vsbb, cbb}} — the zone boundary mechanism, its vsbb, and cbb
   Only use providers/vendors/blocks present in the supplied catalogue — do not
   invent or assume one from vendor defaults.
3. Select the band based on the site's actual requirements (user count, link type,
   bandwidth) as evidenced in the config or accompanying metadata — state your
   rationale.
4. Within each ABB match, for each capability in the governed list below, identify
   whether the config implements it, and cite the specific config element as
   evidence. If a capability is not evidenced, omit it rather than guessing.
   Use the CAPABILITY INDICATORS reference below as matching hints — concrete
   syntax/directives that typically evidence each capability — but this is a
   hint list, not exhaustive; use judgement for config that doesn't literally
   match an indicator string but clearly serves the same function.

   Governed capability list: {capability_tags}

   {capability_indicators}

5. If part of the config doesn't map confidently to anything in the catalogue,
   list it under unmatched_elements instead of forcing a match.
6. This is classification only. Do not judge whether the configuration is correct,
   optimal, or compliant — that is a separate task, out of scope here.
7. Base every claim only on the catalogue and config provided. Do not use outside
   knowledge of vendor defaults or typical configurations.
8. Check for hardening findings and report them under hardening_observations,
   using the GOVERNED HARDENING CHECKS list below:
   - ABSOLUTE findings: always wrong regardless of band. Set type="absolute"
     and assign a severity.
   - CONTEXTUAL findings: correctness depends on the band's own baseline, NOT
     judged here. Only detect and report whether present, with evidence. Set
     type="contextual" and severity="not_applicable". Whether this is actually
     a divergence gets decided later by comparing against other same-band
     sites, not by you.

   {hardening_checks_block}
"""

# Few-shot examples are the single highest-leverage lever you have for
# accuracy with a Flash-tier model. Populate this with 2-3 real, hand-
# validated examples spanning different bands (e.g. one small/ATM-type
# site, one mid-size branch, one large campus) before running the full
# curated batch. Keep examples concise — full input/output pairs, not
# abbreviated.
FEW_SHOT_EXAMPLES = [
    {
        "config": {'site_id': 'BR-EXAMPLE-01', 'site_type': 'Branch', 'devices': [{'hostname': 'BR-EXAMPLE-01-RTR', 'role': 'router', 'interfaces': [{'name': 'Gi0/1.10', 'type': 'sub-interface', 'encapsulation': 'dot1q', 'vlan': 10, 'ip': '10.10.10.2/24', 'ip_helper': '10.100.2.10', 'hsrp_group': 10, 'hsrp_priority': 110}, {'name': 'Gi0/1.20', 'type': 'sub-interface', 'encapsulation': 'dot1q', 'vlan': 20, 'ip': '10.10.20.2/24', 'ip_helper': '10.100.2.10', 'hsrp_group': 20, 'hsrp_priority': 110}, {'name': 'Gi0/1.30', 'type': 'sub-interface', 'encapsulation': 'dot1q', 'vlan': 30, 'ip': '10.10.30.2/24', 'ip_helper': '10.100.2.10', 'hsrp_group': 30}, {'name': 'Gi0/0', 'type': 'wan', 'ip': '172.16.1.2/30', 'mpls_enabled': True, 'qos_policy': 'WAN-QOS-OUT'}], 'routing': {'protocols': ['OSPF', 'BGP'], 'ospf': {'process_id': 1, 'area': 0, 'networks': ['10.10.10.0/24', '10.10.20.0/24', '10.10.30.0/24']}, 'bgp': {'asn': 65001, 'neighbor': '172.16.1.1', 'neighbor_asn': 65000, 'address_family': 'vpnv4'}}, 'mpls': {'enabled': True, 'role': 'CE', 'vpn_type': 'L3VPN'}, 'qos': {'policy_name': 'WAN-QOS-OUT', 'classes': [{'name': 'VOICE', 'match': 'dscp ef', 'treatment': 'priority', 'percent': 20}, {'name': 'VIDEO', 'match': 'dscp af41', 'treatment': 'bandwidth', 'percent': 20}]}, 'acl': [{'name': 'MGMT-ACCESS', 'type': 'extended', 'purpose': 'management-restriction', 'applied_to': 'vty 0 4'}], 'snmp': {'version': 3, 'security_level': 'authPriv', 'auth': 'sha', 'priv': 'aes128'}}, {'hostname': 'BR-EXAMPLE-01-SW', 'role': 'switch', 'vlans': [{'id': 10, 'name': 'DATA'}, {'id': 20, 'name': 'VOICE'}, {'id': 30, 'name': 'WIFI-CORP'}], 'dot1x': {'enabled': True, 'authentication_server': 'radius', 'radius_server': 'ISE-PSN', 'radius_host': '10.100.1.20', 'applied_interfaces': 'Gi1/0/1-24'}, 'voice_vlan': {'vlan': 20, 'applied_interfaces': 'Gi1/0/1-24'}, 'wifi': {'trunk_interface': 'Gi1/0/48', 'allowed_vlans': [10, 20, 30], 'description': 'trunk to autonomous AP / WLC uplink'}, 'qos': {'trust': 'dscp', 'auto_qos_voip': True}, 'acl': [{'name': 'GUEST-RESTRICT', 'type': 'extended', 'purpose': 'guest-isolation', 'applied_to': 'Gi1/0/25-30'}], 'snmp': {'version': 3, 'security_level': 'authPriv', 'auth': 'sha', 'priv': 'aes128'}}]},
        "catalogue_slice": {'primary_capabilities': {'Branch': {'description': 'Small-to-mid site, met by multiple ABBs', 'abbs': ['WAN', 'User', 'WiFi']}, 'Campus': {'description': 'Large multi-building site, met by multiple ABBs', 'abbs': ['WAN', 'User', 'WiFi']}}, 'abbs': {'WAN': {'description': "Transport connectivity meeting the primary capability's connectivity requirement", 'sbb_types': ['MPLS', 'Cellular', 'Satellite', 'ISP', 'DWDM'], 'zbb_types': ['ACL-based', 'Zonal-firewall', 'DDoS-scrubbing']}, 'User': {'description': "Wired LAN access meeting the primary capability's user-connectivity requirement", 'sbb_types': ['Wired LAN'], 'zbb_types': ['ACL-based', 'Zonal-firewall']}, 'WiFi': {'description': "Wireless access meeting the primary capability's wireless-connectivity requirement. WAVE ONE SCOPE NOTE: only VLAN-level evidence from the switch/router config (trunk allowed-vlan, VLAN naming) is used — WLC/AP management config is a separate source of truth and is out of scope until integrated.", 'sbb_types': ['VLAN-Identified'], 'zbb_types': ['VLAN-ACL-isolation', 'Zonal-firewall']}}},
        "expected_output": {'site_id': 'BR-EXAMPLE-01', 'primary_capability': 'Branch', 'band': 'branch-mid-mpls-sdwan', 'band_rationale': '120 users, dual-homed MPLS primary with SD-WAN failover, evidenced by BGP VPNv4 peering plus HSRP dual-uplink config', 'abb_matches': [{'abb': 'WAN', 'sbb': {'type': 'MPLS', 'vsbb': 'VSBB-WAN-MPLS-001', 'cbb': 'CBB-CISCO-RTG-014-v1'}, 'zbb': {'type': 'ACL-based', 'vsbb': 'VSBB-WAN-ZBB-ACL-003', 'cbb': 'CBB-CISCO-WANACL-004-v1'}, 'capabilities': [{'capability': 'Routing', 'evidence': 'router bgp 65001 / address-family vpnv4 / neighbor 172.16.1.1 activate', 'confidence': 'high'}, {'capability': 'Resilience', 'evidence': 'standby 10/20/30 groups with priority 110 and preempt', 'confidence': 'high'}, {'capability': 'Path Selection / QoS', 'evidence': 'policy-map WAN-QOS-OUT with VOICE priority and VIDEO bandwidth classes', 'confidence': 'high'}, {'capability': 'Firewall / Perimeter Security', 'evidence': 'ip access-list extended MGMT-ACCESS applied to vty 0 4', 'confidence': 'high'}]}, {'abb': 'User', 'sbb': {'type': 'Wired LAN', 'vsbb': 'VSBB-USER-LAN-001', 'cbb': 'CBB-CISCO-LAN-001-v1'}, 'zbb': {'type': 'ACL-based', 'vsbb': 'VSBB-USER-ZBB-ACL-001', 'cbb': 'CBB-CISCO-SEG-008-v1'}, 'capabilities': [{'capability': 'Authentication', 'evidence': 'dot1x system-auth-control / authentication port-control auto on Gi1/0/1-24', 'confidence': 'high'}, {'capability': 'Network Access Control', 'evidence': 'aaa authentication dot1x default group radius, radius server ISE-PSN', 'confidence': 'high'}, {'capability': 'Segmentation', 'evidence': 'vlan 10/20/30 with switchport access vlan assignment per interface range', 'confidence': 'medium'}]}, {'abb': 'WiFi', 'sbb': {'type': 'VLAN-Identified', 'vsbb': 'VSBB-WIFI-VLAN-001', 'cbb': 'CBB-CISCO-WIFI-VLAN-001-v1'}, 'zbb': {'type': 'VLAN-ACL-isolation', 'vsbb': 'VSBB-WIFI-ZBB-VLAN-004', 'cbb': 'CBB-CISCO-WIFIZBB-006-v1'}, 'capabilities': [{'capability': 'WiFi/RF Management', 'evidence': 'interface Gi1/0/48 trunk to AP, switchport trunk allowed vlan 10,20,30 including WIFI-CORP', 'confidence': 'medium'}, {'capability': 'Segmentation', 'evidence': 'GUEST-RESTRICT ACL on Gi1/0/25-30 denying access to DATA/VOICE VLANs', 'confidence': 'high'}]}], 'unmatched_elements': [], 'hardening_observations': [{'finding': 'Telnet enabled on VTY lines', 'type': 'absolute', 'detected': False, 'evidence': 'line vty 0 4 / transport input ssh — Telnet not present', 'severity': 'not_applicable'}, {'finding': 'EIGRP redistribution without route-map filter', 'type': 'contextual', 'detected': True, 'evidence': 'redistribute static under router eigrp, no route-map referenced', 'severity': 'not_applicable'}]},
    },
    # Add 1-2 more spanning different bands (e.g. a small/ATM-type site,
    # a large campus) once you have hand-validated real examples — this
    # single one is a starting point, not the final state.
]


def _build_capability_indicators_block() -> str:
    """
    Loads data/catalogue/capability_taxonomy.json (if present) and
    formats each capability's config_indicators as a compact reference
    the model can use as matching hints. Falls back to an empty string
    if the taxonomy file doesn't exist yet — this is additive, not
    required for the pipeline to run.
    """
    path = CATALOGUE_DIR / "capability_taxonomy.json"
    if not path.exists():
        return ""

    taxonomy = json.loads(path.read_text())
    lines = ["CAPABILITY INDICATORS (matching hints, by zone):"]
    for zone in taxonomy.get("zones", []):
        zone_name = zone.get("zone", "")
        lines.append(f"\n{zone_name}:")
        for cap in zone.get("capabilities", []):
            indicators = ", ".join(cap.get("config_indicators", []))
            line = f"  - {cap['capability']}: {indicators}"
            if cap.get("maturity_flag"):
                line += f" [maturity note: {cap['maturity_flag']}]"
            if cap.get("risk_flag"):
                line += f" [risk note: {cap['risk_flag']}]"
            lines.append(line)
        if zone.get("platform_note"):
            lines.append(f"  (platform note: {zone['platform_note']})")

    return "\n".join(lines)


def _build_hardening_checks_block() -> str:
    """
    Loads hardening_checks from data/catalogue/catalogue.json (falling
    back to the example if the real one doesn't exist yet) and formats
    the absolute/contextual lists for the prompt. Dynamic rather than
    hardcoded so the prompt always matches what's actually governed.
    """
    path = CATALOGUE_DIR / "catalogue.json"
    if not path.exists():
        path = CATALOGUE_DIR / "catalogue.example.json"
    if not path.exists():
        return ""

    catalogue = json.loads(path.read_text())
    checks = catalogue.get("hardening_checks", {})
    if not checks:
        return ""

    lines = ["GOVERNED HARDENING CHECKS:", "\nAbsolute (always wrong):"]
    for c in checks.get("absolute", []):
        lines.append(f"  - {c['finding']} [severity: {c['severity']}]")
    lines.append("\nContextual (detect only, do not judge):")
    for c in checks.get("contextual", []):
        lines.append(f"  - {c['finding']}")

    return "\n".join(lines)


def build_prompt(config: dict, catalogue_slice: dict) -> str:
    from src.schema import CAPABILITY_TAGS

    indicators_block = _build_capability_indicators_block()
    hardening_block = _build_hardening_checks_block()
    instructions = SYSTEM_INSTRUCTIONS.format(
        capability_tags=", ".join(CAPABILITY_TAGS),
        capability_indicators=indicators_block,
        hardening_checks_block=hardening_block,
    )

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    return f"""{instructions}
{examples_block}

CATALOGUE:
{json.dumps(catalogue_slice)}

CONFIG TO CLASSIFY:
{json.dumps(config)}
"""
