"""
Pattern derivation — the step this pipeline was always meant to have
but hadn't built: turning accumulated real classifications into
CANDIDATE patterns for the Principal Architect to review and approve.

This does NOT write to data/catalogue/catalogue.json directly and never
will — pattern approval is a governance decision, not something this
script gets to make (same principle as vendor/VSBB approval sitting
with the PA throughout this build). It proposes; a human approves.

Reuses the exact same consistency logic as run_report.py
(compute_block_consistency) — the canonical (majority) SBB+ZBB per ABB
in a band, subject to the same minimum-sample-size threshold as
everywhere else in this pipeline (>= 4 sites).

Usage:
    python -m src.derive_patterns
"""
import json
from pathlib import Path

from src.run_report import load_all_results, group_by_band, compute_block_consistency
from src.hardening import MIN_SAMPLE_SIZE

RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"
OUTPUT_DIR = Path(__file__).parent.parent / "output"


def derive_candidate_pattern(band: str, band_results: list) -> dict:
    """
    Builds one candidate pattern_catalogue entry for a band from its
    real, already-classified sites — the canonical (majority) SBB+ZBB
    combination per ABB.
    """
    consistency = compute_block_consistency(band_results)

    bundle = {}
    confidence_notes = []
    for abb, blocks in consistency.items():
        if "sbb" not in blocks or "zbb" not in blocks:
            continue  # incomplete data for this ABB, skip rather than guess
        sbb_data = blocks["sbb"]
        zbb_data = blocks["zbb"]

        # Need the type (not just CBB) for the bundle — pull from the
        # first site matching the canonical CBB.
        sbb_type = next(
            (m["sbb"]["type"] for r in band_results for m in r.get("abb_matches", [])
             if m["abb"] == abb and m["sbb"]["cbb"] == sbb_data["canonical_cbb"]),
            None
        )
        zbb_type = next(
            (m["zbb"]["type"] for r in band_results for m in r.get("abb_matches", [])
             if m["abb"] == abb and m["zbb"]["cbb"] == zbb_data["canonical_cbb"]),
            None
        )

        bundle[abb] = {
            "sbb_type": sbb_type,
            "sbb_cbb": sbb_data["canonical_cbb"],
            "zbb_type": zbb_type,
            "zbb_cbb": zbb_data["canonical_cbb"],
        }
        confidence_notes.append(
            f"{abb}: SBB {sbb_data['consistency_pct']}% ({sbb_data['sites_matching']}/{sbb_data['total_sites']}), "
            f"ZBB {zbb_data['consistency_pct']}% ({zbb_data['sites_matching']}/{zbb_data['total_sites']})"
        )

    return {
        "pattern_id": f"PTN-CANDIDATE-{band.upper().replace('-', '_')}-v1",
        "band": band,
        "status": "PROPOSED — requires PA review and approval before adding to catalogue.json",
        "derived_from": f"{len(band_results)} classified site(s): {', '.join(r['site_id'] for r in band_results)}",
        "confidence_by_abb": confidence_notes,
        "bundle": bundle,
    }


def derive_all_patterns() -> list:
    results = load_all_results()
    grouped = group_by_band(results)

    candidates = []
    for band, band_results in grouped.items():
        if len(band_results) < MIN_SAMPLE_SIZE:
            print(f"Skipping '{band}': only {len(band_results)} site(s), "
                  f"below minimum sample size ({MIN_SAMPLE_SIZE}) to derive a pattern.")
            continue
        candidates.append(derive_candidate_pattern(band, band_results))

    return candidates


if __name__ == "__main__":
    candidates = derive_all_patterns()

    if not candidates:
        print("\nNo bands have enough classified sites yet to derive a pattern.")
    else:
        print(f"\n{len(candidates)} candidate pattern(s) derived — REVIEW BEFORE APPROVING:\n")
        for c in candidates:
            print(json.dumps(c, indent=2))
            print()

    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / "candidate-patterns.json"
    out_path.write_text(json.dumps(candidates, indent=2))
    print(f"Saved to {out_path}")
    print("\nThese are PROPOSALS. Review each one, then manually add approved")
    print("entries to data/catalogue/catalogue.json's pattern_catalogue — this")
    print("script will never write to the catalogue directly.")
