"""
Loads normalised site configs and catalogue slices from data/.

Assumes configs have already been parsed from raw device output into
structured JSON by a separate, deterministic parsing step (not part of
this repo) — this loader does not do any config parsing itself.
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def load_site_config(site_id: str) -> dict:
    path = DATA_DIR / "sites" / f"{site_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"No config found for site '{site_id}' at {path}")
    return json.loads(path.read_text())


def load_catalogue_slice(band: str = None) -> dict:
    """
    Loads the ABB/SBB/VSBB/CBB catalogue. If band is provided, filters
    to just that band's entries — keep this slice small; don't pass the
    whole estate catalogue into every call.
    """
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        raise FileNotFoundError(f"No catalogue found at {path}")
    catalogue = json.loads(path.read_text())
    if band:
        return {k: v for k, v in catalogue.items() if v.get("band") == band}
    return catalogue


def list_curated_sites() -> list:
    """Returns site_ids for every config file present in data/sites/."""
    return [p.stem for p in (DATA_DIR / "sites").glob("*.json")]
