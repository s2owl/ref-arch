"""
Loads site configs and catalogue slices from data/.

Accepts TWO formats in data/sites/, auto-detected by extension:
  - <site_id>.json — pre-normalised, structured config (the "ideal"
    shape, matching examples/normalized-sites/BR-EXAMPLE-01.json)
  - <site_id>.cfg or <site_id>.txt — raw device config, pasted or
    exported as-is. No manual conversion needed — this is embedded
    directly in the prompt as raw text, and the model is instructed to
    parse it itself. Lower structural guarantee than pre-normalised
    JSON (the model is doing more work), but removes the requirement to
    hand-convert every site before you can classify it.

Returns either a dict (JSON case) or a str (raw case) — callers must
handle both, since they get embedded into the prompt differently.
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def load_site_config(site_id: str):
    """
    Returns a dict for pre-normalised JSON configs, or a str for raw
    config text. Checks .json first, then falls back to .cfg / .txt.
    """
    json_path = DATA_DIR / "sites" / f"{site_id}.json"
    if json_path.exists():
        return json.loads(json_path.read_text())

    for ext in (".cfg", ".txt"):
        raw_path = DATA_DIR / "sites" / f"{site_id}{ext}"
        if raw_path.exists():
            return raw_path.read_text()

    raise FileNotFoundError(
        f"No config found for site '{site_id}' — checked "
        f"data/sites/{site_id}.json, .cfg, and .txt"
    )


def is_raw_config(config) -> bool:
    """True if load_site_config returned raw text rather than parsed JSON."""
    return isinstance(config, str)


def load_catalogue_slice(band: str = None) -> dict:
    """
    Loads the ABB/SBB/VSBB/CBB catalogue. If band is provided, filters
    to just that band's entries — keep this slice small; don't pass the
    whole estate catalogue into every call.
    """
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        raise FileNotFoundError(f"No catalogue found at {path}")
    catalogue = json.loads(path.read_text())
    if band:
        return {k: v for k, v in catalogue.items() if v.get("band") == band}
    return catalogue


def list_curated_sites() -> list:
    """Returns site_ids for every config file present in data/sites/ (any accepted format)."""
    sites_dir = DATA_DIR / "sites"
    ids = set()
    for ext in ("*.json", "*.cfg", "*.txt"):
        ids.update(p.stem for p in sites_dir.glob(ext))
    return sorted(ids)
