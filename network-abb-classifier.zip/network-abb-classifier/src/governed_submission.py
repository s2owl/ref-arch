"""
Governed Architecture Submission.

Different from abb_documentation.py in three deliberate ways:
1. Capability-level, not per-ABB — shows the WHOLE stack (WAN + User +
   WiFi) that jointly delivers a Primary Capability, in one document,
   because stakeholders need to see how the pieces interoperate, not
   review each ABB in isolation.
2. Stops at VSBB — no CBB detail. Config specifics are engineering's
   layer (Outcome 9); this submission is architecture's approval
   artefact, not an implementation reference.
3. States approval status explicitly per ABB, and separates what's
   PA-owned (ABB/SBB/ZBB/VSBB — the architecture) from what's
   engineering-owned (CBB — the solution/config realisation), matching
   the existing Outcome 9 ownership split.

Deterministic — no AI call, reads directly from the catalogue.
"""
import json
import datetime
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def _load_catalogue() -> dict:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        raise FileNotFoundError(
            f"No catalogue found at {path}. This tool will not silently fall "
            f"back to example/fabricated data — copy "
            f"data/catalogue/catalogue.example.json to catalogue.json to "
            f"explicitly start from illustrative data, or set up your real "
            f"governed catalogue first."
        )
    return json.loads(path.read_text())


def _patterns_for_abb(catalogue: dict, abb: str, primary_capability: str = None) -> list:
    patterns = [p for p in catalogue.get("pattern_catalogue", []) if abb in p.get("bundle", {})]
    if primary_capability:
        # Bands are named with a primary-capability prefix (branch-*, campus-*)
        # throughout this catalogue — filter on that so a Branch pattern never
        # gets shown as approved for Campus just because they share an ABB name.
        prefix = primary_capability.lower()
        patterns = [p for p in patterns if p.get("band", "").startswith(prefix)]
    return patterns


def _providers_for_abb(catalogue: dict, abb: str) -> list:
    providers = {e["provider"] for e in catalogue.get("sbb_catalogue", []) if e["abb"] == abb and e.get("approved")}
    return sorted(providers)


def _provider_for(catalogue: dict, abb: str, block_type: str, catalogue_key: str) -> str:
    for entry in catalogue.get(catalogue_key, []):
        if entry["abb"] == abb and entry.get("sbb_type", entry.get("zbb_type")) == block_type:
            return entry.get("provider", "unspecified")
    return "unspecified"


def _capability_diagram(catalogue: dict, primary_capability: str, abbs: list) -> str:
    """Cross-ABB diagram, down to VSBB — no CBB nodes, no config detail."""
    lines = ["```mermaid", "graph TD", f'PC["{primary_capability}"]']
    for abb in abbs:
        abb_node = f"ABB_{abb}"
        lines.append(f'PC --> {abb_node}["{abb} (ABB)"]')
        patterns = _patterns_for_abb(catalogue, abb, primary_capability)
        if not patterns:
            lines.append(f'{abb_node} --> {abb_node}_pending["No approved pattern yet"]')
            continue
        for p in patterns:
            bundle = p["bundle"][abb]
            sbb_node = f"{abb_node}_{bundle['sbb_type']}".replace(" ", "_").replace("-", "_")
            zbb_node = f"{abb_node}_{bundle['zbb_type']}".replace(" ", "_").replace("-", "_")
            sbb_provider = _provider_for(catalogue, abb, bundle["sbb_type"], "sbb_catalogue")
            zbb_provider = _provider_for(catalogue, abb, bundle["zbb_type"], "zbb_catalogue")
            lines.append(f'{abb_node} --> {sbb_node}["SBB<br/>{bundle["sbb_type"]}"]')
            lines.append(f'{sbb_node} --> {sbb_node}_V["VSBB<br/>{sbb_provider}"]')
            lines.append(f'{abb_node} --> {zbb_node}["ZBB<br/>{bundle["zbb_type"]}"]')
            lines.append(f'{zbb_node} --> {zbb_node}_V["VSBB<br/>{zbb_provider}"]')
    lines.append("```")
    return "\n".join(lines)


def generate_governed_submission(primary_capability: str) -> str:
    catalogue = _load_catalogue()
    pc_def = catalogue.get("primary_capabilities", {}).get(primary_capability)
    if not pc_def:
        return f"# {primary_capability} — not found in catalogue. Nothing to submit."

    abbs = pc_def.get("abbs", [])
    today = datetime.date.today().isoformat()

    lines = [
        f"# Governed Architecture Submission — {primary_capability}",
        f"_Prepared {today} — for stakeholder review and sign-off. No engineering config detail "
        f"included; that layer is engineering-owned (CBB) and available on request._",
        "",
        f"## What is being submitted",
        f"The **{primary_capability}** primary capability is delivered by the coordinated "
        f"interoperation of {len(abbs)} architecture building blocks: **{', '.join(abbs)}**. "
        f"Each is independently governed, with its own approved solution (SBB), boundary "
        f"control (ZBB), and approved provider (VSBB) — shown below at the architecture level "
        f"only.",
        "",
        "## How these ABBs interoperate",
        f"No single ABB delivers {primary_capability} alone — each covers a distinct "
        f"connectivity concern, and together they form the complete, governed stack:",
    ]

    interop_notes = {
        "WAN": "external transport connectivity — the boundary between this site and the wider network",
        "User": "internal wired access for users and devices at the site",
        "WiFi": "internal wireless access, layered on top of the wired boundary already governed by User",
    }
    for abb in abbs:
        note = interop_notes.get(abb, "a distinct connectivity concern within this capability")
        lines.append(f"- **{abb}** — {note}")

    lines.append("")
    lines.append("## Approval status")
    lines.append("")
    lines.append("| ABB | Architecture owner | Approved pattern(s) | Status |")
    lines.append("|---|---|---|---|")
    for abb in abbs:
        patterns = _patterns_for_abb(catalogue, abb, primary_capability)
        providers = _providers_for_abb(catalogue, abb)
        if patterns:
            pattern_str = ", ".join(f"`{p['pattern_id']}`" for p in patterns)
            status = "\u2705 Approved"
        else:
            pattern_str = "none"
            status = "\u26a0\ufe0f Pending — do not build against this ABB yet"
        lines.append(f"| {abb} | Principal Architect (VSBB: {', '.join(providers) if providers else 'none approved'}) | {pattern_str} | {status} |")

    lines.append("")
    lines.append("## Reference diagram (architecture level — no config detail)")
    lines.append("")
    lines.append(_capability_diagram(catalogue, primary_capability, abbs))
    lines.append("")
    lines.append(
        "_Engineering configuration templates (CBB) exist beneath each approved pattern above, "
        "owned and maintained by engineering per Outcome 9 — available on request, not included "
        "in this submission._"
    )
    lines.append("")
    lines.append(
        "**Once submitted, this becomes the governed baseline** — any future site delivering "
        f"{primary_capability} is expected to match one of the approved patterns above; "
        "divergence is tracked and reported through the standard consistency mechanism."
    )

    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m src.governed_submission <Primary Capability, e.g. Branch>")
        sys.exit(1)
    print(generate_governed_submission(sys.argv[1]))
