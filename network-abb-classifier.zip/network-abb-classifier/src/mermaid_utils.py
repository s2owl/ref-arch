"""
Shared Mermaid diagram utilities.

Mermaid node IDs (the identifier before the label brackets, e.g. `FOO`
in `FOO["Some Label"]`) cannot contain spaces, `&`, `/`, or most
punctuation — only alphanumerics and underscores are safe. The LABEL
text inside the brackets can contain almost anything (it's a quoted
string), but the ID itself cannot.

This was getting handled inconsistently — some call sites stripped
spaces and hyphens but not `&` or `/`, which is exactly the class of
bug that broke real names like "Monitoring & Alerting" and would also
break "Path Selection / QoS" or "AAA (Device & Session)". One shared,
fully-tested sanitizer instead of ad-hoc replace() chains per file.
"""
import re


def safe_mermaid_id(text: str) -> str:
    """
    Converts any string into a safe Mermaid node ID: alphanumerics and
    underscores only, no leading digit (Mermaid IDs shouldn't start
    with one), no repeated/trailing underscores.
    """
    safe = re.sub(r"[^a-zA-Z0-9_]", "_", text)
    safe = re.sub(r"_+", "_", safe).strip("_")
    if not safe:
        safe = "NODE"
    if safe[0].isdigit():
        safe = f"N_{safe}"
    return safe
