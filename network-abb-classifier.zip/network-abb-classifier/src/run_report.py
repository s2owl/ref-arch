"""
The actual Wave One run report generator — aggregates every classified
result in data/results/ into the consistency scorecard, divergence
findings, gap analysis, and pattern-match summary.

This is what docs/example-output/wave-one-run-report.md illustrated by
hand with fabricated numbers, built for real. Reuses:
  - src/patterns.py's match_pattern() and band applicability logic
  - src/hardening.py's compute_contextual_baseline()
  - src/standards.py's measurable_standard()
No new AI calls — pure aggregation over already-classified structured
output, same principle as everything else in this pipeline.

Usage:
    python -m src.run_report
"""
import json
from collections import defaultdict
from pathlib import Path

from src.patterns import match_pattern, load_band_applicability
from src.hardening import compute_contextual_baseline, collect_absolute_findings, MIN_SAMPLE_SIZE
from src.standards import load_requirement_rules, measurable_standard

RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"


def load_all_results() -> list:
    return [json.loads(p.read_text()) for p in RESULTS_DIR.glob("*.json")]


def group_by_band(results: list) -> dict:
    grouped = defaultdict(list)
    for r in results:
        grouped[r.get("band", "unknown")].append(r)
    return grouped


def compute_block_consistency(band_results: list) -> dict:
    """
    For each ABB in this band's sites, and each of SBB/ZBB, find the
    canonical (majority) CBB and report consistency % and diverging sites.
    """
    by_abb_block = defaultdict(lambda: defaultdict(list))  # abb -> block_type -> [(site_id, cbb)]
    for result in band_results:
        for abb_match in result.get("abb_matches", []):
            abb = abb_match["abb"]
            for block in ("sbb", "zbb"):
                if block in abb_match:
                    by_abb_block[abb][block].append((result["site_id"], abb_match[block]["cbb"]))

    consistency = {}
    for abb, blocks in by_abb_block.items():
        consistency[abb] = {}
        for block, entries in blocks.items():
            total = len(entries)
            counts = defaultdict(list)
            for site_id, cbb in entries:
                counts[cbb].append(site_id)
            canonical_cbb, canonical_sites = max(counts.items(), key=lambda kv: len(kv[1]))
            diverging = [
                {"cbb": cbb, "sites": sites}
                for cbb, sites in counts.items() if cbb != canonical_cbb
            ]
            consistency[abb][block] = {
                "canonical_cbb": canonical_cbb,
                "consistency_pct": round(100 * len(canonical_sites) / total, 1) if total else None,
                "sites_matching": len(canonical_sites),
                "total_sites": total,
                "diverging": diverging,
            }
    return consistency


def compute_gaps(band: str, band_results: list) -> dict:
    applicability = load_band_applicability(band)
    expected_abbs = applicability.get("applicable_abbs") or []
    site_abbs = {r["site_id"]: {m["abb"] for m in r.get("abb_matches", [])} for r in band_results}

    missing = {}
    for site_id, abbs_found in site_abbs.items():
        gap = [a for a in expected_abbs if a not in abbs_found]
        if gap:
            missing[site_id] = gap
    return {
        "expected_abbs": expected_abbs,
        "not_applicable": list(applicability.get("not_applicable", {}).keys()),
        "sites_with_gaps": missing,
    }


def compute_pattern_summary(band_results: list) -> dict:
    statuses = defaultdict(list)
    for r in band_results:
        m = match_pattern(r)
        statuses[m["match_status"]].append(r["site_id"])
    return dict(statuses)


def generate_report() -> str:
    results = load_all_results()
    if not results:
        return "# Wave One Run Report\n\nNo classified results found in data/results/. Nothing to report yet."

    grouped = group_by_band(results)
    lines = [f"# Wave One Run Report", f"\nGenerated from {len(results)} classified site(s) across {len(grouped)} band(s).\n"]

    for band, band_results in sorted(grouped.items()):
        lines.append(f"## Band: `{band}` ({len(band_results)} site(s))")

        if len(band_results) < MIN_SAMPLE_SIZE:
            lines.append(f"\n\u26a0\ufe0f Below minimum sample size ({MIN_SAMPLE_SIZE}) — "
                          f"consistency figures below are exploratory only, not a reliable baseline.\n")

        # Consistency
        consistency = compute_block_consistency(band_results)
        lines.append("\n**Consistency by ABB/block:**\n")
        lines.append("| ABB | Block | Canonical CBB | Consistency | Diverging sites |")
        lines.append("|---|---|---|---|---|")
        for abb, blocks in consistency.items():
            for block, data in blocks.items():
                diverging_str = "; ".join(
                    f"{d['cbb']} ({', '.join(d['sites'])})" for d in data["diverging"]
                ) or "—"
                lines.append(
                    f"| {abb} | {block.upper()} | `{data['canonical_cbb']}` | "
                    f"{data['consistency_pct']}% ({data['sites_matching']}/{data['total_sites']}) | {diverging_str} |"
                )

        # Gaps
        gaps = compute_gaps(band, band_results)
        lines.append(f"\n**Band applicability:** expects {', '.join(gaps['expected_abbs']) or 'none'}")
        if gaps["not_applicable"]:
            lines.append(f" (correctly not applicable: {', '.join(gaps['not_applicable'])})")
        if gaps["sites_with_gaps"]:
            lines.append("\n\n**Real gaps found:**")
            for site_id, missing_abbs in gaps["sites_with_gaps"].items():
                lines.append(f"- `{site_id}` missing: {', '.join(missing_abbs)}")
        else:
            lines.append(" — no sites missing an expected ABB.")

        # Pattern match summary
        pattern_summary = compute_pattern_summary(band_results)
        lines.append("\n\n**Pattern match:**")
        for status, sites in pattern_summary.items():
            lines.append(f"- {status}: {len(sites)} site(s) — {', '.join(sites)}")

        # Hardening (contextual)
        hardening_result = compute_contextual_baseline(band_results, band)
        if hardening_result.get("findings_by_name"):
            lines.append("\n\n**Contextual hardening findings:**")
            for name, data in hardening_result["findings_by_name"].items():
                lines.append(f"- {name}: baseline={data['baseline']}, {data['detected_pct']}% detected"
                              + (f", diverging: {', '.join(data['diverging_sites'])}" if data["diverging_sites"] else ""))

        absolute = collect_absolute_findings(band_results)
        if absolute:
            lines.append("\n\n**Absolute hardening findings (always a problem regardless of band):**")
            for f in absolute:
                lines.append(f"- `{f['site_id']}` [{f['severity']}] {f['finding']}: {f['evidence']}")

        # Rule compliance
        lines.append("\n\n**Requirement rule compliance:**")
        for rule in load_requirement_rules():
            standard = measurable_standard(band_results, rule["rule_id"])
            if standard.get("sites_applicable"):
                lines.append(
                    f"- `{rule['rule_id']}`: {standard['compliance_pct']}% "
                    f"({standard['sites_applicable'] - len(standard['non_compliant_sites'])}/{standard['sites_applicable']})"
                    + (f" — non-compliant: {', '.join(standard['non_compliant_sites'])}" if standard["non_compliant_sites"] else "")
                )

        lines.append("\n---\n")

    return "\n".join(lines)


if __name__ == "__main__":
    print(generate_report())
