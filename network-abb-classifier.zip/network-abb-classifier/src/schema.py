"""
Structured output schema for site classification.

Reflects the full hierarchy: Primary Capability -> ABB -> {SBB, ZBB} -> VSBB -> CBB.

Each ABB has TWO independent children, not one:
- SBB: the solution/transport option (e.g. WAN: MPLS, Cellular, Satellite)
- ZBB: the zonal boundary control mechanism protecting that ABB's traffic
  (e.g. ACL, zonal firewall, service mesh policy) — anything that restricts
  inbound/outbound communication for that ABB

SBB and ZBB can vary independently: two sites can share the same SBB
(e.g. both Wired LAN) while differing on ZBB (ACL vs zonal firewall), or
vice versa. Each gets its own VSBB (architecture-boundary realisation,
provider-inclusive) and CBB (versioned, provider-specific config template).

A single site (e.g. a Branch) is met by MULTIPLE ABBs (User, WAN, WiFi),
each with its own SBB and ZBB chains — a router+switch pair will typically
produce matches for WAN (transport) and User (LAN/wired) at minimum,
possibly WiFi too if AP/WLC config is present.

Kept deliberately narrow to Wave One scope: classification only.
Do not extend this with deviation/gap fields until Wave One is validated —
that belongs in a separate schema for a separate call (see docs/ROADMAP.md).
"""

CAPABILITY_TAGS = [
    "Routing",
    "Encapsulation",
    "Path Selection / QoS",
    "Authentication",
    "IAM",
    "Network Access Control",
    "Segmentation",
    "Firewall / Perimeter Security",
    "WiFi/RF Management",
    "Resilience",
    "Monitoring",
    "Alerting",
    "Logging",
    "DHCP/IP Addressing",
    "DNS",
    "IP SLA",
    "Time Sync (NTP)",
    # --- Added from data/catalogue/capability_taxonomy.json. Some
    # overlap deliberately with the tags above at different precision —
    # e.g. "Resilience" (generic, used by existing requirement_rules)
    # vs "Resilience Mapping" (WAN path/dual-uplink specifically) and
    # "FHRP Resilience" (User LAN first-hop redundancy specifically).
    # Keep both tiers: existing rules/examples reference the generic
    # tag, new classifications should prefer the precise one where it
    # applies.
    "Resilience Mapping",
    "FHRP Resilience",
    "NAT",
    "Multicast",
    "Crypto / Key Management",
    "Spanning Tree / Loop Prevention",
    "Port Security",
    "Control Plane Protection",
    "AAA (Device & Session)",
    "Roaming / Mobility",
    "RF / Path Selection Equivalent",
    "Wired Anchor Config (EX)",
    "Management Plane Access",
    # --- Added from real unidentified-capability findings (DNAC/SD-Access
    # signature: crypto pki trustpoint/certificate chain, netconf-yang,
    # pnp profile — consistently appeared across 9/9 sites in one band,
    # unmatched because they weren't governed yet)
    "Certificate / PKI Trust (Device Identity)",
    "NETCONF-YANG / Programmability",
    "Zero-Touch Provisioning (PnP)",
]

_BLOCK_CHAIN_SCHEMA = {
    "type": "object",
    "properties": {
        "type": {
            "type": "string",
            "description": "The SBB or ZBB type name, e.g. 'MPLS' for SBB or 'ACL-based' for ZBB",
        },
        "vsbb": {
            "type": "string",
            "description": "Vendor-specific protocol/method that realises the SBB (e.g. 'Cisco EIGRP', 'Juniper iBGP') "
                           "or vendor-specific boundary mechanism for a ZBB. Vendor/provider approval is architecture-owned.",
        },
        "vsbb_version": {
            "type": "string",
            "description": "The OS/code version this VSBB is running (e.g. 'IOS-XE 17.3', 'Junos 21.2'). "
                           "Config can differ meaningfully between versions of the same vendor+protocol — "
                           "capture this so version drift is visible, not just vendor drift. Omit if not evidenced.",
        },
        "cbb": {
            "type": "string",
            "description": "Versioned, provider-specific engineering config template, e.g. CBB-CISCO-RTG-014-v2",
        },
        "effective_restriction": {
            "type": "string",
            "description": "ZBB ONLY: the actual restriction this boundary enforces in plain terms — e.g. "
                           "'Management access restricted to 10.100.1.0/24 only' or 'VLAN 10 cannot reach VLAN 20'. "
                           "Not the mechanism name (that's 'type') — the real-world effect of the mechanism, "
                           "grounded in what's observed in the config. Omit for SBB.",
        },
    },
    "required": ["type", "vsbb", "cbb"],
}

CLASSIFICATION_SCHEMA = {
    "type": "object",
    "properties": {
        "site_id": {"type": "string"},
        "primary_capability": {
            "type": "string",
            "description": "e.g. Branch, Campus — the top-level requirement this site satisfies",
        },
        "band": {"type": "string"},
        "band_rationale": {
            "type": "string",
            "description": "Why this band was selected — e.g. user count, link type, bandwidth",
        },
        "abb_matches": {
            "type": "array",
            "description": "One entry per ABB this site's config evidences (typically WAN, User, WiFi — a site can match more than one)",
            "items": {
                "type": "object",
                "properties": {
                    "abb": {
                        "type": "string",
                        "description": "The architecture meeting part of the primary capability, e.g. WAN, User, WiFi",
                    },
                    "sbb": {
                        **_BLOCK_CHAIN_SCHEMA,
                        "description": "Solution/transport option for this ABB, e.g. MPLS, Cellular, Satellite, ISP, DWDM for WAN",
                    },
                    "zbb": {
                        **_BLOCK_CHAIN_SCHEMA,
                        "description": "Zonal boundary control for this ABB's traffic, e.g. ACL-based, Zonal-firewall, Service-mesh-policy. Independent of SBB — cite whatever restricts in/outbound communication.",
                    },
                    "capabilities": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "capability": {"type": "string", "enum": CAPABILITY_TAGS},
                                "evidence": {
                                    "type": "string",
                                    "description": "The specific config element that supports this match",
                                },
                                "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
                            },
                            "required": ["capability", "evidence", "confidence"],
                        },
                    },
                },
                "required": ["abb", "sbb", "zbb", "capabilities"],
            },
        },
        "topology_links": {
            "type": "array",
            "description": (
                "Inter-device connections at this site, derived from interface "
                "descriptions/trunk config that reference another device's "
                "hostname (e.g. 'description TRUNK-TO-BR-EXAMPLE-01-RTR' on the "
                "switch, matched against 'description Trunk to BR-EXAMPLE-01-SW' "
                "on the router). This is what determines site TOPOLOGY, distinct "
                "from ABB/SBB/ZBB classification — classification tells you WHAT "
                "each device's config represents; this tells you HOW the devices "
                "at this site connect to each other. Only include a link if both "
                "ends are evidenced by an actual interface description or "
                "explicit connectivity reference in the config — never infer a "
                "connection from device presence alone."
            ),
            "items": {
                "type": "object",
                "properties": {
                    "device_a": {"type": "string", "description": "Hostname of the first device"},
                    "interface_a": {"type": "string", "description": "Interface on device_a, e.g. Gi1/0/1"},
                    "device_b": {"type": "string", "description": "Hostname of the second device"},
                    "interface_b": {
                        "type": "string",
                        "description": "Interface on device_b, if evidenced. Use 'unknown' if device_a's side is clear but device_b's side isn't independently confirmed.",
                    },
                    "link_type": {
                        "type": "string",
                        "enum": ["trunk", "access", "routed", "wan", "unknown"],
                    },
                    "evidence": {"type": "string", "description": "The specific config lines supporting this link"},
                },
                "required": ["device_a", "interface_a", "device_b", "link_type", "evidence"],
            },
        },
        "unmatched_elements": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Config elements the model could not confidently map to any catalogue entry — flag, don't guess",
        },
        "hardening_observations": {
            "type": "array",
            "description": (
                "Findings that don't belong to any single ABB/CBB — hardening/"
                "prohibited-config checks. ABSOLUTE findings are always wrong "
                "regardless of band (e.g. Telnet enabled) and carry a severity "
                "here. CONTEXTUAL findings (e.g. EIGRP redistribution without a "
                "filter) are NOT judged here — only detected and evidenced. "
                "Whether a contextual finding is actually a problem depends on "
                "whether it diverges from the band baseline, which is computed "
                "in aggregation (src/hardening.py), not per-site."
            ),
            "items": {
                "type": "object",
                "properties": {
                    "finding": {"type": "string"},
                    "type": {"type": "string", "enum": ["absolute", "contextual"]},
                    "detected": {"type": "boolean"},
                    "evidence": {"type": "string"},
                    "severity": {
                        "type": "string",
                        "enum": ["high", "medium", "low", "not_applicable"],
                        "description": "Only meaningful for 'absolute' findings. Use 'not_applicable' for contextual findings — severity is determined at aggregation, not here.",
                    },
                },
                "required": ["finding", "type", "detected", "evidence", "severity"],
            },
        },
    },
    "required": [
        "site_id",
        "primary_capability",
        "band",
        "band_rationale",
        "abb_matches",
    ],
}

# OpenAI-style function-calling wrapper around CLASSIFICATION_SCHEMA.
# Used by src/gateway_client.py so the model is forced to return
# arguments matching the schema, rather than free text we hope is valid
# JSON. The schema itself (CLASSIFICATION_SCHEMA) is unchanged — this
# just adds the name/description a function definition requires.
CLASSIFICATION_FUNCTION = {
    "name": "classify_site",
    "description": (
        "Classify a network site's configuration against the governed "
        "ABB/{SBB,ZBB}/VSBB/CBB architecture catalogue."
    ),
    "parameters": CLASSIFICATION_SCHEMA,
}
