"""
Structured output schema for site classification.

Kept deliberately narrow to Phase 1 scope: classification only.
Do not extend this with deviation/gap fields until Phase 1 is validated —
that belongs in a separate schema for a separate call (see docs/ROADMAP.md).
"""

CAPABILITY_TAGS = [
    "Routing",
    "Encapsulation",
    "Path Selection / QoS",
    "Authentication",
    "IAM",
    "Network Access Control",
    "Segmentation",
    "Firewall / Perimeter Security",
    "WiFi/RF Management",
    "Resilience",
    "Monitoring",
    # --- Last five in priority order. Adding tags later is cheap;
    # removing/merging tags after data has been classified against them
    # is not, so these stay out until the 11 above are validated.
    # "Alerting",
    # "Logging",
    # "DHCP/IP Addressing",
    # "DNS",
    # "Time Sync (NTP)",
]

CLASSIFICATION_SCHEMA = {
    "type": "object",
    "properties": {
        "site_id": {"type": "string"},
        "matched_abb": {"type": "string"},
        "matched_sbb": {"type": "string"},
        "matched_vsbb": {"type": "string"},
        "matched_cbb": {"type": "string"},
        "band": {"type": "string"},
        "band_rationale": {
            "type": "string",
            "description": "Why this band was selected — e.g. user count, link type, bandwidth",
        },
        "capabilities": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "capability": {"type": "string", "enum": CAPABILITY_TAGS},
                    "evidence": {
                        "type": "string",
                        "description": "The specific config element that supports this match",
                    },
                    "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
                },
                "required": ["capability", "evidence", "confidence"],
            },
        },
        "unmatched_elements": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Config elements the model could not confidently map to any catalogue entry — flag, don't guess",
        },
    },
    "required": [
        "site_id",
        "matched_abb",
        "matched_sbb",
        "matched_vsbb",
        "matched_cbb",
        "band",
        "band_rationale",
        "capabilities",
    ],
}
