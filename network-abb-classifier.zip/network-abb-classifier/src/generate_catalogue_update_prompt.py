"""
Generates a prompt for CATALOGUE AUTHORING — a different task from
per-site classification (generate_gui_prompt.py). This one takes real
site-type definitions plus the current catalogue.json (which is full of
illustrative EXAMPLE data — fake providers, made-up bands) and asks for
a revised catalogue with the fabricated content replaced, not carried
forward.

The critical risk this guards against: if the prompt doesn't explicitly
call out which parts of the current catalogue are placeholder/example
data, a model will often "helpfully" preserve plausible-looking values
(e.g. keep "Vodafone" as a provider) rather than recognising them as
fictional and removing them. This prompt is deliberately blunt about
that distinction.

Usage:
    python -m src.generate_catalogue_update_prompt
    -> writes gui-prompts/catalogue-update-prompt.txt

You then attach TWO files in your GUI alongside this prompt:
  1. Your list of site-type/band definitions
  2. The current catalogue.json (as docx or however your GUI accepts it)
"""
from pathlib import Path

OUTPUT_DIR = Path(__file__).parent.parent / "gui-prompts"

PROMPT = """You are revising a governed network architecture catalogue (an
ABB/SBB/ZBB/VSBB/CBB hierarchy used for network governance and
classification) for a real organisation's network estate.

You have been given two attachments:
  1. A document listing REAL definitions of each site type/band
     (criteria such as user count, transport type, bandwidth, etc.)
  2. The CURRENT catalogue.json for this framework, provided as a Word
     document

CRITICAL CONTEXT ABOUT ATTACHMENT 2:
The current catalogue.json is illustrative/example data used to build
and test this framework — NOT real organisational data. It contains
fabricated placeholder values: example provider names (e.g. Vodafone,
Starlink, BT-MPLS, generic "Cisco" entries), invented band names and
criteria, and illustrative patterns. NONE of these specific values are
real. Attachment 2 should be treated as a STRUCTURAL TEMPLATE ONLY —
copy its JSON shape (the same top-level keys, the same nesting), but do
NOT carry forward any of its specific content (provider names, band
criteria, pattern IDs) unless that exact value is also independently
confirmed by attachment 1 or by information I've given you directly in
this conversation.

YOUR TASK:
Produce a revised catalogue.json that:

1. Uses the EXACT same top-level structure as attachment 2: 
   primary_capabilities, band_applicability_matrix, abbs, sbb_catalogue,
   zbb_catalogue, pattern_catalogue, requirement_rules, hardening_checks.
   Do not add or remove top-level keys.

2. Populates band_applicability_matrix from the REAL site-type
   definitions in attachment 1 — real band names, real criteria
   (user counts, transport type, etc.), and infer applicable_abbs
   (WAN/User/WiFi) based on whether each site type plausibly needs
   wired user access and managed WiFi (e.g. a single unmanned device on
   a cellular-only link likely doesn't need User or WiFi ABBs — apply
   the same reasoning the example catalogue's band_applicability_matrix
   demonstrates structurally, without copying its actual band names).

3. Does NOT populate sbb_catalogue, zbb_catalogue, or pattern_catalogue
   with any provider, vendor, or pattern-ID values unless those are
   explicitly stated in attachment 1 or elsewhere in this conversation.
   If real vendor/provider/pattern data hasn't been supplied, leave
   these arrays EMPTY (not filled with placeholders that look real) —
   an empty array is honest; a fabricated-but-plausible entry is not.

4. Leaves pattern_catalogue empty unless an approved pattern is
   explicitly stated as approved in attachment 1. Patterns in this
   framework are meant to be derived from real observed classification
   data over time, not assumed upfront — do not invent one to fill the
   section.

5. For requirement_rules and hardening_checks: only include a rule if
   it reflects a genuinely intended governance requirement (e.g.
   "Authentication is mandatory on User ABBs") rather than a
   vendor-specific or fabricated example. If attachment 1 doesn't cover
   this, retain the STRUCTURE (rule_id, description, applies_to_abb,
   requires_capability, mandatory, regulatory_basis,
   managed_service_solution fields) but mark the managed_service_solution
   and regulatory_basis as "PENDING - not yet confirmed" rather than
   guessing.

6. Anywhere you don't have enough real information to populate a
   required field confidently, use the literal string
   "PENDING - not yet defined" rather than inventing a plausible-sounding
   value. This catalogue is a governance artefact that people will make
   real decisions from — a wrong-but-confident value is worse than an
   honest gap.

OUTPUT FORMAT:
Respond with ONLY the revised catalogue.json as a single JSON object —
no markdown code fences, no explanation before or after — so it can be
copy-pasted directly into a file and saved as data/catalogue/catalogue.json.
"""


if __name__ == "__main__":
    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / "catalogue-update-prompt.txt"
    out_path.write_text(PROMPT)
    print(f"Wrote {out_path} ({len(PROMPT)} characters)")
    print()
    print("Next steps:")
    print("  1. Open this file, copy the contents into your GUI")
    print("  2. Attach your site-type definitions document")
    print("  3. Attach the current catalogue.json (as docx or however your GUI accepts it)")
    print("  4. Submit — review the output carefully for any 'PENDING' markers")
    print("     before saving it as data/catalogue/catalogue.json")
