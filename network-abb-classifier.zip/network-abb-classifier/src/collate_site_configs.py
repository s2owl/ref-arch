"""
Collates multiple per-device config files into one combined config per
site, using the hostname naming convention (src/hostname_parser.py) to
determine which devices belong together.

Without this step, a router + core + distribution + access set for one
real site would each become their own "site" in data/sites/, and
classification would never see the relationships between them — the
whole point of asking about topology. This groups them first, labels
each device's role in the combined text, and writes ONE file per site
that the existing pipeline (generate_gui_prompt.py / classify.py)
already knows how to consume as raw config text.

Usage:
    python -m src.collate_site_configs

Scans data/sites/ for files matching the naming convention, groups by
site_id, and writes data/sites/<site_id>.txt for each group with 2+
devices (a single device doesn't need collating — it's already one
file). Files that don't match the naming convention are listed but
left untouched.
"""
from pathlib import Path
from collections import defaultdict

from src.hostname_parser import parse_device_name, extract_hostname_from_config

SITES_DIR = Path(__file__).parent.parent / "data" / "sites"


def resolve_device_identity(path: Path) -> tuple:
    """
    Returns (parsed_dict_or_None, source, mismatch_warning_or_None).
    Prefers the hostname found INSIDE the config (authoritative — it's
    what the device calls itself) over the filename (fragile — typos,
    stray spaces, renaming in transit all corrupt it, as already seen).
    """
    raw = path.read_text()
    content_hostname = extract_hostname_from_config(raw)

    if content_hostname:
        parsed = parse_device_name(content_hostname)
        if parsed:
            # Cross-check against the filename as a data-quality signal —
            # doesn't block anything, just surfaces a mismatch worth knowing.
            filename_parsed = parse_device_name(path.stem)
            warning = None
            if filename_parsed and filename_parsed["site_id"] != parsed["site_id"]:
                warning = (
                    f"filename '{path.name}' suggests site '{filename_parsed['site_id']}' "
                    f"but the config's own hostname '{content_hostname}' says "
                    f"'{parsed['site_id']}' — using the hostname (more authoritative)"
                )
            return parsed, "config content (hostname line)", warning

    # No usable hostname in the config content — fall back to filename
    filename_parsed = parse_device_name(path.stem)
    return filename_parsed, "filename (fallback — no hostname line found in config)", None


def is_already_collated(path: Path) -> bool:
    """
    A previously-collated file starts with '# Site <id> — combined
    config'. Without this guard, re-running collate() would find a
    real hostname line embedded inside its own prior output and
    re-register it as a new device — corrupting the grouping on any
    second run.
    """
    try:
        first_line = path.read_text().split("\n", 1)[0]
    except Exception:
        return False
    return first_line.startswith("# Site ") and "combined config" in first_line


def collate():
    # Flat files directly in data/sites/ (original workflow, still supported)
    flat_files = [
        p for p in SITES_DIR.glob("*")
        if p.suffix.lower() in (".cfg", ".txt") and p.is_file() and not is_already_collated(p)
    ]
    # Files inside data/sites/<site_id>/ subfolders (organize_site_folders.py output)
    subfolder_files = [
        p for p in SITES_DIR.glob("*/*")
        if p.suffix.lower() in (".cfg", ".txt") and p.is_file() and not is_already_collated(p)
    ]
    device_files = flat_files + subfolder_files

    grouped = defaultdict(list)
    unmatched = []
    warnings = []

    for path in device_files:
        parsed, source, warning = resolve_device_identity(path)
        if warning:
            warnings.append(warning)
        if parsed:
            grouped[parsed["site_id"]].append((path, parsed))
        else:
            unmatched.append(path)

    if warnings:
        print("\u26a0\ufe0f  Filename/content mismatches found (using content, the authoritative source):")
        for w in warnings:
            print(f"  - {w}")
        print()

    if unmatched:
        print("Files where neither the config's hostname line nor the filename matched "
              "the naming convention (left untouched):")
        for p in unmatched:
            print(f"  - {p.name}")
        print()

    written = []
    for site_id, devices in grouped.items():
        if len(devices) < 2:
            print(f"{site_id}: only 1 device ({devices[0][0].name}) — no collation needed, skipping")
            continue

        devices.sort(key=lambda d: (d[1]["device_type"], d[1]["instance"]))

        sections = []
        for path, parsed in devices:
            role = parsed["role"]
            hostname = parsed["original_name"]
            raw_config = path.read_text()
            sections.append(
                f"=== DEVICE: {hostname} | ROLE: {role} (device type '{parsed['device_type']}') ===\n"
                f"{raw_config}"
            )

        combined = (
            f"# Site {site_id} — combined config from {len(devices)} devices "
            f"({', '.join(d[1]['role'] for d in devices)}).\n"
            f"# Each device's role in the topology is labelled below — use this to\n"
            f"# understand the hierarchy (which devices connect to which, not just\n"
            f"# each device's config in isolation) when classifying.\n\n"
            + "\n\n".join(sections)
        )

        out_path = SITES_DIR / f"{site_id}.txt"
        out_path.write_text(combined)
        written.append((site_id, len(devices), out_path))

    print("\nCollated:")
    for site_id, count, path in written:
        print(f"  {site_id}: {count} devices -> {path.name}")

    if not written:
        print("  (none — either no multi-device sites found, or already collated)")


if __name__ == "__main__":
    collate()
