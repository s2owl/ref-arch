"""
Client for the internal AI gateway — matches the org's real reference
template, which supports TWO auth options with different header shapes:

  1. Internal Staff Account Authentication (AMToken) — what this repo
     defaults to, matching the manual ~30-min AM-token workflow in
     src/auth.py.
  2. Service Account Authentication (JWT via X-HSBC-E2E-Trust-Token) —
     no Token_Type header, different header name entirely. Set
     GATEWAY_AUTH_METHOD=jwt to use this instead.

The URL is a single, fully-formed endpoint from the platform (NOT built
by concatenating a base URL + USER_ID + suffix — USER_ID only appears
in the request body's "user" field, per the reference template).

Function (tool) calling is added on top of the reference template so
the classification schema is enforced by the API itself (tool_choice),
rather than just requested in prompt text.
"""
import os
import uuid
import json
import requests
import truststore

from src.auth import get_fresh_token

# ---------------------------------------------------------------
# User configuration — fill in from your AI Platform / gateway setup
# ---------------------------------------------------------------
URL = os.environ.get("GATEWAY_URL", "<YOUR_API_ENDPOINT_HERE>")
# e.g. "https://gaip-api-uat.<org>-<project>-gaipuat-dev.dev.gcp.cloud.<region>.<org>/
#       etiv-ssvc-aigateway-ea-chatcompletion-uat-internal-proxy/v1/api/v1/chat/completions"

USER_ID = os.environ.get("GATEWAY_USER_ID", "<Your Use Case ID>")  # e.g. "UCXXXXXXX"
MODEL = os.environ.get("GATEWAY_MODEL", "<The Model you want to use>")  # e.g. "gemini-3.5-flash"
MAX_TOKENS = int(os.environ.get("GATEWAY_MAX_TOKENS", "2000"))

# "amtoken" (Internal Staff Account) or "jwt" (Service Account)
AUTH_METHOD = os.environ.get("GATEWAY_AUTH_METHOD", "amtoken").lower()

# SSL truststore injection, per the reference template
truststore.inject_into_ssl()


def _build_headers(token: str) -> dict:
    if AUTH_METHOD == "jwt":
        # Service Account Authentication — no Token_Type header
        return {
            "X-HSBC-E2E-Trust-Token": token,
            "Content-Type": "application/json",
            "x-correlation-id": str(uuid.uuid4()),
            "x-usersession-id": str(uuid.uuid4()),
        }
    # Default: Internal Staff Account Authentication (AMToken)
    return {
        "AMToken": token,
        "Content-Type": "application/json",
        "Token_Type": "SESSION_TOKEN",
        "x-correlation-id": str(uuid.uuid4()),
        "x-usersession-id": str(uuid.uuid4()),
    }


def call_with_function(prompt: str, function_schema: dict, retries: int = 1, timeout: int = 25) -> dict:
    """
    Calls the gateway using OpenAI-style function (tool) calling so the
    model is forced to return arguments matching function_schema, rather
    than free text we hope is valid JSON.

    function_schema should be a single function definition:
      {"name": "...", "description": "...", "parameters": {...JSON Schema...}}

    Returns the parsed function-call arguments as a dict.
    """
    tool_def = {
        "type": "function",
        "function": function_schema,
    }

    data = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": MAX_TOKENS,
        "user": USER_ID,
        "tools": [tool_def],
        "tool_choice": {"type": "function", "function": {"name": function_schema["name"]}},
    }

    last_error = None
    for attempt in range(retries + 1):
        # Re-reads data/token.txt fresh every attempt. This can't auto-refresh
        # an expired manual token, but it DOES mean that if you notice a
        # 401, paste a fresh token into data/token.txt, and this retry picks
        # it up without restarting the script.
        token = get_fresh_token()
        headers = _build_headers(token)
        try:
            response = requests.post(URL, headers=headers, json=data, timeout=timeout)
            if response.status_code == 401 and attempt < retries:
                continue  # token expired mid-flight, retry with a fresh one
            response.raise_for_status()
            result = response.json()
            return _extract_function_arguments(result)
        except requests.exceptions.RequestException as e:
            last_error = e
            continue
    raise RuntimeError(
        f"Gateway call failed after {retries + 1} attempt(s): {last_error}. "
        f"If this is a 401, your token in data/token.txt may have expired — "
        f"get a fresh one and paste it in, then retry."
    )


def _extract_function_arguments(result: dict) -> dict:
    """
    Pulls the function-call arguments out of an OpenAI-style
    chat/completions response and parses them as JSON.
    """
    try:
        message = result["choices"][0]["message"]
        tool_calls = message.get("tool_calls")
        if not tool_calls:
            raise RuntimeError(
                f"Model did not return a tool call — got content instead: "
                f"{message.get('content')!r}. Check tool_choice is being "
                f"honoured by the gateway/model."
            )
        arguments_str = tool_calls[0]["function"]["arguments"]
        return json.loads(arguments_str)
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        raise RuntimeError(f"Could not parse function-call response: {e}. Raw response: {result}")
