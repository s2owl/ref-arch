"""
Client for the internal AI gateway. Fetches a fresh JWT immediately
before every call — tokens live ~30 seconds, so never reuse one across
requests or cache it.
"""
import os
import requests

from src.auth import get_jwt_token

GATEWAY_URL = os.environ.get("GATEWAY_URL", "https://your-internal-gateway/v1/generate")
MODEL_NAME = os.environ.get("GATEWAY_MODEL", "gemini-3.5-flash")


def call_gateway(prompt: str, response_schema: dict, retries: int = 1, timeout: int = 25) -> dict:
    """
    Calls the gateway with a fresh token. Retries once on 401 (token
    expired mid-flight) with a newly fetched token.

    Confirm the exact payload shape and field names with whoever owns
    the gateway — this assumes a generic {model, prompt, response_schema}
    body, which is unlikely to match 1:1 without adjustment.
    """
    last_error = None
    for attempt in range(retries + 1):
        token = get_jwt_token()  # fetched fresh on every attempt
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": MODEL_NAME,
            "prompt": prompt,
            "response_schema": response_schema,
        }
        try:
            response = requests.post(GATEWAY_URL, headers=headers, json=payload, timeout=timeout)
            if response.status_code == 401 and attempt < retries:
                continue  # token expired mid-flight, retry with a fresh one
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            last_error = e
            continue
    raise RuntimeError(f"Gateway call failed after {retries + 1} attempt(s): {last_error}")
