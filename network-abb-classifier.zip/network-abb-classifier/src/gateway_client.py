"""
Client for the internal AI gateway — matches the org's real reference
template (OpenAI-compatible chat/completions endpoint) with function
(tool) calling added on top, so the classification schema is enforced
by the API itself rather than just requested in prompt text.

Fetches a fresh token immediately before every call — tokens live ~30
seconds, never cached or reused across requests.
"""
import os
import uuid
import json
import requests
import truststore

from src.auth import get_fresh_token

# ---------------------------------------------------------------
# User configuration — fill in from your AI Platform / gateway setup
# ---------------------------------------------------------------
USER_ID = os.environ.get("GATEWAY_USER_ID", "<Your Use Case ID>")  # e.g. "UCXXXXXXX"
MODEL = os.environ.get("GATEWAY_MODEL", "<The Model you want to use>")  # e.g. "gemini-3.5-flash"
BASE_GATEWAY_URL = os.environ.get(
    "GATEWAY_BASE_URL", "<SDK Endpoint> Retrieve from the AI Platform/"
)  # e.g. "https://host/ai-gateway-uat-internal-proxy/v1"

# SSL truststore injection, per the reference template
truststore.inject_into_ssl()

# ---------------------------------------------------------------
# URL construction — chat/completions (non-embedding models)
# ---------------------------------------------------------------
URL = (
    f"{BASE_GATEWAY_URL.rstrip('/')}"
    f"/{USER_ID.strip('/')}"
    "/chat/completions"
)


def _build_headers(token: str) -> dict:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Token_Type": "SESSION_TOKEN",
        "x-correlation-id": str(uuid.uuid4()),
        "x-usersession-id": str(uuid.uuid4()),
    }


def call_with_function(prompt: str, function_schema: dict, retries: int = 1, timeout: int = 25) -> dict:
    """
    Calls the gateway using OpenAI-style function (tool) calling so the
    model is forced to return arguments matching function_schema, rather
    than free text we hope is valid JSON.

    function_schema should be a single function definition:
      {"name": "...", "description": "...", "parameters": {...JSON Schema...}}

    Returns the parsed function-call arguments as a dict.
    """
    tool_def = {
        "type": "function",
        "function": function_schema,
    }

    data = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "tools": [tool_def],
        "tool_choice": {"type": "function", "function": {"name": function_schema["name"]}},
    }

    last_error = None
    for attempt in range(retries + 1):
        token = get_fresh_token()  # fetched fresh on every attempt — 30s lifetime
        headers = _build_headers(token)
        try:
            response = requests.post(URL, headers=headers, json=data, timeout=timeout)
            if response.status_code == 401 and attempt < retries:
                continue  # token expired mid-flight, retry with a fresh one
            response.raise_for_status()
            result = response.json()
            return _extract_function_arguments(result)
        except requests.exceptions.RequestException as e:
            last_error = e
            continue
    raise RuntimeError(f"Gateway call failed after {retries + 1} attempt(s): {last_error}")


def _extract_function_arguments(result: dict) -> dict:
    """
    Pulls the function-call arguments out of an OpenAI-style
    chat/completions response and parses them as JSON.
    """
    try:
        message = result["choices"][0]["message"]
        tool_calls = message.get("tool_calls")
        if not tool_calls:
            raise RuntimeError(
                f"Model did not return a tool call — got content instead: "
                f"{message.get('content')!r}. Check tool_choice is being "
                f"honoured by the gateway/model."
            )
        arguments_str = tool_calls[0]["function"]["arguments"]
        return json.loads(arguments_str)
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        raise RuntimeError(f"Could not parse function-call response: {e}. Raw response: {result}")
