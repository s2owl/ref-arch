"""
Wave 1.85: customer-facing resilience statement.

Deterministic templating over already-computed output (classification,
pattern-match, rule evaluation) — no AI call, same principle as
patterns.py and standards.py. Translates the internal ABB/SBB/ZBB/VSBB/
CBB taxonomy into a plain-language statement a customer can read without
needing to understand the taxonomy at all. The taxonomy is the evidence
trail behind the statement, not the statement itself.
"""
import datetime


def generate_resilience_statement(classification_result: dict, pattern_match_result: dict = None,
                                    rule_results: list = None) -> str:
    site_id = classification_result["site_id"]
    band = classification_result.get("band", "unknown band")
    primary_capability = classification_result.get("primary_capability", "")

    lines = [f"# Resilience Statement — {site_id}", f"**Site type:** {primary_capability} ({band})", ""]

    # Per-ABB resilience evidence, in plain language
    found_any = False
    for abb_match in classification_result.get("abb_matches", []):
        resilience_caps = [c for c in abb_match.get("capabilities", []) if c["capability"] == "Resilience"]
        if resilience_caps:
            found_any = True
            cap = resilience_caps[0]
            lines.append(f"**{abb_match['abb']} resilience:** {cap['evidence']} (confidence: {cap['confidence']})")
    if not found_any:
        lines.append("**Resilience:** no resilience evidence found in this site's classification — worth checking directly rather than assuming.")

    # Design consistency — is this a standard build or a bespoke one?
    if pattern_match_result:
        status = pattern_match_result.get("match_status")
        pattern_id = pattern_match_result.get("closest_pattern")
        if status == "full":
            lines.append(f"\n**Design consistency:** Fully matches the governed pattern `{pattern_id}` — "
                          f"built to the estate standard, not a bespoke one-off design.")
        elif status == "partial":
            diverging = [d["abb"] for d in pattern_match_result.get("diverging_abbs", [])]
            lines.append(f"\n**Design consistency:** Matches the governed pattern `{pattern_id}` except: "
                          f"{', '.join(diverging)} — flagged for architecture review, not yet resolved.")
        elif status == "no_pattern_defined":
            lines.append(f"\n**Design consistency:** No governed pattern defined yet for band `{band}` — "
                          f"consistency cannot yet be confirmed against a standard.")

    # Rule compliance relevant to resilience/protection
    if rule_results:
        relevant = [r for r in rule_results if "RESILIENCE" in r["rule_id"] or "FIREWALL" in r["rule_id"]]
        if relevant:
            lines.append("")
            for r in relevant:
                status = "\u2705 Confirmed" if r["compliant"] else "\u26a0\ufe0f Not evidenced — needs investigation"
                lines.append(f"**{r['description']}** — {status}")
                lines.append(f"  _Regulatory basis: {r['regulatory_basis']}_")

    lines.append(f"\n_Last verified: {datetime.date.today().isoformat()} — derived from a repeatable "
                  f"classification run against live config, not a one-off design review._")

    return "\n".join(lines)
