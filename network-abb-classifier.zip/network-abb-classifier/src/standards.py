"""
Wave 1.8: requirement rules -> measurable standards.

Different from patterns (empirical: what the estate DOES) and different
from hardening (absolute: config-level right/wrong). This is NORMATIVE:
what the estate MUST do, stated as a governed rule, mapped to how that
requirement is actually delivered as a managed service. Evaluating a
site against these rules is a deterministic comparison over already-
classified output — no AI call needed, same principle as pattern-
matching and hardening aggregation.

The output of this module IS the measurable standard: a rule either has
a stated compliance percentage across a band, or it doesn't — there's
no ambiguity in what "compliant" means, because the rule states it.
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def load_requirement_rules() -> list:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        path = DATA_DIR / "catalogue" / "catalogue.example.json"
    catalogue = json.loads(path.read_text())
    return catalogue.get("requirement_rules", [])


def _site_has_capability(classification_result: dict, abb_filter: str, capability: str) -> tuple:
    """Returns (found: bool, evidence: str|None) for a capability within
    the ABBs matching abb_filter ('*' means any ABB)."""
    for abb_match in classification_result.get("abb_matches", []):
        if abb_filter != "*" and abb_match["abb"] != abb_filter:
            continue
        for cap in abb_match.get("capabilities", []):
            if cap["capability"] == capability:
                return True, cap.get("evidence")
    return False, None


def evaluate_site(classification_result: dict) -> list:
    """
    Evaluate one site's classification output against every applicable
    rule. Returns a list of rule evaluation results.
    """
    band = classification_result.get("band")
    results = []

    for rule in load_requirement_rules():
        if band in rule.get("excluded_bands", []):
            continue  # rule doesn't apply to this band at all

        found, evidence = _site_has_capability(
            classification_result, rule["applies_to_abb"], rule["requires_capability"]
        )

        results.append({
            "rule_id": rule["rule_id"],
            "description": rule["description"],
            "mandatory": rule["mandatory"],
            "compliant": found,
            "evidence": evidence,
            "regulatory_basis": rule["regulatory_basis"],
            "managed_service_solution": rule["managed_service_solution"],
        })

    return results


def measurable_standard(classification_results: list, rule_id: str) -> dict:
    """
    Aggregate one rule's compliance across a set of sites — this is the
    actual "measurable standard": a stated percentage against a stated
    requirement, not a description.
    """
    rule = next((r for r in load_requirement_rules() if r["rule_id"] == rule_id), None)
    if not rule:
        return {"rule_id": rule_id, "error": "rule not found"}

    applicable_sites = [
        r for r in classification_results
        if r.get("band") not in rule.get("excluded_bands", [])
    ]

    compliant_sites = []
    non_compliant_sites = []
    for result in applicable_sites:
        found, _ = _site_has_capability(result, rule["applies_to_abb"], rule["requires_capability"])
        (compliant_sites if found else non_compliant_sites).append(result["site_id"])

    total = len(applicable_sites)
    compliance_pct = round(100 * len(compliant_sites) / total, 1) if total else None

    return {
        "rule_id": rule_id,
        "description": rule["description"],
        "regulatory_basis": rule["regulatory_basis"],
        "managed_service_solution": rule["managed_service_solution"],
        "sites_applicable": total,
        "compliance_pct": compliance_pct,
        "non_compliant_sites": non_compliant_sites,
    }
