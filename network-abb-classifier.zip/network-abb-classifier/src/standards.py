"""
Wave 1.8: requirement rules -> measurable standards.

Different from patterns (empirical: what the estate DOES) and different
from hardening (absolute: config-level right/wrong). This is NORMATIVE:
what the estate MUST do, stated as a governed rule, mapped to how that
requirement is actually delivered as a managed service. Evaluating a
site against these rules is a deterministic comparison over already-
classified output — no AI call needed, same principle as pattern-
matching and hardening aggregation.

The output of this module IS the measurable standard: a rule either has
a stated compliance percentage across a band, or it doesn't — there's
no ambiguity in what "compliant" means, because the rule states it.
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def load_requirement_rules() -> list:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        raise FileNotFoundError(
            f"No catalogue found at {path}. This tool will not silently fall "
            f"back to example/fabricated data — copy "
            f"data/catalogue/catalogue.example.json to catalogue.json to "
            f"explicitly start from illustrative data, or set up your real "
            f"governed catalogue first."
        )
    catalogue = json.loads(path.read_text())
    return catalogue.get("requirement_rules", [])


def _site_has_capability(classification_result: dict, abb_filter: str, capability: str) -> tuple:
    """Returns (found: bool, evidence: str|None) for a capability within
    the ABBs matching abb_filter ('*' means any ABB)."""
    for abb_match in classification_result.get("abb_matches", []):
        if abb_filter != "*" and abb_match["abb"] != abb_filter:
            continue
        for cap in abb_match.get("capabilities", []):
            if cap["capability"] == capability:
                return True, cap.get("evidence")
    return False, None


def evaluate_site(classification_result: dict) -> list:
    """
    Evaluate one site's classification output against every applicable
    rule. Returns a list of rule evaluation results.
    """
    band = classification_result.get("band")
    results = []

    for rule in load_requirement_rules():
        if band in rule.get("excluded_bands", []):
            continue  # rule doesn't apply to this band at all

        found, evidence = _site_has_capability(
            classification_result, rule["applies_to_abb"], rule["requires_capability"]
        )

        results.append({
            "rule_id": rule["rule_id"],
            "description": rule["description"],
            "mandatory": rule["mandatory"],
            "compliant": found,
            "evidence": evidence,
            "regulatory_basis": rule["regulatory_basis"],
            "managed_service_solution": rule["managed_service_solution"],
        })

    return results


def measurable_standard(classification_results: list, rule_id: str) -> dict:
    """
    Aggregate one rule's compliance across a set of sites — this is the
    actual "measurable standard": a stated percentage against a stated
    requirement, not a description.
    """
    rule = next((r for r in load_requirement_rules() if r["rule_id"] == rule_id), None)
    if not rule:
        return {"rule_id": rule_id, "error": "rule not found"}

    applicable_sites = [
        r for r in classification_results
        if r.get("band") not in rule.get("excluded_bands", [])
    ]

    compliant_sites = []
    non_compliant_sites = []
    for result in applicable_sites:
        found, _ = _site_has_capability(result, rule["applies_to_abb"], rule["requires_capability"])
        (compliant_sites if found else non_compliant_sites).append(result["site_id"])

    total = len(applicable_sites)
    compliance_pct = round(100 * len(compliant_sites) / total, 1) if total else None

    return {
        "rule_id": rule_id,
        "description": rule["description"],
        "regulatory_basis": rule["regulatory_basis"],
        "managed_service_solution": rule["managed_service_solution"],
        "sites_applicable": total,
        "compliance_pct": compliance_pct,
        "non_compliant_sites": non_compliant_sites,
    }


if __name__ == "__main__":
    import sys
    import json
    from pathlib import Path

    if len(sys.argv) < 2:
        print("Usage: python -m src.standards <site_id>")
        sys.exit(1)

    site_id = sys.argv[1]
    result_path = Path(__file__).parent.parent / "data" / "results" / f"{site_id}.json"
    if not result_path.exists():
        available = sorted(p.stem for p in result_path.parent.glob("*.json"))
        print(f"No result found at {result_path}.")
        if available:
            print(f"Sites that ARE classified ({len(available)}): {', '.join(available[:15])}"
                  f"{' ...' if len(available) > 15 else ''}")
        else:
            print("No sites have been classified yet at all — run classification/validation first.")
        sys.exit(1)

    site_result = json.loads(result_path.read_text())
    rule_results = evaluate_site(site_result)

    print(f"Rule compliance for {site_id}:\n")
    lines = [f"Rule compliance for {site_id}:\n"]
    for r in rule_results:
        status = "\u2705 Compliant" if r["compliant"] else "\u26a0\ufe0f  Not evidenced"
        line1 = f"{status}  {r['rule_id']}: {r['description']}"
        line2 = f"   Regulatory basis: {r['regulatory_basis']}"
        print(line1)
        print(line2)
        lines.append(line1)
        lines.append(line2)
        if not r["compliant"]:
            line3 = f"   Expected: {r['managed_service_solution']}"
            print(line3)
            lines.append(line3)
        print()
        lines.append("")

    out_dir = Path(__file__).parent.parent / "output"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / f"standards-{site_id}.txt"
    out_path.write_text("\n".join(lines))
    print(f"Saved to {out_path}")
