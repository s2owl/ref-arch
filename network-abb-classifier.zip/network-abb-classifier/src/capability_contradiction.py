"""
Capability-contradiction detection.

Different from every other check in this pipeline: it's not "is this
capability present" (classification) or "does this diverge from the
band baseline" (hardening/patterns) — it's "does the config ITSELF
contradict a capability the classification claimed is evidenced".

The canonical case (from data/catalogue/capability_taxonomy.json's
ACL Quality / Permissiveness risk_flag): a site can be classified as
evidencing Segmentation or Network Access Control, while the actual
ACL enforcing it is "permit ip any any" — permissive enough that it
isn't really enforcing anything. Presence of the capability's mechanism
(an ACL exists) doesn't mean the capability is actually delivered.

Deterministic — scans raw config text for risky patterns and
cross-references against the classification's claimed capabilities.
No AI call, same principle as everything else cross-referencing
already-produced structured output in this pipeline.
"""
import json
from pathlib import Path

from src.config_loader import load_site_config

RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"

# Extensible: add more rules here as new capability-contradiction
# patterns are identified. Each rule scans raw config for risky_indicators
# and flags a contradiction if any of contradicts_claimed_capabilities
# was claimed as evidenced anywhere in the site's classification.
CONTRADICTION_RULES = [
    {
        "rule_id": "CONTRADICTION-ACL-PERMISSIVE-001",
        "risky_capability": "ACL Quality / Permissiveness",
        "risky_indicators": ["permit ip any any", "permit tcp any any"],
        "contradicts_claimed_capabilities": ["Segmentation", "Network Access Control"],
        "description": (
            "An overly permissive ACL (permit any/any) was found in config while "
            "Segmentation or Network Access Control is claimed as evidenced — the "
            "ACL doesn't actually enforce what's claimed."
        ),
    },
]


def _get_searchable_text(config) -> str:
    """Config from load_site_config is either raw text (str) or
    pre-normalised (dict) — make either searchable as plain text."""
    return config if isinstance(config, str) else json.dumps(config)


def _get_claimed_capabilities(classification_result: dict) -> dict:
    """Returns {capability_name: [abb, ...]} — which ABBs claimed each capability."""
    claimed = {}
    for abb_match in classification_result.get("abb_matches", []):
        abb = abb_match["abb"]
        for cap in abb_match.get("capabilities", []):
            claimed.setdefault(cap["capability"], []).append(abb)
    return claimed


def check_contradictions(site_id: str) -> list:
    """
    Returns a list of contradiction findings for a site. Empty list
    means no contradictions found — not that none were checked.
    """
    result_path = RESULTS_DIR / f"{site_id}.json"
    if not result_path.exists():
        raise FileNotFoundError(f"No classification result at {result_path} — classify this site first.")
    classification_result = json.loads(result_path.read_text())

    try:
        raw_config = load_site_config(site_id)
    except FileNotFoundError:
        return [{"error": f"Original config for '{site_id}' not found — cannot check contradictions"}]

    text = _get_searchable_text(raw_config).lower()
    claimed = _get_claimed_capabilities(classification_result)

    findings = []
    for rule in CONTRADICTION_RULES:
        matched_indicator = next((i for i in rule["risky_indicators"] if i.lower() in text), None)
        if not matched_indicator:
            continue
        for claimed_cap in rule["contradicts_claimed_capabilities"]:
            if claimed_cap in claimed:
                findings.append({
                    "rule_id": rule["rule_id"],
                    "site_id": site_id,
                    "contradicted_capability": claimed_cap,
                    "claimed_in_abb": claimed[claimed_cap],
                    "risky_evidence": matched_indicator,
                    "description": rule["description"],
                })

    return findings


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m src.capability_contradiction <site_id>")
        sys.exit(1)

    site_id = sys.argv[1]
    findings = check_contradictions(site_id)

    if not findings:
        print(f"No capability contradictions found for {site_id}.")
    else:
        print(f"\u26a0\ufe0f  {len(findings)} contradiction(s) found for {site_id}:\n")
        for f in findings:
            print(json.dumps(f, indent=2))

    out_dir = Path(__file__).parent.parent / "output"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / f"contradictions-{site_id}.json"
    out_path.write_text(json.dumps(findings, indent=2))
    print(f"\nSaved to {out_path}")
