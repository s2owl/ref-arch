"""
Engineer-facing Build Guide.

Everything built so far (Wave One, patterns, standards) is AUDIT-facing:
given a site that already exists, is it consistent/compliant. This is
the inverse — BUILD-facing: given a band (i.e. a set of requirements —
user count, bandwidth, transport type), tell an engineer exactly what to
deploy, with zero taxonomy knowledge required. The engineer doesn't need
to know what an ABB or VSBB is — they need to know "for this size of
site, use this SBB, this provider, this config template."

Deterministic templating over the catalogue (pattern_catalogue +
band_applicability_matrix + requirement_rules) — no AI call. If a band
has no governed pattern yet, this says so explicitly rather than
guessing or inventing one — that's an architecture decision to make
first, not something to improvise into an engineer's build guide.
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def _load_catalogue() -> dict:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        path = DATA_DIR / "catalogue" / "catalogue.example.json"
    return json.loads(path.read_text())


def _band_applicability(catalogue: dict, band: str) -> dict:
    for entry in catalogue.get("band_applicability_matrix", []):
        if entry["band"] == band:
            return entry
    return {"applicable_abbs": [], "criteria": "unknown band"}


def _pattern_for_band(catalogue: dict, band: str) -> dict:
    for p in catalogue.get("pattern_catalogue", []):
        if p["band"] == band:
            return p
    return None


def _provider_for(catalogue: dict, abb: str, block_type: str, catalogue_key: str) -> str:
    for entry in catalogue.get(catalogue_key, []):
        if entry["abb"] == abb and entry.get("sbb_type", entry.get("zbb_type")) == block_type:
            return entry.get("provider", "unspecified")
    return "unspecified"


def generate_build_guide(band: str) -> str:
    catalogue = _load_catalogue()
    applicability = _band_applicability(catalogue, band)
    pattern = _pattern_for_band(catalogue, band)

    lines = [
        f"# Build Guide — {band}",
        f"_Criteria: {applicability.get('criteria', 'not defined')}_",
        "",
        "If you are building a new site matching this description, use "
        "exactly what's below. This is the governed standard — no design "
        "decisions needed on your part.",
        "",
    ]

    if not applicability.get("applicable_abbs"):
        lines.append("**No band definition found — do not proceed. Escalate to architecture before building.**")
        return "\n".join(lines)

    if not pattern:
        lines.append(
            "**No governed pattern exists yet for this band.** Do not improvise a "
            "design — escalate to architecture to get a pattern approved before "
            "building. (This is expected for newer or lower-volume bands — see "
            "docs/ROADMAP.md, patterns are derived from real data, not assumed upfront.)"
        )
        return "\n".join(lines)

    lines.append(f"**Governed pattern:** `{pattern['pattern_id']}`")
    lines.append(f"_{pattern.get('rationale', '')}_\n")

    for abb in applicability["applicable_abbs"]:
        bundle = pattern["bundle"].get(abb)
        if not bundle:
            lines.append(f"## {abb}\n**No build instruction defined for this ABB in this pattern — escalate to architecture.**\n")
            continue

        sbb_provider = _provider_for(catalogue, abb, bundle["sbb_type"], "sbb_catalogue")
        zbb_provider = _provider_for(catalogue, abb, bundle["zbb_type"], "zbb_catalogue")

        lines.append(f"## {abb}")
        lines.append(f"- **Deploy:** {bundle['sbb_type']} (provider: {sbb_provider})")
        lines.append(f"- **Config template:** `{bundle['sbb_cbb']}`")
        lines.append(f"- **Boundary control:** {bundle['zbb_type']} (provider: {zbb_provider})")
        lines.append(f"- **Config template:** `{bundle['zbb_cbb']}`")
        lines.append("")

    lines.append(
        "_This build guide is generated directly from the governed pattern "
        "and band-applicability catalogue — if you build to this exactly, "
        "you will pass every consistency and rule check in Wave One by "
        "construction, not by coincidence._"
    )

    return "\n".join(lines)
