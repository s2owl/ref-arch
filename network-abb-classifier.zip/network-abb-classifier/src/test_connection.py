"""
Standalone connectivity test — isolates "can I reach the model at all"
from everything else in this pipeline (schema, function calling,
catalogue, prompts). If this fails, the problem is auth/network/config,
not your classification logic — fix this first before troubleshooting
anything else.

Usage:
    python -m src.test_connection
"""
import requests

from src.auth import get_fresh_token
from src.gateway_client import URL, MODEL, MAX_TOKENS, USER_ID, AUTH_METHOD, _build_headers


def test_connection():
    print(f"Testing connection to: {URL}")
    print(f"Model: {MODEL}")
    print(f"Auth method: {AUTH_METHOD}")
    print(f"User/Use Case ID: {USER_ID}")
    print()

    if "<" in URL or "<" in MODEL or "<" in USER_ID:
        print("⚠️  One or more config values still look like a placeholder "
              "(contains '<'). Check your .env file is filled in and loaded.")
        print()

    try:
        token = get_fresh_token()
        print("✅ Token read successfully from data/.token")
    except Exception as e:
        print(f"❌ Could not get a token: {e}")
        return

    headers = _build_headers(token)
    data = {
        "model": MODEL,
        "messages": [{"role": "user", "content": "how to open vscode"}],
        "max_tokens": 50,
        "user": USER_ID,
    }

    print("Sending a minimal test request (no schema, no tool calling)...")
    try:
        response = requests.post(URL, headers=headers, json=data, timeout=25)
    except requests.exceptions.SSLError as e:
        print(f"❌ SSL error — likely a certificate trust issue: {e}")
        print("   See pip.ini.example / README for cert troubleshooting notes.")
        return
    except requests.exceptions.ConnectionError as e:
        print(f"❌ Connection error — could not reach the URL at all: {e}")
        print("   Check GATEWAY_URL is correct and you're on the right network/VPN.")
        return
    except requests.exceptions.Timeout:
        print("❌ Request timed out after 25s — gateway may be slow or unreachable.")
        return

    print(f"Status code: {response.status_code}")

    if response.status_code == 200:
        try:
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            print()
            print("✅ SUCCESS — model responded:")
            print(f"   {content[:200]}")
        except (KeyError, IndexError, ValueError) as e:
            print(f"⚠️  Got 200 but couldn't parse the expected response shape: {e}")
            print(f"   Raw response: {response.text[:500]}")
    elif response.status_code == 401:
        print("❌ 401 Unauthorized — your token is likely invalid or expired.")
        print("   Get a fresh token and paste it into data/.token.")
    elif response.status_code == 404:
        print("❌ 404 Not Found — check GATEWAY_URL is the exact, complete endpoint")
        print("   your platform gave you, not something built from parts.")
    else:
        print(f"❌ Unexpected status. Response body:")
        print(f"   {response.text[:500]}")


if __name__ == "__main__":
    test_connection()
