"""
Generates TWO files per site for GUIs with a short input box but file
attachment support (e.g. a ~4000 character prompt limit):

  <site_id>-prompt.txt      — SHORT (~under 4000 chars). Paste this into
                               the GUI's text box.
  <site_id>-attachment.txt  — Everything else: full instructions,
                               capability indicators, hardening checks,
                               schema, catalogue, and the config itself.
                               Upload this as a file attachment alongside
                               the short prompt.

This split matters because a GUI's input box and its attachment upload
often have very different size limits — cramming everything into the
box either truncates it or simply doesn't fit, while the attachment
channel typically has much more headroom.

Usage:
    python -m src.generate_gui_prompt BR-EXAMPLE-01
    -> writes gui-prompts/BR-EXAMPLE-01-prompt.txt (short)
    -> writes gui-prompts/BR-EXAMPLE-01-attachment.txt (full)
    -> writes gui-prompts/BR-EXAMPLE-01-preview.md (sanity-check)

Workflow:
    1. Run this to generate both files
    2. Open -preview.md — quick sanity-check of what's being submitted
    3. Paste -prompt.txt into the GUI's text box
    4. Upload -attachment.txt as a file attachment
    5. Submit
    6. Copy the model's JSON response into gui-prompts/<site_id>-output.json
    7. Run: python -m src.validate_manual_result <site_id>
       This checks it against the schema and, if valid, copies it into
       data/results/ so every downstream tool works exactly as if it
       came from the API.
"""
import json
import sys
from pathlib import Path

from src.config_loader import load_site_config, load_catalogue_slice, is_raw_config
from src.prompts import SYSTEM_INSTRUCTIONS, FEW_SHOT_EXAMPLES
from src.schema import CLASSIFICATION_SCHEMA, CAPABILITY_TAGS

OUTPUT_DIR = Path(__file__).parent.parent / "gui-prompts"
SHORT_PROMPT_LIMIT = 4000


def build_attachment(site_id: str) -> str:
    """
    Everything the model needs EXCEPT the short pointer prompt: full
    instructions, capability indicators, hardening checks, schema, the
    catalogue, and the config itself. This goes in the attachment, not
    the text box.
    """
    config = load_site_config(site_id)
    catalogue_slice = load_catalogue_slice()
    from src.prompts import _build_capability_indicators_block, _build_hardening_checks_block
    instructions = SYSTEM_INSTRUCTIONS.format(
        capability_tags=", ".join(CAPABILITY_TAGS),
        capability_indicators=_build_capability_indicators_block(),
        hardening_checks_block=_build_hardening_checks_block(),
    )

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    schema_instructions = f"""
IMPORTANT — OUTPUT FORMAT:
Respond with ONLY a single JSON object. No markdown code fences (no ```),
no explanation before or after, no commentary — just the raw JSON object,
so it can be copy-pasted directly into a file and parsed.

The JSON object MUST match this exact shape (this is the JSON Schema it
will be validated against — every required field must be present):

{json.dumps(CLASSIFICATION_SCHEMA, indent=2)}
"""

    if is_raw_config(config):
        config_block = f"""CONFIG TO CLASSIFY (raw device config — parse this yourself; it has
not been pre-structured, so read it as you would real Cisco IOS-style
config):

{config}"""
    else:
        config_block = f"CONFIG TO CLASSIFY (pre-normalised):\n{json.dumps(config, indent=2)}"

    return f"""{instructions}
{examples_block}
{schema_instructions}

CATALOGUE:
{json.dumps(catalogue_slice, indent=2)}

{config_block}

---
FINAL REMINDER, this is the most important instruction in this entire document:
Your ENTIRE response must be ONLY the JSON object. Do not write "Here's the
classification" or any other introduction. Do not add any explanation,
summary, or closing remark after the JSON. Do not use markdown code fences.
The very first character of your response must be {{ and the very last
character must be }}. Nothing else.
"""


def build_short_prompt(site_id: str) -> str:
    """
    The text that actually goes in the GUI's input box — deliberately
    tiny, just enough to point the model at the attachment and restate
    the JSON-only requirement (repetition here matters, since this is
    the last thing the model reads before responding).

    Includes the required top-level keys directly, not just a pointer
    to the attachment — defense in depth in case the GUI doesn't fully
    read a large text-file attachment and the model falls back to
    inventing its own structure instead of the governed schema.
    """
    prompt = f"""Classify network site '{site_id}' using the attached file, which contains
the full classification rules, the governed architecture catalogue, the
JSON schema to follow, and the device configuration itself.

Read the attachment carefully and follow its instructions exactly — do
NOT invent your own JSON structure for describing the site; use the
exact schema from the attachment.

Your JSON response's TOP-LEVEL keys must be exactly:
site_id, primary_capability, band, band_rationale, abb_matches
(plus optionally unmatched_elements, hardening_observations). Do not use
different key names (e.g. not "site", "code", "devices") — use these
exact names, matching the schema in the attachment.

Your entire response must be ONLY a single JSON object matching that
schema. No introduction, no explanation, no closing remarks, no markdown
code fences. The first character of your response must be {{ and the
last character must be }}."""

    if len(prompt) > SHORT_PROMPT_LIMIT:
        # Defensive check — this template is fixed-length and shouldn't
        # ever exceed the limit, but fail loudly rather than silently
        # submit something too long if it ever does.
        raise ValueError(
            f"Short prompt is {len(prompt)} chars, over the {SHORT_PROMPT_LIMIT} limit — "
            f"this shouldn't happen with the current template; something changed."
        )

    return prompt


def build_preview(site_id: str, catalogue_slice: dict) -> str:
    """
    A short, human-readable companion — NOT for pasting into the GUI,
    purely for sanity-checking what's about to be submitted before you
    commit to it.
    """
    abbs = catalogue_slice.get("abbs", {})
    band_matrix = catalogue_slice.get("band_applicability_matrix", [])

    lines = [
        f"# Preview — {site_id}",
        "_Sanity-check this before submitting. This file is not for the GUI —_",
        f"_see `{site_id}-prompt.txt` (paste) and `{site_id}-attachment.txt` (upload)._\n",
        "## What's being checked",
        f"This site will be classified against **{len(abbs)} ABB(s)**: "
        f"{', '.join(abbs.keys()) if abbs else '(none defined in catalogue)'}\n",
    ]

    if band_matrix:
        lines.append("## Bands this catalogue currently defines")
        lines.append("_The model determines which ONE of these applies — this list is not a hint,_")
        lines.append("_just what's possible given the current catalogue._\n")
        for b in band_matrix:
            lines.append(f"- `{b['band']}` — {b.get('criteria', 'no criteria stated')}")
        lines.append("")

    lines.append("## Block hierarchy reminder")
    lines.append("Every ABB match will report:")
    lines.append("- **SBB** — the solution (how the capability is realised)")
    lines.append("- **ZBB** — the zone boundary (how traffic is isolated: ACL/VLAN/FW)")
    lines.append("- **VSBB** — vendor versioning, under each of SBB and ZBB")
    lines.append("- **CBB** — the config achieving each, under each of SBB and ZBB")
    lines.append("\nSee `docs/BUILDING_BLOCK_HIERARCHY.md` for the full model.\n")

    lines.append("## Next step")
    lines.append(f"If this looks right: paste `{site_id}-prompt.txt` into the GUI's text box, "
                  f"upload `{site_id}-attachment.txt` as a file attachment, then submit.")

    return "\n".join(lines)


def _generate_one(site_id: str) -> tuple:
    """Returns (short_prompt, attachment, preview, char_count) for one site."""
    attachment = build_attachment(site_id)
    short_prompt = build_short_prompt(site_id)
    catalogue_slice = load_catalogue_slice()
    preview = build_preview(site_id, catalogue_slice)
    return short_prompt, attachment, preview


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m src.generate_gui_prompt <site_id>")
        print("       python -m src.generate_gui_prompt --all   (generate every un-collated/un-classified site at once)")
        sys.exit(1)

    OUTPUT_DIR.mkdir(exist_ok=True)

    if sys.argv[1] == "--all":
        from src.config_loader import list_curated_sites
        RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"

        site_ids = list_curated_sites()
        already_classified = {p.stem for p in RESULTS_DIR.glob("*.json")}
        pending = [s for s in site_ids if s not in already_classified]

        if not pending:
            print("Every curated site already has a classified result in data/results/. "
                  "Nothing to generate — use --force logic manually if you want to redo any.")
            sys.exit(0)

        print(f"Generating prompts for {len(pending)} site(s) "
              f"(skipping {len(site_ids) - len(pending)} already classified)...\n")
        for site_id in pending:
            try:
                short_prompt, attachment, preview = _generate_one(site_id)

                (OUTPUT_DIR / f"{site_id}-prompt.txt").write_text(short_prompt)
                (OUTPUT_DIR / f"{site_id}-attachment.txt").write_text(attachment)
                (OUTPUT_DIR / f"{site_id}-preview.md").write_text(preview)

                print(f"  \u2705 {site_id} -> prompt.txt ({len(short_prompt)} chars), "
                      f"attachment.txt ({len(attachment)} chars), preview written")
            except Exception as e:
                print(f"  \u274c {site_id} failed: {e}")

        print(f"\n{len(pending)} site(s) written to {OUTPUT_DIR}/")
        print("For each: paste -prompt.txt into your GUI's text box, upload")
        print("-attachment.txt as a file, submit, save the response as")
        print("<site_id>-output.json, then run:")
        print("  python -m src.validate_manual_result --all")
        sys.exit(0)

    site_id = sys.argv[1]
    short_prompt, attachment, preview = _generate_one(site_id)

    preview_path = OUTPUT_DIR / f"{site_id}-preview.md"
    preview_path.write_text(preview)

    prompt_path = OUTPUT_DIR / f"{site_id}-prompt.txt"
    prompt_path.write_text(short_prompt)

    attachment_path = OUTPUT_DIR / f"{site_id}-attachment.txt"
    attachment_path.write_text(attachment)

    print(f"Wrote {prompt_path} ({len(short_prompt)} characters — paste this into the GUI)")
    print(f"Wrote {attachment_path} ({len(attachment)} characters — upload this as a file)")
    print(f"Wrote {preview_path} — read this first, it's the short sanity-check version")
    print()
    print("Next steps:")
    print(f"  1. Open {preview_path} — quick sanity-check")
    print(f"  2. Paste {prompt_path}'s contents into your GUI's text box")
    print(f"  3. Upload {attachment_path} as a file attachment")
    print(f"  4. Pick a model, submit")
    print(f"  5. Copy the model's JSON response into {OUTPUT_DIR / (site_id + '-output.json')}")
    print(f"  6. Run: python -m src.validate_manual_result {site_id}")
