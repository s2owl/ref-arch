"""
Generates a single, self-contained, copy-pasteable prompt for use in a
GUI-only model interface (choose model, paste prompt, optionally
upload files — no API, no function calling, no schema enforcement).

This is the manual equivalent of src/classify.py — same catalogue, same
config, same instructions — but since there's no tool_choice to force
a structured response, the schema is spelled out explicitly in the
prompt text and the model is instructed to return raw JSON only. The
output still needs validating (see validate_manual_result.py) before
it's trusted, since nothing here enforces the shape the way function
calling did.

Usage:
    python -m src.generate_gui_prompt BR-EXAMPLE-01
    -> writes gui-prompts/BR-EXAMPLE-01-prompt.txt

Workflow:
    1. Run this to generate the prompt file
    2. Open it, copy the entire contents
    3. Paste into your GUI, pick a model, submit
    4. Copy the model's JSON response into
       gui-prompts/<site_id>-output.json
    5. Run: python -m src.validate_manual_result BR-EXAMPLE-01
       This checks it against the schema and, if valid, copies it into
       data/results/ so every downstream tool (patterns, standards,
       build guide, etc.) works exactly as if it came from the API.
"""
import json
import sys
from pathlib import Path

from src.config_loader import load_site_config, load_catalogue_slice, is_raw_config
from src.prompts import SYSTEM_INSTRUCTIONS, FEW_SHOT_EXAMPLES
from src.schema import CLASSIFICATION_SCHEMA, CAPABILITY_TAGS

OUTPUT_DIR = Path(__file__).parent.parent / "gui-prompts"


def build_gui_prompt(site_id: str) -> str:
    config = load_site_config(site_id)
    catalogue_slice = load_catalogue_slice()
    from src.prompts import _build_capability_indicators_block, _build_hardening_checks_block
    instructions = SYSTEM_INSTRUCTIONS.format(
        capability_tags=", ".join(CAPABILITY_TAGS),
        capability_indicators=_build_capability_indicators_block(),
        hardening_checks_block=_build_hardening_checks_block(),
    )

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    # No function calling available here, so the schema has to be spelled
    # out as explicit instructions rather than enforced by the API.
    schema_instructions = f"""
IMPORTANT — OUTPUT FORMAT:
Respond with ONLY a single JSON object. No markdown code fences (no ```),
no explanation before or after, no commentary — just the raw JSON object,
so it can be copy-pasted directly into a file and parsed.

The JSON object MUST match this exact shape (this is the JSON Schema it
will be validated against — every required field must be present):

{json.dumps(CLASSIFICATION_SCHEMA, indent=2)}
"""

    if is_raw_config(config):
        config_block = f"""CONFIG TO CLASSIFY (raw device config — parse this yourself; it has
not been pre-structured, so read it as you would real Cisco IOS-style
config):

{config}"""
    else:
        config_block = f"CONFIG TO CLASSIFY (pre-normalised):\n{json.dumps(config, indent=2)}"

    return f"""{instructions}
{examples_block}
{schema_instructions}

CATALOGUE:
{json.dumps(catalogue_slice, indent=2)}

{config_block}
"""


def build_preview(site_id: str, catalogue_slice: dict) -> str:
    """
    A short, human-readable companion — NOT for pasting into the GUI,
    purely for sanity-checking what's about to be submitted before you
    commit to it. The actual prompt.txt is a wall of JSON by necessity
    (the model needs the full catalogue); this is the two-minute read
    that orients you first.
    """
    primary_caps = catalogue_slice.get("primary_capabilities", {})
    abbs = catalogue_slice.get("abbs", {})
    band_matrix = catalogue_slice.get("band_applicability_matrix", [])

    lines = [
        f"# Preview — {site_id}",
        "_Sanity-check this before pasting the full prompt. This file is not_",
        "_for the GUI — see `{site_id}-prompt.txt` for that._\n".format(site_id=site_id),
        "## What's being checked",
        f"This site will be classified against **{len(abbs)} ABB(s)**: "
        f"{', '.join(abbs.keys()) if abbs else '(none defined in catalogue)'}\n",
    ]

    if band_matrix:
        lines.append("## Bands this catalogue currently defines")
        lines.append("_The model determines which ONE of these applies — this list is not a hint,_")
        lines.append("_just what's possible given the current catalogue._\n")
        for b in band_matrix:
            lines.append(f"- `{b['band']}` — {b.get('criteria', 'no criteria stated')}")
        lines.append("")

    lines.append("## Block hierarchy reminder")
    lines.append("Every ABB match will report:")
    lines.append("- **SBB** — the solution (how the capability is realised)")
    lines.append("- **ZBB** — the zone boundary (how traffic is isolated: ACL/VLAN/FW)")
    lines.append("- **VSBB** — vendor versioning, under each of SBB and ZBB")
    lines.append("- **CBB** — the config achieving each, under each of SBB and ZBB")
    lines.append("\nSee `docs/BUILDING_BLOCK_HIERARCHY.md` for the full model.\n")

    lines.append("## Next step")
    lines.append(f"If this looks right, open `{site_id}-prompt.txt`, copy the whole thing into your GUI.")

    return "\n".join(lines)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m src.generate_gui_prompt <site_id>")
        print("       python -m src.generate_gui_prompt --all   (generate every un-collated/un-classified site at once)")
        sys.exit(1)

    OUTPUT_DIR.mkdir(exist_ok=True)

    if sys.argv[1] == "--all":
        from src.config_loader import list_curated_sites
        RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"

        site_ids = list_curated_sites()
        already_classified = {p.stem for p in RESULTS_DIR.glob("*.json")}
        pending = [s for s in site_ids if s not in already_classified]

        if not pending:
            print("Every curated site already has a classified result in data/results/. "
                  "Nothing to generate — use --force logic manually if you want to redo any.")
            sys.exit(0)

        print(f"Generating prompts for {len(pending)} site(s) "
              f"(skipping {len(site_ids) - len(pending)} already classified)...\n")
        for site_id in pending:
            try:
                prompt = build_gui_prompt(site_id)
                out_path = OUTPUT_DIR / f"{site_id}-prompt.txt"
                out_path.write_text(prompt)

                catalogue_slice = load_catalogue_slice()
                preview = build_preview(site_id, catalogue_slice)
                (OUTPUT_DIR / f"{site_id}-preview.md").write_text(preview)

                print(f"  \u2705 {site_id} -> {out_path.name} ({len(prompt)} chars), preview written")
            except Exception as e:
                print(f"  \u274c {site_id} failed: {e}")

        print(f"\n{len(pending)} prompt(s) written to {OUTPUT_DIR}/")
        print("For each: open the file, paste into your GUI, save the response as")
        print("<site_id>-output.json in the same folder, then run:")
        print("  python -m src.validate_manual_result --all")
        sys.exit(0)

    site_id = sys.argv[1]
    prompt = build_gui_prompt(site_id)

    catalogue_slice = load_catalogue_slice()
    preview = build_preview(site_id, catalogue_slice)
    preview_path = OUTPUT_DIR / f"{site_id}-preview.md"
    preview_path.write_text(preview)

    out_path = OUTPUT_DIR / f"{site_id}-prompt.txt"
    out_path.write_text(prompt)

    print(f"Wrote {out_path} ({len(prompt)} characters)")
    print(f"Wrote {preview_path} — read this first, it's the short version")
    print()
    print("Next steps:")
    print(f"  1. Open {preview_path} — quick sanity-check of what's being submitted")
    print(f"  2. Open {out_path}, copy the entire contents")
    print(f"  3. Paste into your GUI, pick a model, submit")
    print(f"  4. Copy the model's JSON response into {OUTPUT_DIR / (site_id + '-output.json')}")
    print(f"  5. Run: python -m src.validate_manual_result {site_id}")
