"""
Generates a single, self-contained, copy-pasteable prompt for use in a
GUI-only model interface (choose model, paste prompt, optionally
upload files — no API, no function calling, no schema enforcement).

This is the manual equivalent of src/classify.py — same catalogue, same
config, same instructions — but since there's no tool_choice to force
a structured response, the schema is spelled out explicitly in the
prompt text and the model is instructed to return raw JSON only. The
output still needs validating (see validate_manual_result.py) before
it's trusted, since nothing here enforces the shape the way function
calling did.

Usage:
    python -m src.generate_gui_prompt BR-EXAMPLE-01
    -> writes gui-prompts/BR-EXAMPLE-01-prompt.txt

Workflow:
    1. Run this to generate the prompt file
    2. Open it, copy the entire contents
    3. Paste into your GUI, pick a model, submit
    4. Copy the model's JSON response into
       gui-prompts/<site_id>-output.json
    5. Run: python -m src.validate_manual_result BR-EXAMPLE-01
       This checks it against the schema and, if valid, copies it into
       data/results/ so every downstream tool (patterns, standards,
       build guide, etc.) works exactly as if it came from the API.
"""
import json
import sys
from pathlib import Path

from src.config_loader import load_site_config, load_catalogue_slice
from src.prompts import SYSTEM_INSTRUCTIONS, FEW_SHOT_EXAMPLES
from src.schema import CLASSIFICATION_SCHEMA, CAPABILITY_TAGS

OUTPUT_DIR = Path(__file__).parent.parent / "gui-prompts"


def build_gui_prompt(site_id: str) -> str:
    config = load_site_config(site_id)
    catalogue_slice = load_catalogue_slice()
    instructions = SYSTEM_INSTRUCTIONS.format(capability_tags=", ".join(CAPABILITY_TAGS))

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    # No function calling available here, so the schema has to be spelled
    # out as explicit instructions rather than enforced by the API.
    schema_instructions = f"""
IMPORTANT — OUTPUT FORMAT:
Respond with ONLY a single JSON object. No markdown code fences (no ```),
no explanation before or after, no commentary — just the raw JSON object,
so it can be copy-pasted directly into a file and parsed.

The JSON object MUST match this exact shape (this is the JSON Schema it
will be validated against — every required field must be present):

{json.dumps(CLASSIFICATION_SCHEMA, indent=2)}
"""

    return f"""{instructions}
{examples_block}
{schema_instructions}

CATALOGUE:
{json.dumps(catalogue_slice)}

CONFIG TO CLASSIFY:
{json.dumps(config)}
"""


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m src.generate_gui_prompt <site_id>")
        sys.exit(1)

    site_id = sys.argv[1]
    prompt = build_gui_prompt(site_id)

    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / f"{site_id}-prompt.txt"
    out_path.write_text(prompt)

    print(f"Wrote {out_path} ({len(prompt)} characters)")
    print()
    print("Next steps:")
    print(f"  1. Open {out_path}, copy the entire contents")
    print(f"  2. Paste into your GUI, pick a model, submit")
    print(f"  3. Copy the model's JSON response into {OUTPUT_DIR / (site_id + '-output.json')}")
    print(f"  4. Run: python -m src.validate_manual_result {site_id}")
