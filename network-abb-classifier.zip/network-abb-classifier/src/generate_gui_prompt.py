"""
Generates GUI-ready content matching the proven-working pattern: config
inline where it fits, "the rules" (catalogue+schema+instructions) as a
separate attachment. Historically this worked because the rules
attachment was focused (catalogue+schema only) and genuinely got read.

As sites moved to multi-device collation (3-5 devices per site), the
config itself outgrew what fits inline in a short prompt box — so
config is now its OWN attachment too, separate from the rules
attachment, rather than trying to cram it back into the prompt text.

Three output modes:
  1. Default — <site_id>-prompt.txt (short, paste), <site_id>-rules.txt
     (attachment: catalogue+schema+instructions), <site_id>-config.txt
     (attachment: the device config). Matches the proven pattern.
  2. --chunked — for GUIs that don't read attachments as full context
     at all (different failure mode — confirm with a quote-test before
     assuming this is needed). Splits everything into sequential
     under-limit messages to paste one at a time into the same
     conversation.

Usage:
    python -m src.generate_gui_prompt BR-EXAMPLE-01
    python -m src.generate_gui_prompt BR-EXAMPLE-01 --chunked
    python -m src.generate_gui_prompt --all

Workflow (default mode):
    1. Open -preview.md — quick sanity-check
    2. Paste -prompt.txt into the GUI's text box
    3. Upload -rules.txt AND -config.txt as file attachments
    4. Submit
    5. Copy the model's JSON response into gui-prompts/<site_id>-output.json
    6. Run: python -m src.validate_manual_result <site_id>
"""
import json
import sys
from pathlib import Path

from src.config_loader import load_site_config, load_catalogue_slice, is_raw_config
from src.prompts import SYSTEM_INSTRUCTIONS, FEW_SHOT_EXAMPLES
from src.schema import CLASSIFICATION_SCHEMA, CAPABILITY_TAGS

OUTPUT_DIR = Path(__file__).parent.parent / "gui-prompts"
SHORT_PROMPT_LIMIT = 4000


def build_rules_attachment(site_id: str) -> str:
    """
    "The rules" — instructions, capability indicators, hardening checks,
    schema, and catalogue. Deliberately does NOT include the config —
    this matches the pattern already proven to work (catalogue read
    correctly from an attachment when it held rules content only, not
    also competing with a large config block for attention).
    """
    catalogue_slice = load_catalogue_slice()
    from src.prompts import _build_capability_indicators_block, _build_hardening_checks_block
    instructions = SYSTEM_INSTRUCTIONS.format(
        capability_tags=", ".join(CAPABILITY_TAGS),
        capability_indicators=_build_capability_indicators_block(),
        hardening_checks_block=_build_hardening_checks_block(),
    )

    examples_block = ""
    if FEW_SHOT_EXAMPLES:
        examples_block = "\n\nEXAMPLES OF CORRECT CLASSIFICATION:\n"
        for i, ex in enumerate(FEW_SHOT_EXAMPLES, 1):
            examples_block += (
                f"\nExample {i}:\nCONFIG: {json.dumps(ex['config'])}\n"
                f"CATALOGUE: {json.dumps(ex['catalogue_slice'])}\n"
                f"CORRECT OUTPUT: {json.dumps(ex['expected_output'])}\n"
            )

    schema_instructions = f"""
IMPORTANT — OUTPUT FORMAT:
Respond with ONLY a single JSON object. No markdown code fences (no ```),
no explanation before or after, no commentary — just the raw JSON object,
so it can be copy-pasted directly into a file and parsed.

The JSON object MUST match this exact shape (this is the JSON Schema it
will be validated against — every required field must be present):

{json.dumps(CLASSIFICATION_SCHEMA, indent=2)}
"""

    return f"""{instructions}
{examples_block}
{schema_instructions}

CATALOGUE:
{json.dumps(catalogue_slice, indent=2)}
"""


def build_config_attachment(site_id: str) -> str:
    """
    Just the device config — separated out because multi-device
    collation (3-5 devices per site) has outgrown what fits inline in
    a 4000-char prompt box. Single-device configs used to fit directly
    in the prompt; this replaces that now that they don't.
    """
    config = load_site_config(site_id)
    if is_raw_config(config):
        return f"""CONFIG TO CLASSIFY for site '{site_id}' (raw device config — parse this
yourself; it has not been pre-structured, so read it as you would real
Cisco IOS-style config):

{config}"""
    else:
        return f"CONFIG TO CLASSIFY for site '{site_id}' (pre-normalised):\n{json.dumps(config, indent=2)}"


def build_attachment(site_id: str) -> str:
    """Full combined content (rules + config) — used by --chunked mode,
    which doesn't rely on attachments being read at all, so the
    rules/config split doesn't matter there."""
    return build_rules_attachment(site_id) + "\n\n" + build_config_attachment(site_id) + f"""

---
FINAL REMINDER, this is the most important instruction in this entire document:
Your ENTIRE response must be ONLY the JSON object. Do not write "Here's the
classification" or any other introduction. Do not add any explanation,
summary, or closing remark after the JSON. Do not use markdown code fences.
The very first character of your response must be {{ and the very last
character must be }}. Nothing else.
"""


def build_chunks(site_id: str, chunk_limit: int = 3800) -> list:
    """
    Splits the full classification content into a sequence of messages,
    each safely under chunk_limit characters, to paste ONE AT A TIME
    into the SAME GUI conversation. For GUIs that don't read attachments
    as full context at all — confirm with a quote-test first, since
    that's a different failure mode than config having outgrown the
    prompt box.
    """
    full_content = build_attachment(site_id)
    paragraphs = full_content.split("\n\n")

    chunks = []
    current = ""
    for para in paragraphs:
        candidate = (current + "\n\n" + para) if current else para
        if len(candidate) > chunk_limit:
            if current:
                chunks.append(current)
            if len(para) > chunk_limit:
                for i in range(0, len(para), chunk_limit):
                    chunks.append(para[i:i + chunk_limit])
                current = ""
            else:
                current = para
        else:
            current = candidate
    if current:
        chunks.append(current)

    total = len(chunks) + 1
    labeled = [
        f"[PART {i+1} of {total} — do not respond yet, more is coming. "
        f"Just acknowledge briefly.]\n\n{chunk}"
        for i, chunk in enumerate(chunks)
    ]

    trigger = f"""[PART {total} of {total} — FINAL, respond now]

You now have everything: instructions, schema, catalogue, and the config
for site '{site_id}'. Classify it.

Required top-level JSON keys, exactly: site_id, primary_capability, band,
band_rationale, abb_matches (optionally unmatched_elements,
hardening_observations). Do not invent different key names.

Your entire response must be ONLY that JSON object — no introduction, no
explanation, no closing remarks, no markdown code fences. First character
must be {{, last character must be }}."""

    labeled.append(trigger)
    return labeled


def build_turn1_prompt(site_id: str) -> str:
    """
    Turn 1: let the model reason and analyse freely — no strict JSON
    requirement yet. This is what produced good output before (rich
    detail, even a topology diagram) — the problem was never the
    model's analysis, it was demanding perfect JSON simultaneously.
    Explicitly invites depth, including a connectivity/topology summary
    if it can determine one.
    """
    return f"""Analyse network site '{site_id}' using the attached file, which
contains the classification framework (ABB/SBB/ZBB/VSBB/CBB hierarchy),
governed catalogue, and the device configuration(s) for this site.

Work through this thoroughly:
- Which architecture building blocks (ABBs — WAN, User, WiFi) does this
  site's config evidence?
- For each, what's the solution (SBB) and boundary control (ZBB), and
  which vendor/version (VSBB) delivers each?
- What capabilities are evidenced, with the specific config that proves it?
- If there are multiple devices, show how they connect to each other as
  a Mermaid diagram (```mermaid ... graph TD ... ```) if you can
  determine the topology from interface descriptions or similar
  evidence — label each device with its role (Router/Core/
  Distribution/Access/Server)
- Any hardening findings (things that are wrong regardless of context)
  or config patterns worth flagging?

Take your time and be thorough — I'll ask you to convert this into a
structured format in my next message, so focus on getting the analysis
right first."""


def build_turn2_prompt() -> str:
    """
    Turn 2: the model already produced good analysis in turn 1 — this
    just asks it to restructure THAT into the exact schema. A much
    simpler task than reasoning + schema-compliance simultaneously.

    Uses a compact SKELETON (structure only) rather than the full
    verbose JSON Schema — the full schema is ~9000 chars with field
    descriptions, too big for a short follow-up message, and a concrete
    shape is often easier for a model to match exactly than an abstract
    schema definition anyway.
    """
    skeleton = {
        "site_id": "<string>",
        "primary_capability": "<e.g. Branch, Campus>",
        "band": "<band name from the catalogue>",
        "band_rationale": "<why this band, based on your analysis>",
        "abb_matches": [
            {
                "abb": "<e.g. WAN, User, WiFi>",
                "sbb": {"type": "<solution type>", "vsbb": "<vendor+version>", "cbb": "<config template id>"},
                "zbb": {"type": "<boundary type>", "vsbb": "<vendor+version>", "cbb": "<config template id>"},
                "capabilities": [
                    {"capability": "<from the governed list>", "evidence": "<specific config that proves it>", "confidence": "high|medium|low"}
                ],
            }
        ],
        "unmatched_elements": ["<optional: anything you couldn't map>"],
        "hardening_observations": [
            {"finding": "<e.g. Telnet enabled>", "type": "absolute|contextual", "detected": True, "evidence": "<...>", "severity": "high|medium|low|not_applicable"}
        ],
    }

    prompt = f"""Thank you. Now convert your analysis above into a single JSON object
matching EXACTLY this structure (this is the shape, not literal values —
fill in real data from your analysis):

{json.dumps(skeleton, indent=2)}

Top-level keys must be exactly: site_id, primary_capability, band,
band_rationale, abb_matches (optionally unmatched_elements,
hardening_observations). Do not use different key names or invent your
own structure.

Your entire response must be ONLY that JSON object — no introduction, no
explanation, no closing remarks, no markdown code fences. The first
character must be {{ and the last character must be }}."""

    return prompt


def build_short_prompt(site_id: str) -> str:
    """
    The text that goes in the GUI's input box. References ONE attachment
    (rules + config combined) — some GUIs only support a single file
    upload per message, so the rules/config split has to collapse back
    into one file, just kept as a single attachment instead of pasted
    into the box directly.
    """
    prompt = f"""Classify network site '{site_id}'.

Read the attached file for the full classification instructions, schema,
governed architecture catalogue, and the device configuration to
classify. Follow it exactly — do NOT invent your own JSON structure
(e.g. do not use keys like "devices", "hostname", "eigrp", "vlans" as
your top level); use the exact schema described in the attachment. A
worked example is included in the attachment showing exactly what a
correct classification output looks like — match that shape, not your
own instinct for summarising the config.

Required top-level JSON keys, exactly: site_id, primary_capability, band,
band_rationale, abb_matches (optionally unmatched_elements,
hardening_observations).

Your entire response must be ONLY a single JSON object matching that
schema. No introduction, no explanation, no closing remarks, no markdown
code fences. The first character of your response must be {{ and the
last character must be }}."""

    if len(prompt) > SHORT_PROMPT_LIMIT:
        raise ValueError(
            f"Short prompt is {len(prompt)} chars, over the {SHORT_PROMPT_LIMIT} limit — "
            f"this shouldn't happen with the current template; something changed."
        )

    return prompt


def build_preview(site_id: str, catalogue_slice: dict) -> str:
    """A short, human-readable companion — NOT for pasting into the GUI,
    purely for sanity-checking what's about to be submitted."""
    abbs = catalogue_slice.get("abbs", {})
    band_matrix = catalogue_slice.get("band_applicability_matrix", [])

    lines = [
        f"# Preview — {site_id}",
        "_Sanity-check this before submitting. This file is not for the GUI —_",
        f"_see `{site_id}-prompt.txt` (paste) and `{site_id}-attachment.txt` (upload, ONE file)._\n",
        "## What's being checked",
        f"This site will be classified against **{len(abbs)} ABB(s)**: "
        f"{', '.join(abbs.keys()) if abbs else '(none defined in catalogue)'}\n",
    ]

    if band_matrix:
        lines.append("## Bands this catalogue currently defines")
        lines.append("_The model determines which ONE of these applies — this list is not a hint,_")
        lines.append("_just what's possible given the current catalogue._\n")
        for b in band_matrix:
            lines.append(f"- `{b['band']}` — {b.get('criteria', 'no criteria stated')}")
        lines.append("")

    lines.append("## Block hierarchy reminder")
    lines.append("Every ABB match will report:")
    lines.append("- **SBB** — the solution (how the capability is realised)")
    lines.append("- **ZBB** — the zone boundary (how traffic is isolated: ACL/VLAN/FW)")
    lines.append("- **VSBB** — vendor versioning, under each of SBB and ZBB")
    lines.append("- **CBB** — the config achieving each, under each of SBB and ZBB")
    lines.append("\nSee `docs/BUILDING_BLOCK_HIERARCHY.md` for the full model.\n")

    lines.append("## Next step")
    lines.append(f"Paste `{site_id}-prompt.txt` into the GUI's text box, upload "
                  f"`{site_id}-attachment.txt` as the (single) file attachment, submit.")

    return "\n".join(lines)


def _generate_one(site_id: str) -> tuple:
    """Returns (short_prompt, attachment, preview) for one site — single
    combined attachment (rules + config), matching a GUI that only
    supports one file upload per message."""
    attachment = build_attachment(site_id)
    short_prompt = build_short_prompt(site_id)
    catalogue_slice = load_catalogue_slice()
    preview = build_preview(site_id, catalogue_slice)
    return short_prompt, attachment, preview


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m src.generate_gui_prompt <site_id>")
        print("       python -m src.generate_gui_prompt <site_id> --twoturn   (let it reason freely first, then convert to JSON)")
        print("       python -m src.generate_gui_prompt <site_id> --chunked   (if attachments genuinely aren't read at all)")
        print("       python -m src.generate_gui_prompt --all   (generate every un-collated/un-classified site at once)")
        sys.exit(1)

    OUTPUT_DIR.mkdir(exist_ok=True)

    if len(sys.argv) >= 3 and sys.argv[2] == "--twoturn":
        site_id = sys.argv[1]
        turn1 = build_turn1_prompt(site_id)
        attachment = build_attachment(site_id)
        turn2 = build_turn2_prompt()

        (OUTPUT_DIR / f"{site_id}-turn1-prompt.txt").write_text(turn1)
        (OUTPUT_DIR / f"{site_id}-turn1-attachment.txt").write_text(attachment)
        (OUTPUT_DIR / f"{site_id}-turn2-prompt.txt").write_text(turn2)

        print(f"Wrote {site_id}-turn1-prompt.txt ({len(turn1)} chars) + "
              f"{site_id}-turn1-attachment.txt ({len(attachment)} chars)")
        print(f"Wrote {site_id}-turn2-prompt.txt ({len(turn2)} chars)")
        print()
        print("Workflow:")
        print(f"  1. Paste turn1-prompt.txt, upload turn1-attachment.txt, submit")
        print(f"  2. Read its analysis — this is where the good detail/diagram should show up")
        print(f"  3. In the SAME conversation, paste turn2-prompt.txt (no new attachment needed)")
        print(f"  4. That response should be the JSON — save it as {site_id}-output.json")
        print(f"  5. Run: python -m src.validate_manual_result {site_id}")
        sys.exit(0)

    if len(sys.argv) >= 3 and sys.argv[2] == "--chunked":
        site_id = sys.argv[1]
        chunks = build_chunks(site_id)
        digits = len(str(len(chunks)))

        for i, chunk in enumerate(chunks, 1):
            part_path = OUTPUT_DIR / f"{site_id}-part{str(i).zfill(digits)}.txt"
            part_path.write_text(chunk)

        print(f"Wrote {len(chunks)} sequential message(s) to {OUTPUT_DIR}/{site_id}-part*.txt")
        print("Paste these ONE AT A TIME, in order, into the SAME conversation.")
        print(f"Then run: python -m src.validate_manual_result {site_id}")
        sys.exit(0)

    if sys.argv[1] == "--all":
        from src.config_loader import list_curated_sites
        RESULTS_DIR = Path(__file__).parent.parent / "data" / "results"

        site_ids = list_curated_sites()
        already_classified = {p.stem for p in RESULTS_DIR.glob("*.json")}
        pending = [s for s in site_ids if s not in already_classified]

        if not pending:
            print("Every curated site already has a classified result in data/results/. "
                  "Nothing to generate — use --force logic manually if you want to redo any.")
            sys.exit(0)

        print(f"Generating {len(pending)} site(s) "
              f"(skipping {len(site_ids) - len(pending)} already classified)...\n")
        for site_id in pending:
            try:
                short_prompt, attachment, preview = _generate_one(site_id)

                (OUTPUT_DIR / f"{site_id}-prompt.txt").write_text(short_prompt)
                (OUTPUT_DIR / f"{site_id}-attachment.txt").write_text(attachment)
                (OUTPUT_DIR / f"{site_id}-preview.md").write_text(preview)

                print(f"  \u2705 {site_id} -> prompt ({len(short_prompt)} chars), "
                      f"attachment ({len(attachment)} chars)")
            except Exception as e:
                print(f"  \u274c {site_id} failed: {e}")

        print(f"\n{len(pending)} site(s) written to {OUTPUT_DIR}/")
        print("For each: paste -prompt.txt, upload -attachment.txt as the single file,")
        print("submit, save the response as <site_id>-output.json, then:")
        print("  python -m src.validate_manual_result --all")
        sys.exit(0)

    site_id = sys.argv[1]
    short_prompt, attachment, preview = _generate_one(site_id)

    preview_path = OUTPUT_DIR / f"{site_id}-preview.md"
    preview_path.write_text(preview)
    prompt_path = OUTPUT_DIR / f"{site_id}-prompt.txt"
    prompt_path.write_text(short_prompt)
    attachment_path = OUTPUT_DIR / f"{site_id}-attachment.txt"
    attachment_path.write_text(attachment)

    print(f"Wrote {prompt_path} ({len(short_prompt)} chars — paste into the GUI's text box)")
    print(f"Wrote {attachment_path} ({len(attachment)} chars — upload as the single attachment)")
    print(f"Wrote {preview_path} — read this first")
    print()
    print("Next steps:")
    print(f"  1. Open {preview_path} — quick sanity-check")
    print(f"  2. Paste {prompt_path}'s contents into your GUI's text box")
    print(f"  3. Upload {attachment_path} as the file attachment")
    print(f"  4. Pick a model, submit")
    print(f"  5. Copy the model's JSON response into {OUTPUT_DIR / (site_id + '-output.json')}")
    print(f"  6. Run: python -m src.validate_manual_result {site_id}")
