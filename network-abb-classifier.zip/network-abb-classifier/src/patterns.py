"""
Pattern matching — deterministic comparison, not an AI call.

Once a site has been classified (abb_matches with sbb/zbb per ABB), this
compares that output against the pattern_catalogue to find the closest
named pattern and report exactly which ABBs/blocks match vs diverge.

Kept as plain code, not a model prompt: this is a lookup/diff over
already-structured data, which is unambiguous and doesn't benefit from
LLM judgement — same principle applied to config normalisation earlier
in this pipeline.
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"


def load_pattern_catalogue() -> list:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        path = DATA_DIR / "catalogue" / "catalogue.example.json"
    catalogue = json.loads(path.read_text())
    return catalogue.get("pattern_catalogue", [])


def load_band_applicability(band: str) -> dict:
    path = DATA_DIR / "catalogue" / "catalogue.json"
    if not path.exists():
        path = DATA_DIR / "catalogue" / "catalogue.example.json"
    catalogue = json.loads(path.read_text())
    matrix = catalogue.get("band_applicability_matrix", [])
    for entry in matrix:
        if entry["band"] == band:
            return entry
    return {"band": band, "applicable_abbs": None, "not_applicable": {}}


def match_pattern(classification_result: dict) -> dict:
    """
    Given a site's classification output, find the pattern for its band
    and report per-ABB match status against the bundle.
    """
    band = classification_result.get("band")
    patterns = [p for p in load_pattern_catalogue() if p["band"] == band]

    if not patterns:
        applicability = load_band_applicability(band)
        all_abbs = [a["abb"] for a in classification_result.get("abb_matches", [])]
        expected_abbs = applicability.get("applicable_abbs")
        missing_but_expected = (
            [a for a in expected_abbs if a not in all_abbs] if expected_abbs else []
        )
        return {
            "closest_pattern": None,
            "match_status": "no_pattern_defined",
            "note": f"No pattern defined for band '{band}' yet — patterns are populated iteratively from wave-one data, not upfront.",
            "missing_but_expected_for_band": missing_but_expected,
            "not_applicable_for_band": list(applicability.get("not_applicable", {}).keys()),
        }

    pattern = patterns[0]  # assumes one canonical pattern per band; extend if multiple
    bundle = pattern["bundle"]

    matching_abbs = []
    diverging = []

    for abb_match in classification_result.get("abb_matches", []):
        abb = abb_match["abb"]
        expected = bundle.get(abb)
        if not expected:
            continue

        sbb_match = abb_match["sbb"]["cbb"] == expected["sbb_cbb"]
        zbb_match = abb_match["zbb"]["cbb"] == expected["zbb_cbb"]

        if sbb_match and zbb_match:
            matching_abbs.append(abb)
        else:
            diverging.append({
                "abb": abb,
                "sbb_matches": sbb_match,
                "zbb_matches": zbb_match,
                "observed_sbb_cbb": abb_match["sbb"]["cbb"],
                "expected_sbb_cbb": expected["sbb_cbb"],
                "observed_zbb_cbb": abb_match["zbb"]["cbb"],
                "expected_zbb_cbb": expected["zbb_cbb"],
            })

    all_abbs = [a["abb"] for a in classification_result.get("abb_matches", [])]
    status = "full" if not diverging else ("partial" if matching_abbs else "none")

    # Check for ABBs the band expects but the site's config didn't evidence at all —
    # distinguish a real gap from an ABB that simply isn't applicable to this band.
    applicability = load_band_applicability(band)
    expected_abbs = applicability.get("applicable_abbs")
    missing_but_expected = []
    if expected_abbs:
        for expected_abb in expected_abbs:
            if expected_abb not in all_abbs:
                missing_but_expected.append(expected_abb)

    return {
        "closest_pattern": pattern["pattern_id"],
        "match_status": status,
        "matching_abbs": matching_abbs,
        "diverging_abbs": diverging,
        "total_abbs_checked": len(all_abbs),
        "missing_but_expected_for_band": missing_but_expected,
        "not_applicable_for_band": list(applicability.get("not_applicable", {}).keys()),
    }


if __name__ == "__main__":
    import sys
    import json
    from pathlib import Path

    if len(sys.argv) < 2:
        print("Usage: python -m src.patterns <site_id>")
        sys.exit(1)

    site_id = sys.argv[1]
    result_path = Path(__file__).parent.parent / "data" / "results" / f"{site_id}.json"
    if not result_path.exists():
        print(f"No result found at {result_path}. Run classification/validation for this site first.")
        sys.exit(1)

    site_result = json.loads(result_path.read_text())
    match = match_pattern(site_result)
    print(json.dumps(match, indent=2))
