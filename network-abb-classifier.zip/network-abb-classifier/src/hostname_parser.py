"""
Parses device hostnames/filenames against the org's naming convention:

  chars 1-2   = country code
  chars 3-N   = site code (3-7 chars)
  next 1 char = device type: R=Router, C=Core, D=Distribution, A=Access
  remaining   = instance number

Site code length is variable, so this uses a lazy regex with
backtracking rather than a fixed-width split — verified against real
filenames including a genuinely ambiguous case (GBSFCTYD_R1, where the
site code SFCTYD itself contains a 'D' that could be mistaken for the
Distribution device-type letter; backtracking resolves it correctly).
"""
import re
from pathlib import Path

# Fixed-width convention: CC (country, 2) + SSSSSS (site, exactly 6) +
# TT (device type, exactly 2 letters — descriptive pairs like RT/CR/DS/
# AC/SV, but only the FIRST letter is used to determine role, since
# that alone is unambiguous across R/C/D/A/S) + ### (number, exactly 3).
PATTERN = re.compile(r'^([A-Z]{2})([A-Z0-9]{6})([A-Z]{2})(\d{3})$')

# Matches Cisco IOS-style "hostname X" lines. Case-insensitive since
# configs vary; anchored to line start so it doesn't match "hostname"
# appearing mid-sentence in a comment.
HOSTNAME_LINE = re.compile(r'^\s*hostname\s+(\S+)', re.MULTILINE | re.IGNORECASE)

DEVICE_ROLES = {"R": "Router", "C": "Core", "D": "Distribution", "A": "Access", "S": "Server"}

# Router/Core feed the WAN ABB (transport/routing hierarchy); Distribution/
# Access/Server feed the User ABB (edge/internal). Server's ABB hint is a
# best guess — no dedicated Server/DC ABB exists in the catalogue yet, so
# this may need revisiting once real Server-role config is seen.
ROLE_TO_ABB_HINT = {"R": "WAN", "C": "WAN", "D": "User", "A": "User", "S": "User"}


def extract_hostname_from_config(config_text: str) -> str:
    """
    Pulls the device's own hostname out of its config content (the
    'hostname X' line), rather than trusting the filename. More robust:
    filenames can have typos, stray spaces, or get renamed in transit,
    but the hostname the device configures itself with is authoritative.
    Returns None if no hostname line is found.
    """
    m = HOSTNAME_LINE.search(config_text)
    return m.group(1) if m else None


def parse_device_name(name: str) -> dict:
    """
    Returns None if the name doesn't match the convention (don't guess —
    an unparsed device should be flagged, not silently misgrouped).
    """
    clean = Path(name).stem.upper().replace("_", "").replace(" ", "").replace("-", "")
    m = PATTERN.match(clean)
    if not m:
        return None
    country, site_code, dev_type_field, instance = m.groups()
    role_letter = dev_type_field[0]  # first letter identifies role, whether the field is 1 or 2 chars
    if role_letter not in DEVICE_ROLES:
        return None  # matched the shape but not a known device type — don't guess the role
    return {
        "original_name": name,
        "country": country,
        "site_code": site_code,
        "device_type": dev_type_field,
        "role": DEVICE_ROLES[role_letter],
        "abb_hint": ROLE_TO_ABB_HINT[role_letter],
        "instance": instance,
        "site_id": country + site_code,
    }


def group_devices_by_site(filenames: list) -> dict:
    """
    Groups a list of filenames/hostnames by site_id. Returns
    {site_id: [parsed_device_dict, ...]}. Names that don't match the
    convention are collected under None so they're visible, not lost.
    """
    grouped = {}
    for name in filenames:
        parsed = parse_device_name(name)
        key = parsed["site_id"] if parsed else None
        grouped.setdefault(key, []).append(parsed or {"original_name": name})
    return grouped
